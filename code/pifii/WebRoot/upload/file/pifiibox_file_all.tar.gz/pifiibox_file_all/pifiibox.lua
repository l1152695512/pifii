module ("luci.controller.extension.pifiibox",package.seeall)

-- 2015-01-23 10:00 

function index()
  local page
  local api = require "luci.api"

  page = entry( api.apiuri("createDB", "pifiibox"), call("Api_createDB"), "", 1 )
  page.dependent = false

  page = entry( api.apiuri("insertDB", "pifiibox"), call("Api_insertDB"), "", 2 )
  page.dependent = false

  page = entry( api.apiuri("queryData", "pifiibox"), call("Api_queryData"), "", 3 )
  page.dependent = false

  page = entry( api.apiuri("sumData", "pifiibox"), call("Api_sumData"),"", 4 )
  page.dependent = false

  page = entry( api.apiuri("logIn", "pifiibox"), call("Api_logIn"), "", 5 )
  page.dependent = false
  page.sysauth = false

  page = entry( api.apiuri("setURL", "pifiibox"), call("Api_setURL"), "", 6 )
  page.dependent = false
  page.sysauth = false

  page = entry( api.apiuri("HiPifii", "pifiibox"), call("Api_HiPifii"), "", 7 )
  page.dependent = false
  page.sysauth = false
  
  page = entry( api.apiuri("getQos", "pifiibox"), call("Api_GetQos"), "", 8 )
  page.dependent = false
  page.sysauth = false
  
  page = entry( api.apiuri("setQos", "pifiibox"), call("Api_SetQos"), "", 9 )
  page.dependent = false
  page.sysauth = false
  
  page = entry( api.apiuri("getPrivoxy", "pifiibox"), call("Api_GetPrivoxy"), "", 10 )
  page.dependent = false
  page.sysauth = false
  
  page = entry( api.apiuri("setPrivoxy", "pifiibox"), call("Api_SetPrivoxy"), "", 11 )
  page.dependent = false
  page.sysauth = false
end

-- lua http
function setHttp(urls)

   local http = require("socket.http")
   local ltn12 = require("ltn12")
   local socket = require "socket"

   function http.get(u)
     local t = {}
     local r, c, h = http.request{
     url = u,
     sink = ltn12.sink.table(t)
      }
     return r, c, h, table.concat(t)
   end

   r,c,h,body=http.get(urls)
   ccc = c
   return c,body

end


function pifiidb_createTable(name)
   local db=sqlite3.open(name)
   db:exec[[

      CREATE TABLE SYS_LogSum (ID INTEGER PRIMARY KEY AUTOINCREMENT, SystemSN NVARCHAR(50),
                  ClientMAC NVARCHAR(50) , ResourcesID NVARCHAR(50), SumTime NVARCHAR(100));

      CREATE TABLE APP_AudioInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, AudioName NVARCHAR(50),
                  SortId Integer , ImgPath NVARCHAR(100), FilePath NVARCHAR(100));

      CREATE TABLE SYS_IndexClientInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, CilentName NVARCHAR(20),
                ClientPhone NVARCHAR(50), ClientLogoPath NVARCHAR(50), ClientAdr NVARCHAR(100), ClientQRCode NVARCHAR(50));

      CREATE TABLE APP_BookInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, BookName NVARCHAR(50),
                  BookType NVARCHAR(20), SortId Integer, ImgPath NVARCHAR(100), FilePath NVARCHAR(100) ,
                                    Author NVARCHAR(20),Desp NVARCHAR(100));

      CREATE TABLE APP_ModuleSum (ID INTEGER PRIMARY KEY AUTOINCREMENT, ModuleID Integer,
                  DeviceID NVARCHAR(50), DeviceMAC NVARCHAR(50), SumTime NVARCHAR(100));

      CREATE TABLE SYS_BaseInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, BoxID NVARCHAR(50),
            Version NVARCHAR(50), APPVersion NVARCHAR(50), IsNewest Integer , TempletID Integer);

      CREATE TABLE SYS_IndexAppInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, AppName NVARCHAR(20),
            AppLogoPath NVARCHAR(50), AppLink NVARCHAR(50), SortId Integer);

      CREATE TABLE SYS_IndexADInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, AdName NVARCHAR(20),
            AdImgPath NVARCHAR(50), AdLink NVARCHAR(150), SortId Integer);

      CREATE TABLE APP_VideoInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, VideoName NVARCHAR(50),
            SortId Integer , ImgPath NVARCHAR(100), FilePath NVARCHAR(100), Desp NVARCHAR(100));

      CREATE TABLE APP_APPInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, AppName NVARCHAR(50),
            APPType NVARCHAR(20), SortId Integer, ImgPath NVARCHAR(100) , FilePath NVARCHAR(100) ,
                  HitStar Integer ,DLNum Integer);

      CREATE TABLE APP_GameInfo (ID INTEGER PRIMARY KEY AUTOINCREMENT, GameName NVARCHAR(50),
            SortId Integer, ImgPath NVARCHAR(100), GamePath NVARCHAR(100) ,HitStar Integer);


    ]]

end



function Api_createDB(args)
   require "lsqlite3"
   local api = require "luci.api"
   if not args then args = {} end
   local hwrite = api.GetParam(args, "hwrite", "1")

   local uci = luci.model.uci.cursor()
   local fname, section = "pifiibox", "ipset"
   result = 1

   pifiidb_createTable( "/usr/lib/lua/luci/controller/extension/pifiibox.db" )

    local ret = {
         test  = uci:get(fname, section, "createDB"),
--         version = sqlite3.version(),
--         args = args
           result = result
         }

    if hwrite=="1" then
          luci.http.prepare_content( "application/json; charset=GBK" )
          luci.http.write_json(ret)
    end
    return ret

end


-- select database
function Api_queryData(args)
  require "lsqlite3"
  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"
  local dataARR={}
  local result = 1
  local TableNamedb = api.GetParam(args, "tname")

     if not TableNamedb then
          result = 0
      else

  local db=sqlite3.open("/usr/lib/lua/luci/controller/extension/pifiibox.db")
  local sql="select * from "..TableNamedb
    local i=1
    for row in db:nrows(sql) do
      dataARR[i] =row
      i = i+1
    end
  end

  local ret = {
               test  = uci:get(fname, section, "queryData"),
               result = result,
               data=dataARR,
               }

    if hwrite=="1" then
          luci.http.prepare_content( "application/json;charset=GBK" )
          luci.http.write_json(ret)
    end
    return ret

end




-- insert database
function Api_insertDB(args)
  require "lsqlite3"
  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"

 local result = 1
 local db=sqlite3.open("/usr/lib/lua/luci/controller/extension/pifiibox.db")
 local TableNamedb = api.GetParam(args, "TableName")

    if not TableNamedb then
        result = 0

    elseif TableNamedb == "SYS_BaseInfo" then

    local BoxIDdb = api.GetParam(args, "BoxID")
    if not BoxIDdb then BoxIDdb = "" end
    local Versiondb = api.GetParam(args, "Version")
    if not Versiondb then Versiondb = "" end
    local APPVersiondb = api.GetParam(args, "APPVersion")
    if not APPVersiondb then APPVersiondb = "" end
    local IsNewestdb = api.GetParam(args, "IsNewest")
    if not IsNewestdb then IsNewestdb = "" end
    local TempletIDdb = api.GetParam(args, "TempletID")
    if not TempletIDdb then TempletIDdb = "" end
    local sql = "INSERT INTO SYS_BaseInfo(BoxID, Version, APPVersion, IsNewest, TempletID) VALUES (\'"..BoxIDdb.."\', \'"..Versiondb.."\', \'"..APPVersiondb.."\', \'"..IsNewestdb.."\', \'"..TempletIDdb.."\');"
    db:exec(sql, NULL, NULL)

    elseif TableNamedb == "SYS_IndexAppInfo" then

      local AppNamedb = api.GetParam(args, "AppName")
      if not AppNamedb then AppNamedb = "" end
      local AppLogoPathdb = api.GetParam(args, "AppLogoPath")
      if not AppLogoPathdb then AppLogoPathdb = "" end
      local AppLinkdb = api.GetParam(args, "AppLink")
      if not AppLinkdb then AppLinkdb = "" end
      local SortIddb = api.GetParam(args, "SortId")
      if not SortIddb then SortIddb = "" end
      local sql = "INSERT INTO SYS_IndexAppInfo(AppName, AppLogoPath, AppLink, SortId) VALUES (\'"..AppNamedb.."\', \'"..AppLogoPathdb.."\', \'"..AppLinkdb.."\', \'"..SortIddb.."\');"
      db:exec(sql, NULL, NULL)

    elseif TableNamedb == "SYS_IndexADInfo" then

      local AdNamedb = api.GetParam(args, "AdName")
      if not AdNamedb then AdNamedb = "" end
      local AdImgPathdb = api.GetParam(args, "AdImgPath")
      if not AdImgPathdb then AdImgPathdb = "" end
      local AdLinkdb = api.GetParam(args, "AdLink")
      if not AdLinkdb then AdLinkdb = "" end
      local SortIddb = api.GetParam(args, "SortId")
      if not SortIddb then SortIddb = "" end
      local sql = "INSERT INTO SYS_IndexADInfo(AdName, AdImgPath, AdLink, SortId) VALUES (\'"..AdNamedb.."\', \'"..AdImgPathdb.."\', \'"..AdLinkdb.."\', \'"..SortIddb.."\');"
      db:exec(sql, NULL, NULL)

   elseif TableNamedb == "SYS_IndexClientInfo" then

      local CilentNamedb = api.GetParam(args, "CilentName")
      if not CilentNamedb then CilentNamedb = "" end
      local ClientLogoPathdb = api.GetParam(args, "ClientLogoPath")
      if not ClientLogoPathdb then ClientLogoPathdb = "" end
      local ClientAdrdb = api.GetParam(args, "ClientAdr")
      if not ClientAdrdb then ClientAdrdb = "" end
      local ClientQRCodedb = api.GetParam(args, "ClientQRCode")
      if not ClientQRCodedb then ClientQRCodedb = "" end
      local sql = "INSERT INTO SYS_IndexClientInfo(CilentName, ClientLogoPath, ClientAdr, ClientQRCode) VALUES (\'"..CilentNamedb.."\', \'"..ClientLogoPathdb.."\', \'"..ClientAdrdb.."\', \'"..ClientQRCodedb.."\');"
      db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_VideoInfo" then

    local VideoNamedb = api.GetParam(args, "VideoName")
    if not VideoNamedb then VideoNamedb = "" end
    local SortIddb = api.GetParam(args, "SortId")
    if not SortIddb then SortIddb = "" end
    local ImgPathdb = api.GetParam(args, "ImgPath")
    if not ImgPathdb then ImgPathdb = "" end
    local FilePathdb = api.GetParam(args, "FilePath")
    if not FilePathdb then FilePathdb = "" end
    local Despdb = api.GetParam(args, "Desp")
    if not Despdb then Despdb = "" end
    local sql = "INSERT INTO APP_VideoInfo(VideoName, SortId, ImgPath, FilePath, Desp) VALUES (\'"..VideoNamedb.."\', \'"..SortIddb.."\', \'"..ImgPathdb.."\', \'"..FilePathdb.."\', \'"..Despdb.."\');"
    db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_AudioInfo" then

    local AudioNamedb = api.GetParam(args, "AudioName")
    if not AudioNamedb then AudioNamedb = "" end
    local SortIddb = api.GetParam(args, "SortId")
    if not SortIddb then SortIddb = "" end
    local ImgPathdb = api.GetParam(args, "ImgPath")
    if not ImgPathdb then ImgPathdb = "" end
    local FilePathdb = api.GetParam(args, "FilePath")
    if not FilePathdb then FilePathdb = "" end
    local sql = "INSERT INTO APP_AudioInfo(AudioName, SortId, ImgPath, FilePath) VALUES (\'"..AudioNamedb.."\',\'"..SortIddb.."\', \'"..ImgPathdb.."\', \'"..FilePathdb.."\');"
    db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_APPInfo" then

    local AppNamedb = api.GetParam(args, "AppName")
    if not AppNamedb then AppNamedb = "" end
    local APPTypedb = api.GetParam(args, "APPType")
    if not APPTypedb then APPTypedb = "" end
    local SortIddb = api.GetParam(args, "SortId")
    if not SortIddb then SortIddb = "" end
    local ImgPathdb = api.GetParam(args, "ImgPath")
    if not ImgPathdb then ImgPathdb = "" end
    local FilePathdb = api.GetParam(args, "FilePath")
    if not FilePathdb then FilePathdb = "" end
    local HitStardb = api.GetParam(args, "HitStar")
    if not HitStardb then HitStardb = "" end
    local DLNumdb = api.GetParam(args, "DLNum")
    if not DLNumdb then DLNumdb = "" end
    local sql = "INSERT INTO APP_APPInfo(AppName, APPType, SortId, ImgPath, FilePath, HitStar, DLNum) VALUES (\'"..AppNamedb.."\', \'"..APPTypedb.."\', \'"..SortIddb.."\', \'"..ImgPathdb.."\', \'"..FilePathdb.."\', \'"..HitStardb.."\', \'"..DLNumdb.."\');"
    db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_BookInfo" then

    local BookNamedb = api.GetParam(args, "BookName")
    if not BookNamedb then BookNamedb = "" end
    local BookTypedb = api.GetParam(args, "BookType")
    if not BookTypedb then BookTypedb = "" end
    local SortIddb = api.GetParam(args, "SortId")
    if not SortIddb then SortIddb = "" end
    local ImgPathdb = api.GetParam(args, "ImgPath")
    if not ImgPathdb then ImgPathdb = "" end
    local FilePathdb = api.GetParam(args, "FilePath")
    if not FilePathdb then FilePathdb = "" end
    local Authordb = api.GetParam(args, "Author")
    if not Authordb then Authordb = "" end
    local Despdb = api.GetParam(args, "Desp")
    if not Despdb then Despdb = "" end
    local sql = "INSERT INTO APP_BookInfo(BookName, BookType, SortId, ImgPath, FilePath, Author, Desp) VALUES (\'"..BookNamedb.."\', \'"..BookTypedb.."\', \'"..SortIddb.."\', \'"..ImgPathdb.."\', \'"..FilePathdb.."\', \'"..Authordb.."\', \'"..Despdb.."\');"
    db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_GameInfo" then

    local GameNamedb = api.GetParam(args, "GameName")
    if not GameNamedb then GameNamedb = "" end
    local SortIddb = api.GetParam(args, "SortId")
    if not SortIddb then SortIddb = "" end
    local ImgPathdb = api.GetParam(args, "ImgPath")
    if not ImgPathdb then ImgPathdb = "" end
    local GamePathdb = api.GetParam(args, "GamePath")
    if not GamePathdb then GamePathdb = "" end
    local HitStardb = api.GetParam(args, "HitStar")
    if not HitStardb then HitStardb = "" end
    local sql = "INSERT INTO APP_GameInfo(GameName, SortId, ImgPath, GamePath, HitStar) VALUES (\'"..GameNamedb.."\', \'"..SortIddb.."\', \'"..ImgPathdb.."\', \'"..GamePathdb.."\', \'"..HitStardb.."\');"
    db:exec(sql, NULL, NULL)

   elseif TableNamedb == "APP_ModuleSum" then

    local ModuleIDdb = api.GetParam(args, "ModuleID")
    if not ModuleIDdb then ModuleIDdb = "" end
    local DeviceIDdb = api.GetParam(args, "DeviceID")
    if not DeviceIDdb then DeviceIDdb = "" end
    local DeviceMACdb = api.GetParam(args, "DeviceMAC")
    if not DeviceMACdb then DeviceMACdb = "" end
    local SumTimedb = api.GetParam(args, "SumTime")
    if not SumTimedb then SumTimedb = "" end

    local systime = os.date("%Y")..os.date("%m")..os.date("%d").." "..os.date("%X")


    local sql = "INSERT INTO APP_ModuleSum(ModuleID, DeviceID, DeviceMAC, SumTime) VALUES (\'"..ModuleIDdb.."\', \'"..DeviceIDdb.."\', \'"..DeviceMACdb.."\', \'"..systime.."\');"
    db:exec(sql, NULL, NULL)

  end

   ret = {
     test  = uci:get(fname, section, "insertDB"),
     resule = result,
   }

 if hwrite=="1" then
     luci.http.prepare_content( "application/json;charset=GBK")
     luci.http.write_json(ret)
  end
  return ret
end



 function Api_sumData(args)
 --http://192.168.10.1/cgi-bin/luci/api/0/pifiibox/sumData?token=080df330x4g0vdw4&ModuleID=2

  require "lsqlite3"
  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"
  local ModuleIDdb = api.GetParam(args, "ModuleID")
  if not ModuleIDdb then ModuleIDdb = "" end

  local db=sqlite3.open("pifiibox.db")

--  local sql = "select count (*) from APP_ModuleSum where ModuleID ="..ModuleIDdb
  local sql="select * from APP_ModuleSum where ModuleID ="..ModuleIDdb

  local sum = 0
      for row in db:nrows(sql) do
         sum = sum + 1
      end
 local ret = {
             test  = uci:get(fname, section, "sumData"),
             result = result,
             sum = sum,
              }
    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
     return ret
  end



function getSN()
  local fname = "idcard"
  local section = fname
  local uci = luci.model.uci.cursor()
  local sn = uci:get(fname,section,"serial_number")
  return sn
end


-- insert database
function Api_logIn(args)

--http://192.168.10.1/cgi-bin/luci/api/0/pifiibox/logIn?token=080df330x4g0vdw4?mac=aaa&rid=13

  require "lsqlite3"
  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"

  local db=sqlite3.open("/usr/lib/lua/luci/controller/extension/pifiibox.db")

  local ClientMACdb = api.GetParam(args, "mac")
  if not ClientMACdb then ClientMACdb = "" end
  local ResourcesIDdb = api.GetParam(args, "rid")
  if not ResourcesIDdb then ResourcesIDdb = "" end

  local SystemSNdb = getSN()
  -- get system timea
  local SumTimedb = os.date("%Y")..os.date("%m")..os.date("%d")..os.date("%H")..os.date("%M")..os.date("%S")

  local db=sqlite3.open("/usr/lib/lua/luci/controller/extension/pifiibox.db")
  local sql = "INSERT INTO SYS_LogSum(SystemSN, ClientMAC, ResourcesID, SumTime) VALUES (\'"..SystemSNdb.."\', \'"..ClientMACdb.."\', \'"..ResourcesIDdb.."\', \'"..SumTimedb.."\');"
  db:exec(sql, NULL, NULL)

end


-- set hosturl
function setHostURL(hosturl)
  local api = require "luci.api"
  require "luci.model.uci"
  local uci = luci.model.uci.cursor()
  uci:set("ifidc","auth","hosturl",hosturl)
  local stat = uci:commit( "ifidc" )
end


-- set url
function Api_setURL(args)

-- http://192.168.10.1/cgi-bin/luci/api/0/pifiibox/setURL?token=080df330x4g0vdw4&seturl=http://www.pifii.com/home

  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"

  local ret = {}
  local get_URL = api.GetParam(args, "seturl")
  if get_URL then
     setHostURL(get_URL)
     ret = {
            seturl = get_URL,
	    }
  end --  if get_URL then

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret

end


function getPassWork()
  local uci = luci.model.uci.cursor()
  local pw = uci:get("account","account","pass")
  return pw
end


function Base64(str)
  local mime = require("mime")
  return (mime.b64(str))
end


function UnBase64(str)
  local mime = require("mime")
  return (mime.unb64(str))
end


-- get token value
function getToken()
  require "luci.model.uci"
  local uci=luci.model.uci.cursor()
  local token=uci:get("idcard","idcard","token")
  return token
end


-- get mac value
function getMAC()
  require "luci.json"
  local host_box_url = "http://192.168.10.1/cgi-bin/luci/api/0/"
  require "luci.model.uci"
  local mac
  local token = getToken()
-- http://192.168.10.1/cgi-bin/luci/api/0/common/deviceinfo?token=080d63gyigbbof2c
  if token then
    local urls = host_box_url.."common/deviceinfo?token="..token
    local c,res = setHttp(urls)

    if c == 200 then
      local res_tab = luci.json.decode(res)
      mac = res_tab.lan.mac
----      return (string.upper(string.gsub(mac,":","")))
      return mac
    end -- if cc == 200 then

  end -- if token then
--  return (string.upper(string.gsub(mac,":","")))
  return mac
end



-- set url
function Api_HiPifii(args)

-- http://192.168.10.1/cgi-bin/luci/api/0/pifiibox/HiPifii

  local api = require "luci.api"
  if not args then args = {} end
  local hwrite = api.GetParam(args, "hwrite", "1")
  local uci = luci.model.uci.cursor()
  local fname, section = "pifiibox", "ipset"

--  local str = getPassWork()
  local str = getToken()
  for i=1, 3 do
     str = str..math.random(1,9)
  end --  for i=1, 3 do
  local bas2 =  Base64(Base64(str))

  local passWord = getPassWork()
  for i=1, 3 do
     passWord = passWord..math.random(1,9)
  end --  for i=1, 3 do
  local passWord2 =  Base64(Base64(passWord))
  
     ret = {
            hipifii_t = bas2,
            hipifii_p = passWord2
	    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret

end

function Api_GetQos(args)
    require "luci.model.uci"
    local api = require "luci.api"
    local uci = luci.model.uci.cursor()
    local ret = {
        enabled="-1",
        upload="0",
        download="0"
    }   
    local is_qos = os.execute("test -f /etc/config/qos")
    if 0 == is_qos then
        local qosenabled = uci:get("qos","wan","enabled")
        local up = uci:get("qos","wan","upload")
        local down = uci:get("qos","wan","download")
        ret["enabled"]=qosenabled
        ret["upload"]=up/1024
        ret["download"]=down/1024
    end
    if not args then args = {} end
    local hwrite = api.GetParam(args,"hwrite","1")
    if "1"==hwrite then
        luci.http.prepare_content("application/json") 
        luci.http.write_json(ret) 
    end
    return ret 
end

function Api_SetQos(args)
    local api = require "luci.api"
    local ret = {result="false"}
    if not args then args = {} end                                                                                 
    local hwrite = api.GetParam(args, "hwrite", "1")
    if args then 
        local enabled_set = api.GetParam(args,"enabled")
        local up_set = api.GetParam(args,"upload")
        local down_set = api.GetParam(args,"download")
        if enabled_set and up_set and down_set then 
            require "luci.model.uci"
            local uci = luci.model.uci.cursor()
            local enabled_old = uci:get("qos","wan","enabled")
            local up_old = uci:get("qos","wan","upload")
            local down_old = uci:get("qos","wan","download")
            if enabled_old == enabled_set and up_old+0 == up_set*1024 and down_old+0 == down_set*1024 then
                ret["result"]="true" 
            else
                uci:set("qos","wan","enabled",enabled_set)
                uci:set("qos","wan","upload",up_set*1024)
                uci:set("qos","wan","download",down_set*1024)
                local stat = uci:commit("qos")
                if stat then
                   os.execute("/etc/init.d/qos restart")
                   ret["result"]="true" 
                end
            end
        end
    end
    if "1" == hwrite then
        luci.http.prepare_content("application/json") 
        luci.http.write_json(ret) 
    end
    return ret
end

function Api_GetPrivoxy()
    local api = require "luci.api"
    local util = require "luci.util"                                                        
    local ret = {status="n"}
    local is_privoxy = os.execute("which privoxy >/dev/null")
    if 0 == is_privoxy then
        local conf = "/etc/nginx/vh.server.conf"
        local cmd_str = 'grep "^\ *proxy_pass\ http://192.168.10.1:8118;" '..conf..' | tr -d "\\ \\n"'
        local is_conf = util.exec(cmd_str) 
        if is_conf and "" ~= is_conf then
            cmd_str = "grep \"set\\ \\$lexaenable\" ".."/etc/nginx/vh.server.conf | head -n 1 | awk ".." \'{print $3}\' | tr -d \'\";\\n\'" 
            local status = util.exec(cmd_str)
            if status and "n" == status then 
               ret["status"]="n" 
            else
               ret["status"]="y" 
            end
        else
            ret["status"]="not config"
        end
    else
    	ret["status"]="privoxy is not installed"
    end
    if not args then args = {} end                                                                                 
    local hwrite = api.GetParam(args, "hwrite", "1")
    if "1" == hwrite then
        luci.http.prepare_content("application/json") 
        luci.http.write_json(ret) 
    end
end

function Api_SetPrivoxy(args)
    local api = require "luci.api"
    local util = require "luci.util"                                                        
    local ret = {result="false"}
    if not args then args = {} end                                                                                 
    local hwrite = api.GetParam(args, "hwrite", "1")
    local is_privoxy = os.execute("which privoxy >/dev/null")
    if 0 == is_privoxy then
        local conf = "/etc/nginx/vh.server.conf"
        local cmd_str = 'grep "^\ *proxy_pass\ http://192.168.10.1:8118;" '..conf..' | tr -d "\\ \\n"'
        local is_conf = util.exec(cmd_str) 
        if is_conf and "" ~= is_conf then
            cmd_str = "grep \"set\\ \\$lexaenable\" ".."/etc/nginx/vh.server.conf | head -n 1 | awk ".." \'{print $3}\' | tr -d \'\";\\n\'" 
            local status = util.exec(cmd_str)
            local status_set = api.GetParam(args,"status")
            if status and status_set then
                if status == status_set then 
                    ret["result"]="true"
                else
                   cmd_str='grep "set\ \$lexaenable" '..conf..' -n | head -n 1 | sed s/:.*// | tr -d "\\n"' 
                   local line_num = util.exec(cmd_str) 
                   cmd_str='sed -i "'..line_num..' s/\\".*\\"/\\"'..status_set..'\\"/" '..conf
                   local is_set = os.execute(cmd_str) 
                   if is_set and 0 == is_set then
                        os.execute("/etc/init.d/nginx reload")
                        ret["result"]="true"
                   end
                end
            else 
                ret["result"]="false"
            end
        else
            ret["result"]="not config"
        end 
    else
    	ret["result"]="privoxy is not installed"
    end 
    if "1" == hwrite then
        luci.http.prepare_content("application/json") 
        luci.http.write_json(ret) 
    end
    return ret
end
