module( "luci.controller.extension.ifidc", package.seeall )



function index()
    local page
    local api = require "luci.api"

    page = entry( api.apiuri("logserver_set", "ifidc"), call("Api_logserver_set"), "", 1 )
    page.dependent = false
    page = entry( api.apiuri("logserver_get", "ifidc"), call("Api_logserver_get"), "", 2 )
    page.dependent = false

    page = entry( api.apiuri("authurl_set", "ifidc"), call("Api_authurl_set"), "", 3 )
    page.dependent = false
    page = entry( api.apiuri("authurl_get", "ifidc"), call("Api_authurl_get"), "", 4 )
    page.dependent = false

    page = entry( api.apiuri("passlist_set", "ifidc"), call("Api_passlist_set"), "", 5 )
    page.dependent = false
    page = entry( api.apiuri("passlist_get", "ifidc"), call("Api_passlist_get"), "", 6 )
    page.dependent = false

    page = entry( api.apiuri("whitelist_set", "ifidc"), call("Api_whitelist_set"), "", 7 )
    page.dependent = false
    page = entry( api.apiuri("whitelist_get", "ifidc"), call("Api_whitelist_get"), "", 8 )
    page.dependent = false

    page = entry( api.apiuri("timeout_set", "ifidc"), call("Api_timeout_set"), "", 7 )
    page.dependent = false
    page = entry( api.apiuri("timeout_get", "ifidc"), call("Api_timeout_get"), "", 8 )
    page.dependent = false

    page = entry( api.apiuri("cmcc_set", "ifidc"), call("Api_cmcc_set"), "", 7 )
    page.dependent = false
    page = entry( api.apiuri("cmcc_get", "ifidc"), call("Api_cmcc_get"), "", 8 )
    page.dependent = false

    page = entry( api.apiuri("opkg_cmd", "ifidc"), call("Api_opkg_cmd"), "", 7 )
    page.dependent = false

    page = entry( api.apiuri("def_location_set", "ifidc"), call("Api_def_location_set"), "", 7 )
    page.dependent = false
    page = entry( api.apiuri("def_location_get", "ifidc"), call("Api_def_location_get"), "", 8 )
    page.dependent = false

    page = entry( api.apiuri("custom_domain_set", "ifidc"), call("Api_custom_domain_set"), "", 7 )
    page.dependent = false
    page = entry( api.apiuri("custom_domain_get", "ifidc"), call("Api_custom_domain_get"), "", 8 )
    page.dependent = false

end


function Api_logserver_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local ip = api.GetParam(args, "ip")
    local port = api.GetParam(args, "port")

    repeat
        if not dt.ipaddr(ip) then status = 2 break end
        if not dt.port(port) then status = 2 break end
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "logserver"
        api.InitConfigNameSection( fname, section, nil, uci )
        uci:set( fname, section, "ip", ip )
        uci:set( fname, section, "port", port )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        stat = uci:apply( "syslog-ng" )
        if stat ~= 0 then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_logserver_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "logserver"
    local ret = {
         ip = uci:get(fname, section, "ip") or "",
         port = tonumber(uci:get(fname, section, "port")),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function parse_http_url(web)
    local sch, hp, uri, args = web:match("(https?)://([^/]+)([^?]*)(.*)")
    return { sch = sch, hp = hp, uri = uri, args = args }
end
function Api_authurl_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local auth = api.GetParam(args, "auth")
    local ad = api.GetParam(args, "ad")

    repeat
        if not auth or not ad then status=2 break end
        local tauth = parse_http_url(auth)
        local tad = parse_http_url(ad)

        if not tauth.sch or not tauth.hp
                or not tad.sch or not tad.hp then
            status=2
            break
        end
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "auth"
        api.InitConfigNameSection( fname, section, nil, uci )
        uci:set( fname, section, "auth", auth )
        uci:set( fname, section, "ad", ad )
        for k, v in pairs(tauth) do
            uci:set( fname, section, "ifauth"..k, v )
        end
        for k, v in pairs(tad) do
            uci:set( fname, section, "ifad"..k, v )
        end

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        stat = uci:apply( "nginx" )
        if stat ~= 0 then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_authurl_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "auth"
    local ret = {
        auth = uci:get(fname, section, "auth") or "",
        ad = uci:get(fname, section, "ad") or "",
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end

function Api_passlist_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local member = api.GetParam(args, "member")

    if type(member) ~= "table" then member = { member } end

    repeat
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "passlist"
        api.InitConfigNameSection( fname, section, nil, uci )
        uci:delete( fname, section, 'member' )
        uci:set_list( fname, section, "member", member )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        stat = uci:apply( "ifidc_ipset_member" )
        if stat ~= 0 then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_passlist_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "passlist"
    local ret = {
         member = uci:get(fname, section, "member"),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_whitelist_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local ip = api.GetParam(args, "ip")
    local domain = api.GetParam(args, "domain")
    if type(ip) ~= "table" then ip = { ip } end
    if type(domain) ~= "table" then domain = { domain } end

    repeat
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "whitelist"
        api.InitConfigNameSection( fname, section, nil, uci )

        uci:delete( fname, section, "ip" )
        -- uci:delete( fname, section, "iport" )
        uci:delete( fname, section, "domain" )

        if next( ip ) then uci:set_list( fname, section, "ip", ip ) end
        -- uci:set_list( fname, section, "iport", iport )
        if next( domain ) then uci:set_list( fname, section, "domain", domain ) end

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        stat = uci:apply( "ifidc_ipset_whitelist" )
        if stat ~= 0 then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_whitelist_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "whitelist"
    local ret = {
         ip = uci:get(fname, section, "ip"),
         -- iport = uci:get(fname, section, "iport"),
         domain = uci:get(fname, section, "domain"),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end

function Api_timeout_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local timeout = api.GetParam(args, "timeout")
    repeat
        if not timeout or not tonumber(timeout) then status = 2 break end
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "ipset"
        api.InitConfigNameSection( fname, section, nil, uci )
        uci:set( fname, section, "timeout", timeout )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        stat = uci:apply( "ifidc_ipset" )
        if stat ~= 0 then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_timeout_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "ipset"
    local ret = {
        timeout  = uci:get(fname, section, "timeout"),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_cmcc_set(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0

    local username = api.GetParam(args, "user")
    local password = api.GetParam(args, "pass")
    local cmcc = api.GetParam(args, "cmcc")
    local enable = api.GetParam(args, "enable", "1")

    repeat
        if not username or not password or not cmcc then status=2 break end
        if cmcc ~= "cmcc" and cmcc ~= "cmcc_jike" and cmcc ~= "cmcc_edu" then status=2 break end

        local uci = luci.model.uci.cursor()

        local fname, section = "ifidc", cmcc

        api.InitConfigNameSection( fname, section, nil, uci )

        uci:set( fname, section, "username", username )
        uci:set( fname, section, "password", password )
        uci:set( fname, section, "enable", enable )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
        --stat = uci:apply( "ifidc_cmcc" )
        --if stat ~= 0 then status = 5 break end

    until true

    local ret = api.Status( status )

    if cmcc then
        api.call_no_stdout( cmcc .. "_autoauth")
    end

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_cmcc_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")
    local cmcc = api.GetParam(args, "cmcc")

    local ret = {}
    repeat
        if not cmcc then status=2 break end
        if cmcc ~= "cmcc" and cmcc ~= "cmcc_jike" and cmcc ~= "cmcc_edu" then status=2 break end

        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", cmcc
        ret = {
            user  = uci:get(fname, section, "username"),
            pass = uci:get(fname, section, "password"),
            enable = uci:get(fname, section, "enable"),
        }
    until true

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_opkg_cmd(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0

    local path = api.GetParam(args, "path")
    local cmd = api.GetParam(args, "cmd")

    repeat
        if not path or not cmd then status = 2 break end

        local callret = api.call_no_stdout("opkg " .. cmd .. " " .. path)
        if callret ~= 0 then status = 5 break end
        break
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_def_location_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local url = api.GetParam(args, "url")
    repeat
        if not url then status = 2 break end
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "def_location"
        api.InitConfigNameSection( fname, section, nil, uci )
        uci:set( fname, section, "url", url )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_def_location_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "def_location"
    local ret = {
        url  = uci:get(fname, section, "url"),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_custom_domain_set(args)
    local dt = require "luci.cbi.datatypes"
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local status = 0
    local domains = api.GetParam(args, "domains")
    repeat
        if not domains then status = 2 break end
        local uci = luci.model.uci.cursor()
        local fname, section = "ifidc", "custom"

        api.InitConfigNameSection( fname, section, nil, uci )

        if type(domains)=="string" then domains = {domains,} end
        uci:set_list( fname, section, "domain", domains )

        local stat = uci:commit( fname )
        if not stat then status = 3 break end

        stat = api.call_no_stdout("/etc/init.d/dnsmasq restart")
        if not stat then status = 5 break end
    until true

    local ret = api.Status( status )

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end


function Api_custom_domain_get(args)
    local api = require "luci.api"
    if not args then args = {} end
    local hwrite = api.GetParam(args, "hwrite", "1")

    local uci = luci.model.uci.cursor()
    local fname, section = "ifidc", "custom"
    local ret = {
        custom = uci:get_list(fname, section, "domain"),
    }

    if hwrite=="1" then
        luci.http.prepare_content( "application/json" )
        luci.http.write_json(ret)
    end
    return ret
end
