package org.productivity.java.syslog4j;

public class SyslogRuntimeException extends RuntimeException
{
  private static final long serialVersionUID = 7278123987654320379L;

  public SyslogRuntimeException(String paramString)
  {
    super(paramString);
  }

  public SyslogRuntimeException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogRuntimeException
 * JD-Core Version:    0.6.0
 */