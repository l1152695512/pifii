package org.productivity.java.syslog4j;

public abstract interface SyslogMessageModifierConfigIF extends SyslogConstants, SyslogCharSetIF
{
  public abstract String getPrefix();

  public abstract void setPrefix(String paramString);

  public abstract String getSuffix();

  public abstract void setSuffix(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogMessageModifierConfigIF
 * JD-Core Version:    0.6.0
 */