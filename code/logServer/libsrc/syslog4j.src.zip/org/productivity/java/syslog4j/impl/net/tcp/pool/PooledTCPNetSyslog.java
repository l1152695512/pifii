package org.productivity.java.syslog4j.impl.net.tcp.pool;

import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslog;
import org.productivity.java.syslog4j.impl.pool.AbstractSyslogPoolFactory;
import org.productivity.java.syslog4j.impl.pool.generic.GenericSyslogPoolFactory;

public class PooledTCPNetSyslog extends TCPNetSyslog
{
  private static final long serialVersionUID = 4279960451141784200L;
  protected AbstractSyslogPoolFactory poolFactory = null;

  public void initialize()
    throws SyslogRuntimeException
  {
    super.initialize();
    this.poolFactory = createSyslogPoolFactory();
    this.poolFactory.initialize(this);
  }

  protected AbstractSyslogPoolFactory createSyslogPoolFactory()
  {
    GenericSyslogPoolFactory localGenericSyslogPoolFactory = new GenericSyslogPoolFactory();
    return localGenericSyslogPoolFactory;
  }

  public AbstractSyslogWriter getWriter()
  {
    try
    {
      AbstractSyslogWriter localAbstractSyslogWriter = this.poolFactory.borrowSyslogWriter();
      return localAbstractSyslogWriter;
    }
    catch (Exception localException)
    {
    }
    throw new SyslogRuntimeException(localException);
  }

  public void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
    try
    {
      this.poolFactory.returnSyslogWriter(paramAbstractSyslogWriter);
    }
    catch (Exception localException)
    {
      throw new SyslogRuntimeException(localException);
    }
  }

  public void flush()
    throws SyslogRuntimeException
  {
    try
    {
      this.poolFactory.clear();
    }
    catch (Exception localException)
    {
    }
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    try
    {
      this.poolFactory.close();
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.pool.PooledTCPNetSyslog
 * JD-Core Version:    0.6.0
 */