package org.productivity.java.syslog4j.server.impl.net.tcp.ssl;

import java.io.IOException;
import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLServerSocketFactory;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServer;

public class SSLTCPNetSyslogServer extends TCPNetSyslogServer
{
  public void initialize()
    throws SyslogRuntimeException
  {
    super.initialize();
    SSLTCPNetSyslogServerConfigIF localSSLTCPNetSyslogServerConfigIF = (SSLTCPNetSyslogServerConfigIF)this.tcpNetSyslogServerConfig;
    String str1 = localSSLTCPNetSyslogServerConfigIF.getKeyStore();
    if ((str1 != null) && (!"".equals(str1.trim())))
      System.setProperty("javax.net.ssl.keyStore", str1);
    String str2 = localSSLTCPNetSyslogServerConfigIF.getKeyStorePassword();
    if ((str2 != null) && (!"".equals(str2.trim())))
      System.setProperty("javax.net.ssl.keyStorePassword", str2);
    String str3 = localSSLTCPNetSyslogServerConfigIF.getTrustStore();
    if ((str3 != null) && (!"".equals(str3.trim())))
      System.setProperty("javax.net.ssl.trustStore", str3);
    String str4 = localSSLTCPNetSyslogServerConfigIF.getTrustStorePassword();
    if ((str4 != null) && (!"".equals(str4.trim())))
      System.setProperty("javax.net.ssl.trustStorePassword", str4);
  }

  protected ServerSocketFactory getServerSocketFactory()
    throws IOException
  {
    ServerSocketFactory localServerSocketFactory = SSLServerSocketFactory.getDefault();
    return localServerSocketFactory;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.ssl.SSLTCPNetSyslogServer
 * JD-Core Version:    0.6.0
 */