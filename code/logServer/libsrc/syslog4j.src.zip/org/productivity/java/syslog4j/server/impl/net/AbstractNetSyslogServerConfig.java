package org.productivity.java.syslog4j.server.impl.net;

import org.productivity.java.syslog4j.server.impl.AbstractSyslogServerConfig;

public abstract class AbstractNetSyslogServerConfig extends AbstractSyslogServerConfig
{
  private static final long serialVersionUID = -3363374941938350263L;
  protected String host = null;
  protected int port = 514;

  public String getHost()
  {
    return this.host;
  }

  public void setHost(String paramString)
  {
    this.host = paramString;
  }

  public int getPort()
  {
    return this.port;
  }

  public void setPort(int paramInt)
  {
    this.port = paramInt;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.AbstractNetSyslogServerConfig
 * JD-Core Version:    0.6.0
 */