package org.productivity.java.syslog4j.impl.net.tcp;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.SocketFactory;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class TCPNetSyslogWriter extends AbstractSyslogWriter
{
  private static final long serialVersionUID = -6388813866108482855L;
  protected TCPNetSyslog tcpNetSyslog = null;
  protected Socket socket = null;
  protected TCPNetSyslogConfigIF tcpNetSyslogConfig = null;
  protected long lastSocketCreationTimeMs = 0L;

  public void initialize(AbstractSyslog paramAbstractSyslog)
  {
    super.initialize(paramAbstractSyslog);
    this.tcpNetSyslog = ((TCPNetSyslog)paramAbstractSyslog);
    this.tcpNetSyslogConfig = ((TCPNetSyslogConfigIF)this.tcpNetSyslog.getConfig());
  }

  protected SocketFactory obtainSocketFactory()
  {
    return SocketFactory.getDefault();
  }

  protected Socket createSocket(InetAddress paramInetAddress, int paramInt, boolean paramBoolean)
    throws IOException
  {
    SocketFactory localSocketFactory = obtainSocketFactory();
    Socket localSocket = localSocketFactory.createSocket(paramInetAddress, paramInt);
    if (this.tcpNetSyslogConfig.isSoLinger())
      localSocket.setSoLinger(true, this.tcpNetSyslogConfig.getSoLingerSeconds());
    if (this.tcpNetSyslogConfig.isKeepAlive())
      localSocket.setKeepAlive(paramBoolean);
    if (this.tcpNetSyslogConfig.isReuseAddress())
      localSocket.setReuseAddress(true);
    return localSocket;
  }

  protected Socket getSocket()
    throws SyslogRuntimeException
  {
    if ((this.socket != null) && (this.socket.isConnected()))
    {
      int i = this.tcpNetSyslogConfig.getFreshConnectionInterval();
      if (i > 0)
      {
        long l = System.currentTimeMillis();
        if (l - this.lastSocketCreationTimeMs >= i)
          closeSocket(this.socket);
      }
      else
      {
        return this.socket;
      }
    }
    if (this.socket == null)
    {
      this.lastSocketCreationTimeMs = 0L;
      try
      {
        InetAddress localInetAddress = this.tcpNetSyslog.getHostAddress();
        this.socket = createSocket(localInetAddress, this.syslog.getConfig().getPort(), this.tcpNetSyslogConfig.isPersistentConnection());
        this.lastSocketCreationTimeMs = System.currentTimeMillis();
      }
      catch (IOException localIOException)
      {
        throw new SyslogRuntimeException(localIOException);
      }
    }
    return this.socket;
  }

  protected void closeSocket(Socket paramSocket)
  {
    if (paramSocket == null)
      return;
    try
    {
      paramSocket.close();
    }
    catch (IOException localIOException)
    {
      if (!"Socket is closed".equalsIgnoreCase(localIOException.getMessage()))
        throw new SyslogRuntimeException(localIOException);
    }
    finally
    {
      if (paramSocket == this.socket)
        this.socket = null;
    }
  }

  public void write(byte[] paramArrayOfByte)
    throws SyslogRuntimeException
  {
    Socket localSocket = null;
    int i = 0;
    while ((i != -1) && (i < this.tcpNetSyslogConfig.getWriteRetries() + 1))
      try
      {
        localSocket = getSocket();
        if (localSocket == null)
          throw new SyslogRuntimeException("No socket available");
        OutputStream localOutputStream = localSocket.getOutputStream();
        if (this.tcpNetSyslogConfig.isSetBufferSize())
          localSocket.setSendBufferSize(paramArrayOfByte.length);
        localOutputStream.write(paramArrayOfByte);
        byte[] arrayOfByte = this.tcpNetSyslogConfig.getDelimiterSequence();
        if ((arrayOfByte != null) && (arrayOfByte.length > 0))
          localOutputStream.write(arrayOfByte);
        this.syslog.setBackLogStatus(false);
        i = -1;
        if (!this.tcpNetSyslogConfig.isPersistentConnection())
          closeSocket(localSocket);
      }
      catch (IOException localIOException)
      {
        i++;
        closeSocket(localSocket);
        if (i >= this.tcpNetSyslogConfig.getWriteRetries() + 1)
          throw new SyslogRuntimeException(localIOException);
      }
  }

  public synchronized void flush()
    throws SyslogRuntimeException
  {
    if (this.socket == null)
      return;
    if (this.syslogConfig.isThreaded())
    {
      shutdown();
      this.syslog.createWriterThread(this);
    }
    else
    {
      closeSocket(this.socket);
    }
  }

  public synchronized void shutdown()
    throws SyslogRuntimeException
  {
    this.shutdown = true;
    if (this.syslogConfig.isThreaded())
    {
      long l1 = System.currentTimeMillis();
      int i = 0;
      while (i == 0)
      {
        if ((this.socket == null) || (this.socket.isClosed()))
        {
          i = 1;
          continue;
        }
        long l2 = System.currentTimeMillis();
        if (l2 > l1 + this.tcpNetSyslogConfig.getMaxShutdownWait())
        {
          closeSocket(this.socket);
          this.thread.interrupt();
          i = 1;
        }
        if (i != 0)
          continue;
        SyslogUtility.sleep(100L);
      }
    }
    if ((this.socket == null) || (this.socket.isClosed()))
      return;
    closeSocket(this.socket);
  }

  protected void runCompleted()
  {
    closeSocket(this.socket);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogWriter
 * JD-Core Version:    0.6.0
 */