package org.productivity.java.syslog4j.util;

public final class OSDetectUtility
{
  private static final String[] UNIX_PLATFORMS = { "Linux", "Mac OS", "Solaris", "SunOS", "MPE/iX", "HP-UX", "AIX", "OS/390", "FreeBSD", "Irix", "Digital Unix", "FreeBSD", "OSF1", "OpenVMS" };
  private static final String[] WINDOWS_PLATFORMS = { "Windows", "OS/2" };
  private static boolean UNIX = false;
  private static boolean WINDOWS = false;

  private static boolean isMatch(String[] paramArrayOfString)
  {
    int i = 0;
    String str1 = System.getProperty("os.name");
    if ((str1 != null) && (!"".equals(str1.trim())))
    {
      str1 = str1.toLowerCase();
      for (int j = 0; j < paramArrayOfString.length; j++)
      {
        String str2 = paramArrayOfString[j].toLowerCase();
        if (str1.indexOf(str2) <= -1)
          continue;
        i = 1;
        break;
      }
    }
    return i;
  }

  public static boolean isUnix()
  {
    return UNIX;
  }

  public static boolean isWindows()
  {
    return WINDOWS;
  }

  static
  {
    UNIX = isMatch(UNIX_PLATFORMS);
    WINDOWS = isMatch(WINDOWS_PLATFORMS);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.util.OSDetectUtility
 * JD-Core Version:    0.6.0
 */