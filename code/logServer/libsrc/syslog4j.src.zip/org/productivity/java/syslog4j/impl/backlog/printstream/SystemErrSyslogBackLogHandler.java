package org.productivity.java.syslog4j.impl.backlog.printstream;

import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;

public class SystemErrSyslogBackLogHandler extends PrintStreamSyslogBackLogHandler
{
  public static final SyslogBackLogHandlerIF create()
  {
    return new SystemErrSyslogBackLogHandler();
  }

  public SystemErrSyslogBackLogHandler()
  {
    super(System.err, true);
  }

  public SystemErrSyslogBackLogHandler(boolean paramBoolean)
  {
    super(System.err, true, paramBoolean);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.printstream.SystemErrSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */