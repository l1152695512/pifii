package org.productivity.java.syslog4j.impl.net.tcp.ssl;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogWriter;

public class SSLTCPNetSyslogWriter extends TCPNetSyslogWriter
{
  private static final long serialVersionUID = 8944446235285662244L;

  protected SocketFactory obtainSocketFactory()
  {
    return SSLSocketFactory.getDefault();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslogWriter
 * JD-Core Version:    0.6.0
 */