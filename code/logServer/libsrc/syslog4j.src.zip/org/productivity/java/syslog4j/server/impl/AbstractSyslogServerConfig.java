package org.productivity.java.syslog4j.server.impl;

import java.util.ArrayList;
import java.util.List;
import org.productivity.java.syslog4j.server.SyslogServerConfigIF;
import org.productivity.java.syslog4j.server.SyslogServerEventHandlerIF;

public abstract class AbstractSyslogServerConfig
  implements SyslogServerConfigIF
{
  private static final long serialVersionUID = 870248648801259856L;
  protected String charSet = "UTF-8";
  protected long shutdownWait = 500L;
  protected List eventHandlers = new ArrayList();
  protected boolean useStructuredData = false;
  protected Object dateTimeFormatter = null;
  protected boolean useDaemonThread = true;
  protected int threadPriority = -1;

  public abstract Class getSyslogServerClass();

  public String getCharSet()
  {
    return this.charSet;
  }

  public void setCharSet(String paramString)
  {
    this.charSet = paramString;
  }

  public long getShutdownWait()
  {
    return this.shutdownWait;
  }

  public void setShutdownWait(long paramLong)
  {
    this.shutdownWait = paramLong;
  }

  public List getEventHandlers()
  {
    return this.eventHandlers;
  }

  public void addEventHandler(SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF)
  {
    this.eventHandlers.add(paramSyslogServerEventHandlerIF);
  }

  public void insertEventHandler(int paramInt, SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF)
  {
    this.eventHandlers.add(paramInt, paramSyslogServerEventHandlerIF);
  }

  public void removeEventHandler(SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF)
  {
    this.eventHandlers.remove(paramSyslogServerEventHandlerIF);
  }

  public void removeAllEventHandlers()
  {
    this.eventHandlers.clear();
  }

  public boolean isUseStructuredData()
  {
    return this.useStructuredData;
  }

  public void setUseStructuredData(boolean paramBoolean)
  {
    this.useStructuredData = paramBoolean;
  }

  public boolean isUseDaemonThread()
  {
    return this.useDaemonThread;
  }

  public Object getDateTimeFormatter()
  {
    return this.dateTimeFormatter;
  }

  public void setDateTimeFormatter(Object paramObject)
  {
    this.dateTimeFormatter = paramObject;
  }

  public void setUseDaemonThread(boolean paramBoolean)
  {
    this.useDaemonThread = paramBoolean;
  }

  public int getThreadPriority()
  {
    return this.threadPriority;
  }

  public void setThreadPriority(int paramInt)
  {
    this.threadPriority = paramInt;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.AbstractSyslogServerConfig
 * JD-Core Version:    0.6.0
 */