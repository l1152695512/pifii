package org.productivity.java.syslog4j.impl;

import java.util.ArrayList;
import java.util.List;
import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.backlog.printstream.SystemErrSyslogBackLogHandler;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractSyslogConfig
  implements AbstractSyslogConfigIF
{
  private static final long serialVersionUID = -3728308557871358111L;
  protected static final List defaultBackLogHandlers = new ArrayList();
  protected int facility = 8;
  protected String charSet = "UTF-8";
  protected String ident = "";
  protected String localName = null;
  protected boolean sendLocalTimestamp = true;
  protected boolean sendLocalName = true;
  protected boolean includeIdentInMessageModifier = false;
  protected boolean throwExceptionOnWrite = false;
  protected boolean throwExceptionOnInitialize = true;
  protected int maxMessageLength = 1024;
  protected byte[] splitMessageBeginText = "...".getBytes();
  protected byte[] splitMessageEndText = "...".getBytes();
  protected List messageModifiers = null;
  protected List backLogHandlers = null;
  protected boolean threaded = true;
  protected boolean useDaemonThread = true;
  protected int threadPriority = -1;
  protected long threadLoopInterval = 500L;
  protected int writeRetries = 2;
  protected long maxShutdownWait = 30000L;
  protected boolean truncateMessage = false;
  protected boolean useStructuredData = false;

  public abstract Class getSyslogClass();

  public String getCharSet()
  {
    return this.charSet;
  }

  public void setCharSet(String paramString)
  {
    this.charSet = paramString;
  }

  public String getLocalName()
  {
    return this.localName;
  }

  public void setLocalName(String paramString)
  {
    this.localName = paramString;
  }

  public boolean isThrowExceptionOnWrite()
  {
    return this.throwExceptionOnWrite;
  }

  public void setThrowExceptionOnWrite(boolean paramBoolean)
  {
    this.throwExceptionOnWrite = paramBoolean;
  }

  public boolean isThrowExceptionOnInitialize()
  {
    return this.throwExceptionOnInitialize;
  }

  public void setThrowExceptionOnInitialize(boolean paramBoolean)
  {
    this.throwExceptionOnInitialize = paramBoolean;
  }

  public byte[] getSplitMessageBeginText()
  {
    return this.splitMessageBeginText;
  }

  public void setSplitMessageBeginText(byte[] paramArrayOfByte)
  {
    this.splitMessageBeginText = paramArrayOfByte;
  }

  public void setSplitMessageBeginText(String paramString)
    throws SyslogRuntimeException
  {
    this.splitMessageBeginText = SyslogUtility.getBytes(this, paramString);
  }

  public byte[] getSplitMessageEndText()
  {
    return this.splitMessageEndText;
  }

  public void setSplitMessageEndText(byte[] paramArrayOfByte)
  {
    this.splitMessageEndText = paramArrayOfByte;
  }

  public void setSplitMessageEndText(String paramString)
    throws SyslogRuntimeException
  {
    this.splitMessageEndText = SyslogUtility.getBytes(this, paramString);
  }

  public int getMaxMessageLength()
  {
    return this.maxMessageLength;
  }

  public void setMaxMessageLength(int paramInt)
  {
    this.maxMessageLength = paramInt;
  }

  public boolean isSendLocalTimestamp()
  {
    return this.sendLocalTimestamp;
  }

  public void setSendLocalTimestamp(boolean paramBoolean)
  {
    this.sendLocalTimestamp = paramBoolean;
  }

  public boolean isSendLocalName()
  {
    return this.sendLocalName;
  }

  public void setSendLocalName(boolean paramBoolean)
  {
    this.sendLocalName = paramBoolean;
  }

  public int getFacility()
  {
    return this.facility;
  }

  public void setFacility(int paramInt)
  {
    this.facility = paramInt;
  }

  public void setFacility(String paramString)
  {
    this.facility = SyslogUtility.getFacility(paramString);
  }

  public String getIdent()
  {
    return this.ident;
  }

  public void setIdent(String paramString)
  {
    this.ident = paramString;
  }

  protected synchronized List _getMessageModifiers()
  {
    if (this.messageModifiers == null)
      this.messageModifiers = new ArrayList();
    return this.messageModifiers;
  }

  public void addMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    if (paramSyslogMessageModifierIF == null)
      return;
    List localList = _getMessageModifiers();
    synchronized (localList)
    {
      localList.add(paramSyslogMessageModifierIF);
    }
  }

  public void insertMessageModifier(int paramInt, SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    if (paramSyslogMessageModifierIF == null)
      return;
    List localList = _getMessageModifiers();
    synchronized (localList)
    {
      try
      {
        localList.add(paramInt, paramSyslogMessageModifierIF);
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
      {
        throw new SyslogRuntimeException(localIndexOutOfBoundsException);
      }
    }
  }

  public void removeMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    if (paramSyslogMessageModifierIF == null)
      return;
    List localList = _getMessageModifiers();
    synchronized (localList)
    {
      localList.remove(paramSyslogMessageModifierIF);
    }
  }

  public List getMessageModifiers()
  {
    return this.messageModifiers;
  }

  public void setMessageModifiers(List paramList)
  {
    this.messageModifiers = paramList;
  }

  public void removeAllMessageModifiers()
  {
    if ((this.messageModifiers == null) || (this.messageModifiers.isEmpty()))
      return;
    this.messageModifiers.clear();
  }

  protected synchronized List _getBackLogHandlers()
  {
    if (this.backLogHandlers == null)
      this.backLogHandlers = new ArrayList();
    return this.backLogHandlers;
  }

  public void addBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    if (paramSyslogBackLogHandlerIF == null)
      return;
    List localList = _getBackLogHandlers();
    synchronized (localList)
    {
      paramSyslogBackLogHandlerIF.initialize();
      localList.add(paramSyslogBackLogHandlerIF);
    }
  }

  public void insertBackLogHandler(int paramInt, SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    if (paramSyslogBackLogHandlerIF == null)
      return;
    List localList = _getBackLogHandlers();
    synchronized (localList)
    {
      try
      {
        paramSyslogBackLogHandlerIF.initialize();
        localList.add(paramInt, paramSyslogBackLogHandlerIF);
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
      {
        throw new SyslogRuntimeException(localIndexOutOfBoundsException);
      }
    }
  }

  public void removeBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    if (paramSyslogBackLogHandlerIF == null)
      return;
    List localList = _getBackLogHandlers();
    synchronized (localList)
    {
      localList.remove(paramSyslogBackLogHandlerIF);
    }
  }

  public List getBackLogHandlers()
  {
    if ((this.backLogHandlers == null) || (this.backLogHandlers.size() < 1))
      return defaultBackLogHandlers;
    return this.backLogHandlers;
  }

  public void setBackLogHandlers(List paramList)
  {
    this.backLogHandlers = paramList;
  }

  public void removeAllBackLogHandlers()
  {
    if ((this.backLogHandlers == null) || (this.backLogHandlers.isEmpty()))
      return;
    this.backLogHandlers.clear();
  }

  public boolean isIncludeIdentInMessageModifier()
  {
    return this.includeIdentInMessageModifier;
  }

  public void setIncludeIdentInMessageModifier(boolean paramBoolean)
  {
    this.includeIdentInMessageModifier = paramBoolean;
  }

  public boolean isThreaded()
  {
    return this.threaded;
  }

  public void setThreaded(boolean paramBoolean)
  {
    this.threaded = paramBoolean;
  }

  public boolean isUseDaemonThread()
  {
    return this.useDaemonThread;
  }

  public void setUseDaemonThread(boolean paramBoolean)
  {
    this.useDaemonThread = paramBoolean;
  }

  public int getThreadPriority()
  {
    return this.threadPriority;
  }

  public void setThreadPriority(int paramInt)
  {
    this.threadPriority = paramInt;
  }

  public long getThreadLoopInterval()
  {
    return this.threadLoopInterval;
  }

  public void setThreadLoopInterval(long paramLong)
  {
    this.threadLoopInterval = paramLong;
  }

  public long getMaxShutdownWait()
  {
    return this.maxShutdownWait;
  }

  public void setMaxShutdownWait(long paramLong)
  {
    this.maxShutdownWait = paramLong;
  }

  public int getWriteRetries()
  {
    return this.writeRetries;
  }

  public void setWriteRetries(int paramInt)
  {
    this.writeRetries = paramInt;
  }

  public boolean isTruncateMessage()
  {
    return this.truncateMessage;
  }

  public void setTruncateMessage(boolean paramBoolean)
  {
    this.truncateMessage = paramBoolean;
  }

  public boolean isUseStructuredData()
  {
    return this.useStructuredData;
  }

  public void setUseStructuredData(boolean paramBoolean)
  {
    this.useStructuredData = paramBoolean;
  }

  public Class getSyslogWriterClass()
  {
    return null;
  }

  static
  {
    defaultBackLogHandlers.add(new SystemErrSyslogBackLogHandler());
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.AbstractSyslogConfig
 * JD-Core Version:    0.6.0
 */