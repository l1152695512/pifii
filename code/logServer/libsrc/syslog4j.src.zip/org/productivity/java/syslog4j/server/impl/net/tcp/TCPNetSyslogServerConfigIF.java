package org.productivity.java.syslog4j.server.impl.net.tcp;

import org.productivity.java.syslog4j.server.SyslogServerConfigIF;

public abstract interface TCPNetSyslogServerConfigIF extends SyslogServerConfigIF
{
  public static final byte MAX_ACTIVE_SOCKETS_BEHAVIOR_BLOCK = 0;
  public static final byte MAX_ACTIVE_SOCKETS_BEHAVIOR_REJECT = 1;

  public abstract int getTimeout();

  public abstract void setTimeout(int paramInt);

  public abstract int getBacklog();

  public abstract void setBacklog(int paramInt);

  public abstract int getMaxActiveSockets();

  public abstract void setMaxActiveSockets(int paramInt);

  public abstract byte getMaxActiveSocketsBehavior();

  public abstract void setMaxActiveSocketsBehavior(byte paramByte);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfigIF
 * JD-Core Version:    0.6.0
 */