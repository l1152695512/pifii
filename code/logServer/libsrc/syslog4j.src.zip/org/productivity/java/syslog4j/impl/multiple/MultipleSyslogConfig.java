package org.productivity.java.syslog4j.impl.multiple;

import java.util.ArrayList;
import java.util.List;
import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public class MultipleSyslogConfig
  implements SyslogConfigIF
{
  private static final long serialVersionUID = 753704522364959612L;
  protected List syslogProtocols = null;

  public MultipleSyslogConfig()
  {
    this.syslogProtocols = new ArrayList();
  }

  public MultipleSyslogConfig(List paramList)
  {
    if (paramList != null)
      this.syslogProtocols = paramList;
    else
      this.syslogProtocols = new ArrayList();
  }

  public MultipleSyslogConfig(String[] paramArrayOfString)
  {
    if (paramArrayOfString != null)
    {
      this.syslogProtocols = new ArrayList(paramArrayOfString.length);
      for (int i = 0; i < paramArrayOfString.length; i++)
        this.syslogProtocols.add(paramArrayOfString[i]);
    }
    this.syslogProtocols = new ArrayList();
  }

  public List getProtocols()
  {
    return this.syslogProtocols;
  }

  public void addProtocol(String paramString)
  {
    this.syslogProtocols.add(paramString);
  }

  public void insertProtocol(int paramInt, String paramString)
  {
    this.syslogProtocols.add(paramInt, paramString);
  }

  public void removeProtocol(String paramString)
  {
    this.syslogProtocols.remove(paramString);
  }

  public void removeAllProtocols()
  {
    this.syslogProtocols.clear();
  }

  public void addBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void addMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public Class getSyslogClass()
  {
    return MultipleSyslog.class;
  }

  public String getCharSet()
  {
    return "UTF-8";
  }

  public int getFacility()
  {
    return 8;
  }

  public String getHost()
  {
    return "localhost";
  }

  public String getIdent()
  {
    return null;
  }

  public String getLocalName()
  {
    return null;
  }

  public int getPort()
  {
    return 514;
  }

  public int getMaxShutdownWait()
  {
    return 30000;
  }

  public void setMaxShutdownWait(int paramInt)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void insertBackLogHandler(int paramInt, SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void insertMessageModifier(int paramInt, SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public boolean isCacheHostAddress()
  {
    return true;
  }

  public boolean isIncludeIdentInMessageModifier()
  {
    return false;
  }

  public boolean isSendLocalName()
  {
    return true;
  }

  public boolean isSendLocalTimestamp()
  {
    return true;
  }

  public boolean isThrowExceptionOnInitialize()
  {
    return true;
  }

  public boolean isThrowExceptionOnWrite()
  {
    return false;
  }

  public void removeAllBackLogHandlers()
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void removeAllMessageModifiers()
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void removeBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void removeMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setCacheHostAddress(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setCharSet(String paramString)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setFacility(int paramInt)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setFacility(String paramString)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setHost(String paramString)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setIdent(String paramString)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setLocalName(String paramString)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setIncludeIdentInMessageModifier(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setPort(int paramInt)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setSendLocalName(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setSendLocalTimestamp(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setThrowExceptionOnInitialize(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setThrowExceptionOnWrite(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public int getMaxMessageLength()
  {
    return 1024;
  }

  public void setMaxMessageLength(int paramInt)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public boolean isTruncateMessage()
  {
    return false;
  }

  public void setTruncateMessage(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public boolean isUseStructuredData()
  {
    return false;
  }

  public void setUseStructuredData(boolean paramBoolean)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.multiple.MultipleSyslogConfig
 * JD-Core Version:    0.6.0
 */