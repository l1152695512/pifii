package org.productivity.java.syslog4j.impl.backlog;

import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractSyslogBackLogHandler
  implements SyslogBackLogHandlerIF
{
  protected boolean appendReason = true;

  protected String combine(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
  {
    String str1 = paramString1 != null ? paramString1 : "UNKNOWN";
    String str2 = paramString2 != null ? paramString2 : "UNKNOWN";
    String str3 = SyslogUtility.getLevelString(paramInt) + " " + str1;
    if (this.appendReason)
      str3 = str3 + " [" + str2 + "]";
    return str3;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.AbstractSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */