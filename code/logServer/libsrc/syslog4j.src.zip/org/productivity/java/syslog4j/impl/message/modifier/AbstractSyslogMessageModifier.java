package org.productivity.java.syslog4j.impl.message.modifier;

import org.productivity.java.syslog4j.SyslogMessageModifierConfigIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;

public abstract class AbstractSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = 7632959170109372003L;
  protected SyslogMessageModifierConfigIF messageModifierConfig = null;

  public AbstractSyslogMessageModifier(SyslogMessageModifierConfigIF paramSyslogMessageModifierConfigIF)
  {
    this.messageModifierConfig = paramSyslogMessageModifierConfigIF;
  }

  public String[] parseInlineModifier(String paramString)
  {
    return parseInlineModifier(paramString, this.messageModifierConfig.getPrefix(), this.messageModifierConfig.getSuffix());
  }

  public static String[] parseInlineModifier(String paramString1, String paramString2, String paramString3)
  {
    String[] arrayOfString = null;
    if ((paramString1 == null) || ("".equals(paramString1.trim())))
      return null;
    if ((paramString2 == null) || ("".equals(paramString2)))
      paramString2 = " ";
    int i;
    if ((paramString3 == null) || ("".equals(paramString3)))
    {
      i = paramString1.lastIndexOf(paramString2);
      if (i > -1)
        arrayOfString = new String[] { paramString1.substring(0, i), paramString1.substring(i + paramString2.length()) };
    }
    else
    {
      i = paramString1.lastIndexOf(paramString3);
      if (i > -1)
      {
        int j = paramString1.lastIndexOf(paramString2, i);
        if (j > -1)
          arrayOfString = new String[] { paramString1.substring(0, j), paramString1.substring(j + paramString2.length(), i) };
      }
    }
    return arrayOfString;
  }

  protected abstract boolean verify(String paramString1, String paramString2);

  public boolean verify(String paramString)
  {
    String[] arrayOfString = parseInlineModifier(paramString);
    if ((arrayOfString == null) || (arrayOfString.length != 2))
      return false;
    return verify(arrayOfString[0], arrayOfString[1]);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */