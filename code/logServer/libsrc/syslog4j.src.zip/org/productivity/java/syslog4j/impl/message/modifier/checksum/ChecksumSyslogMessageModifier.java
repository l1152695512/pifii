package org.productivity.java.syslog4j.impl.message.modifier.checksum;

import java.util.zip.Checksum;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifier;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class ChecksumSyslogMessageModifier extends AbstractSyslogMessageModifier
{
  private static final long serialVersionUID = -3268914290497005065L;
  protected ChecksumSyslogMessageModifierConfig config = null;

  public static final ChecksumSyslogMessageModifier createCRC32()
  {
    ChecksumSyslogMessageModifier localChecksumSyslogMessageModifier = new ChecksumSyslogMessageModifier(ChecksumSyslogMessageModifierConfig.createCRC32());
    return localChecksumSyslogMessageModifier;
  }

  public static final ChecksumSyslogMessageModifier createADLER32()
  {
    ChecksumSyslogMessageModifier localChecksumSyslogMessageModifier = new ChecksumSyslogMessageModifier(ChecksumSyslogMessageModifierConfig.createADLER32());
    return localChecksumSyslogMessageModifier;
  }

  public ChecksumSyslogMessageModifier(ChecksumSyslogMessageModifierConfig paramChecksumSyslogMessageModifierConfig)
  {
    super(paramChecksumSyslogMessageModifierConfig);
    this.config = paramChecksumSyslogMessageModifierConfig;
    if (this.config == null)
      throw new SyslogRuntimeException("Checksum config object cannot be null");
    if (this.config.getChecksum() == null)
      throw new SyslogRuntimeException("Checksum object cannot be null");
  }

  public ChecksumSyslogMessageModifierConfig getConfig()
  {
    return this.config;
  }

  protected void continuousCheckForVerify()
  {
    if (this.config.isContinuous())
      throw new SyslogRuntimeException(getClass().getName() + ".verify(..) does not work with isContinuous() returning true");
  }

  public boolean verify(String paramString1, String paramString2)
  {
    continuousCheckForVerify();
    long l = Long.parseLong(paramString2, 16);
    return verify(paramString1, l);
  }

  public boolean verify(String paramString, long paramLong)
  {
    continuousCheckForVerify();
    synchronized (this.config.getChecksum())
    {
      this.config.getChecksum().reset();
      byte[] arrayOfByte = SyslogUtility.getBytes(this.config, paramString);
      this.config.getChecksum().update(arrayOfByte, 0, paramString.length());
      return this.config.getChecksum().getValue() == paramLong;
    }
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    synchronized (this.config.getChecksum())
    {
      StringBuffer localStringBuffer = new StringBuffer(paramString);
      byte[] arrayOfByte = SyslogUtility.getBytes(paramSyslogIF.getConfig(), paramString);
      if (!this.config.isContinuous())
        this.config.getChecksum().reset();
      this.config.getChecksum().update(arrayOfByte, 0, paramString.length());
      localStringBuffer.append(this.config.getPrefix());
      localStringBuffer.append(Long.toHexString(this.config.getChecksum().getValue()).toUpperCase());
      localStringBuffer.append(this.config.getSuffix());
      return localStringBuffer.toString();
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.checksum.ChecksumSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */