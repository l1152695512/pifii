package org.productivity.java.syslog4j.impl.net.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.impl.net.AbstractNetSyslog;
import org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfigIF;

public class UDPNetSyslog extends AbstractNetSyslog
{
  private static final long serialVersionUID = 5259485504549037999L;
  protected DatagramSocket socket = null;

  public void initialize()
    throws SyslogRuntimeException
  {
    super.initialize();
    createDatagramSocket(true);
  }

  protected synchronized void createDatagramSocket(boolean paramBoolean)
  {
    try
    {
      this.socket = new DatagramSocket();
    }
    catch (SocketException localSocketException)
    {
      if (paramBoolean)
      {
        if (this.syslogConfig.isThrowExceptionOnInitialize())
          throw new SyslogRuntimeException(localSocketException);
      }
      else
        throw new SyslogRuntimeException(localSocketException);
    }
    if (this.socket == null)
      throw new SyslogRuntimeException("Cannot seem to get a Datagram socket");
  }

  protected void write(int paramInt, byte[] paramArrayOfByte)
    throws SyslogRuntimeException
  {
    if (this.socket == null)
      createDatagramSocket(false);
    InetAddress localInetAddress = getHostAddress();
    DatagramPacket localDatagramPacket = new DatagramPacket(paramArrayOfByte, paramArrayOfByte.length, localInetAddress, this.syslogConfig.getPort());
    int i = 0;
    while ((i != -1) && (i < this.netSyslogConfig.getWriteRetries() + 1))
      try
      {
        this.socket.send(localDatagramPacket);
        i = -1;
      }
      catch (IOException localIOException)
      {
        if (i == this.netSyslogConfig.getWriteRetries() + 1)
          throw new SyslogRuntimeException(localIOException);
      }
  }

  public void flush()
    throws SyslogRuntimeException
  {
    shutdown();
    createDatagramSocket(true);
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    if (this.socket != null)
    {
      this.socket.close();
      this.socket = null;
    }
  }

  public AbstractSyslogWriter getWriter()
  {
    return null;
  }

  public void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.udp.UDPNetSyslog
 * JD-Core Version:    0.6.0
 */