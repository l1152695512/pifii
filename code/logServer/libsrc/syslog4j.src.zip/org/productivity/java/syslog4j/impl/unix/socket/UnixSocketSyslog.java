package org.productivity.java.syslog4j.impl.unix.socket;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Structure;
import java.nio.ByteBuffer;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.util.OSDetectUtility;

public class UnixSocketSyslog extends AbstractSyslog
{
  private static final long serialVersionUID = 39878807911936785L;
  protected boolean libraryLoaded = false;
  protected CLibrary libraryInstance = null;
  protected UnixSocketSyslogConfig unixSocketSyslogConfig = null;
  protected int fd = -1;

  protected synchronized void loadLibrary()
  {
    if (!OSDetectUtility.isUnix())
      throw new SyslogRuntimeException("UnixSyslog not supported on non-Unix platforms");
    if (!this.libraryLoaded)
    {
      this.libraryInstance = ((CLibrary)Native.loadLibrary(this.unixSocketSyslogConfig.getLibrary(), CLibrary.class));
      this.libraryLoaded = true;
    }
  }

  public void initialize()
    throws SyslogRuntimeException
  {
    try
    {
      this.unixSocketSyslogConfig = ((UnixSocketSyslogConfig)this.syslogConfig);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must be of type UnixSocketSyslogConfig");
    }
    loadLibrary();
  }

  protected synchronized void connect()
  {
    if (this.fd != -1)
      return;
    this.fd = this.libraryInstance.socket(this.unixSocketSyslogConfig.getFamily(), this.unixSocketSyslogConfig.getType(), this.unixSocketSyslogConfig.getProtocol());
    if (this.fd == -1)
    {
      this.fd = -1;
      return;
    }
    SockAddr localSockAddr = new SockAddr();
    localSockAddr.sun_family = this.unixSocketSyslogConfig.getFamily();
    localSockAddr.setSunPath(this.unixSocketSyslogConfig.getPath());
    int i = this.libraryInstance.connect(this.fd, localSockAddr, localSockAddr.size());
    if (i == -1)
    {
      this.fd = -1;
      return;
    }
  }

  protected void write(int paramInt, byte[] paramArrayOfByte)
    throws SyslogRuntimeException
  {
    if (this.fd == -1)
      connect();
    if (this.fd == -1)
      return;
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    this.libraryInstance.write(this.fd, localByteBuffer, paramArrayOfByte.length);
  }

  public void flush()
    throws SyslogRuntimeException
  {
    shutdown();
    this.fd = this.libraryInstance.socket(this.unixSocketSyslogConfig.getFamily(), this.unixSocketSyslogConfig.getType(), this.unixSocketSyslogConfig.getProtocol());
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    if (this.fd == -1)
      return;
    this.libraryInstance.close(this.fd);
    this.fd = -1;
  }

  public AbstractSyslogWriter getWriter()
  {
    return null;
  }

  public void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
  }

  protected static abstract interface CLibrary extends Library
  {
    public abstract int socket(int paramInt1, int paramInt2, int paramInt3);

    public abstract int connect(int paramInt1, UnixSocketSyslog.SockAddr paramSockAddr, int paramInt2);

    public abstract int write(int paramInt1, ByteBuffer paramByteBuffer, int paramInt2);

    public abstract int close(int paramInt);

    public abstract String strerror(int paramInt);
  }

  protected static class SockAddr extends Structure
  {
    public static final int SUN_PATH_SIZE = 108;
    public static final byte[] ZERO_BYTE = { 0 };
    public short sun_family = 1;
    public byte[] sun_path = new byte[108];

    public void setSunPath(String paramString)
    {
      System.arraycopy(paramString.getBytes(), 0, this.sun_path, 0, paramString.length());
      System.arraycopy(ZERO_BYTE, 0, this.sun_path, paramString.length(), 1);
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.unix.socket.UnixSocketSyslog
 * JD-Core Version:    0.6.0
 */