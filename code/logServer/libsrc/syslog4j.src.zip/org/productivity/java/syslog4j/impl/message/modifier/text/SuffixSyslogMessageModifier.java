package org.productivity.java.syslog4j.impl.message.modifier.text;

import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;

public class SuffixSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = 7160593302741507576L;
  protected String suffix = null;
  protected String delimiter = " ";

  public SuffixSyslogMessageModifier()
  {
  }

  public SuffixSyslogMessageModifier(String paramString)
  {
    this.suffix = paramString;
  }

  public SuffixSyslogMessageModifier(String paramString1, String paramString2)
  {
    this.suffix = paramString1;
    if (paramString2 != null)
      this.delimiter = paramString2;
  }

  public String getSuffix()
  {
    return this.suffix;
  }

  public void setSuffix(String paramString)
  {
    this.suffix = paramString;
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    if ((this.suffix == null) || ("".equals(this.suffix.trim())))
      return paramString;
    return paramString + this.delimiter + this.suffix;
  }

  public boolean verify(String paramString)
  {
    return true;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.text.SuffixSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */