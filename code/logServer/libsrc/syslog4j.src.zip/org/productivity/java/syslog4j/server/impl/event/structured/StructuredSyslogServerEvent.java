package org.productivity.java.syslog4j.server.impl.event.structured;

import java.net.InetAddress;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessage;
import org.productivity.java.syslog4j.server.impl.event.SyslogServerEvent;

public class StructuredSyslogServerEvent extends SyslogServerEvent
{
  private static final long serialVersionUID = 1676499796406044315L;
  protected String applicationName = "unknown";
  protected String processId = null;
  protected DateTime dateTime = null;
  protected DateTimeFormatter dateTimeFormatter = null;

  public StructuredSyslogServerEvent(byte[] paramArrayOfByte, int paramInt, InetAddress paramInetAddress)
  {
    initialize(paramArrayOfByte, paramInt, paramInetAddress);
    parse();
  }

  public StructuredSyslogServerEvent(String paramString, InetAddress paramInetAddress)
  {
    initialize(paramString, paramInetAddress);
    parse();
  }

  public DateTimeFormatter getDateTimeFormatter()
  {
    if (this.dateTimeFormatter == null)
      this.dateTimeFormatter = ISODateTimeFormat.dateTime();
    return this.dateTimeFormatter;
  }

  public void setDateTimeFormatter(Object paramObject)
  {
    this.dateTimeFormatter = ((DateTimeFormatter)paramObject);
  }

  protected void parseApplicationName()
  {
    int i = this.message.indexOf(' ');
    if (i > -1)
    {
      this.applicationName = this.message.substring(0, i).trim();
      this.message = this.message.substring(i + 1);
      parseProcessId();
    }
    if ("-".equals(this.applicationName))
      this.applicationName = null;
  }

  protected void parseProcessId()
  {
    int i = this.message.indexOf(' ');
    if (i > -1)
    {
      this.processId = this.message.substring(0, i).trim();
      this.message = this.message.substring(i + 1);
    }
    if ("-".equals(this.processId))
      this.processId = null;
  }

  protected void parseDate()
  {
    int i = this.message.indexOf(' ');
    this.message = this.message.substring(i + 1);
    i = this.message.indexOf(' ');
    if (i > -1)
    {
      String str = this.message.substring(0, i).trim();
      try
      {
        DateTimeFormatter localDateTimeFormatter = getDateTimeFormatter();
        this.dateTime = localDateTimeFormatter.parseDateTime(str);
        this.date = this.dateTime.toDate();
        this.message = this.message.substring(str.length() + 1);
      }
      catch (Exception localException)
      {
        super.parseDate();
      }
    }
  }

  protected void parseHost()
  {
    int i = this.message.indexOf(' ');
    if (i > -1)
    {
      this.host = this.message.substring(0, i).trim();
      this.message = this.message.substring(i + 1);
      parseApplicationName();
    }
  }

  public String getApplicationName()
  {
    return this.applicationName;
  }

  public String getProcessId()
  {
    return this.processId;
  }

  public DateTime getDateTime()
  {
    return this.dateTime;
  }

  public StructuredSyslogMessage getStructuredMessage()
  {
    try
    {
      return StructuredSyslogMessage.fromString(getMessage());
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    return new StructuredSyslogMessage(null, null, getMessage());
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.event.structured.StructuredSyslogServerEvent
 * JD-Core Version:    0.6.0
 */