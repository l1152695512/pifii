package org.productivity.java.syslog4j.impl;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractSyslogWriter
  implements Runnable, Serializable
{
  private static final long serialVersionUID = 836468466009035847L;
  protected AbstractSyslog syslog = null;
  protected List queuedMessages = null;
  protected Thread thread = null;
  protected AbstractSyslogConfigIF syslogConfig = null;
  protected boolean shutdown = false;

  public void initialize(AbstractSyslog paramAbstractSyslog)
  {
    this.syslog = paramAbstractSyslog;
    try
    {
      this.syslogConfig = ((AbstractSyslogConfigIF)this.syslog.getConfig());
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must implement interface AbstractSyslogConfigIF");
    }
    if (this.syslogConfig.isThreaded())
      this.queuedMessages = new LinkedList();
  }

  public void queue(int paramInt, byte[] paramArrayOfByte)
  {
    synchronized (this.queuedMessages)
    {
      if ((this.syslogConfig.getMaxQueueSize() == -1) || (this.queuedMessages.size() < this.syslogConfig.getMaxQueueSize()))
        this.queuedMessages.add(paramArrayOfByte);
      else
        this.syslog.backLog(paramInt, SyslogUtility.newString(this.syslogConfig, paramArrayOfByte), "MaxQueueSize (" + this.syslogConfig.getMaxQueueSize() + ") reached");
    }
  }

  public void setThread(Thread paramThread)
  {
    this.thread = paramThread;
  }

  public boolean hasThread()
  {
    return (this.thread != null) && (this.thread.isAlive());
  }

  public abstract void write(byte[] paramArrayOfByte);

  public abstract void flush();

  public abstract void shutdown();

  protected abstract void runCompleted();

  public void run()
  {
    while ((!this.shutdown) || (!this.queuedMessages.isEmpty()))
    {
      LinkedList localLinkedList = null;
      synchronized (this.queuedMessages)
      {
        localLinkedList = new LinkedList(this.queuedMessages);
        this.queuedMessages.clear();
      }
      if (localLinkedList != null)
        while (!localLinkedList.isEmpty())
        {
          ??? = (byte[])localLinkedList.remove(0);
          try
          {
            write(???);
            this.syslog.setBackLogStatus(false);
          }
          catch (SyslogRuntimeException localSyslogRuntimeException)
          {
            this.syslog.backLog(6, SyslogUtility.newString(this.syslog.getConfig(), ???), localSyslogRuntimeException);
          }
        }
      SyslogUtility.sleep(this.syslogConfig.getThreadLoopInterval());
    }
    runCompleted();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.AbstractSyslogWriter
 * JD-Core Version:    0.6.0
 */