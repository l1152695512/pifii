package org.productivity.java.syslog4j.impl.message.modifier.hash;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifier;
import org.productivity.java.syslog4j.util.Base64;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class HashSyslogMessageModifier extends AbstractSyslogMessageModifier
{
  private static final long serialVersionUID = 7335757344826206953L;
  protected HashSyslogMessageModifierConfig config = null;

  public static final HashSyslogMessageModifier createMD5()
  {
    HashSyslogMessageModifier localHashSyslogMessageModifier = new HashSyslogMessageModifier(HashSyslogMessageModifierConfig.createMD5());
    return localHashSyslogMessageModifier;
  }

  public static final HashSyslogMessageModifier createSHA1()
  {
    HashSyslogMessageModifier localHashSyslogMessageModifier = new HashSyslogMessageModifier(HashSyslogMessageModifierConfig.createSHA1());
    return localHashSyslogMessageModifier;
  }

  public static final HashSyslogMessageModifier createSHA160()
  {
    return createSHA1();
  }

  public static final HashSyslogMessageModifier createSHA256()
  {
    HashSyslogMessageModifier localHashSyslogMessageModifier = new HashSyslogMessageModifier(HashSyslogMessageModifierConfig.createSHA256());
    return localHashSyslogMessageModifier;
  }

  public static final HashSyslogMessageModifier createSHA384()
  {
    HashSyslogMessageModifier localHashSyslogMessageModifier = new HashSyslogMessageModifier(HashSyslogMessageModifierConfig.createSHA384());
    return localHashSyslogMessageModifier;
  }

  public static final HashSyslogMessageModifier createSHA512()
  {
    HashSyslogMessageModifier localHashSyslogMessageModifier = new HashSyslogMessageModifier(HashSyslogMessageModifierConfig.createSHA512());
    return localHashSyslogMessageModifier;
  }

  public HashSyslogMessageModifier(HashSyslogMessageModifierConfig paramHashSyslogMessageModifierConfig)
    throws SyslogRuntimeException
  {
    super(paramHashSyslogMessageModifierConfig);
    this.config = paramHashSyslogMessageModifierConfig;
    if (this.config == null)
      throw new SyslogRuntimeException("Hash config object cannot be null");
    if (this.config.getHashAlgorithm() == null)
      throw new SyslogRuntimeException("Hash algorithm cannot be null");
    try
    {
      MessageDigest.getInstance(paramHashSyslogMessageModifierConfig.getHashAlgorithm());
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new SyslogRuntimeException(localNoSuchAlgorithmException);
    }
  }

  protected MessageDigest obtainMessageDigest()
  {
    MessageDigest localMessageDigest = null;
    try
    {
      localMessageDigest = MessageDigest.getInstance(this.config.getHashAlgorithm());
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new SyslogRuntimeException(localNoSuchAlgorithmException);
    }
    return localMessageDigest;
  }

  public HashSyslogMessageModifierConfig getConfig()
  {
    return this.config;
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    byte[] arrayOfByte1 = SyslogUtility.getBytes(paramSyslogIF.getConfig(), paramString);
    MessageDigest localMessageDigest = obtainMessageDigest();
    byte[] arrayOfByte2 = localMessageDigest.digest(arrayOfByte1);
    String str = Base64.encodeBytes(arrayOfByte2, 8);
    StringBuffer localStringBuffer = new StringBuffer(paramString);
    localStringBuffer.append(this.config.getPrefix());
    localStringBuffer.append(str);
    localStringBuffer.append(this.config.getSuffix());
    return localStringBuffer.toString();
  }

  public boolean verify(String paramString1, String paramString2)
  {
    byte[] arrayOfByte = Base64.decode(paramString2);
    return verify(paramString1, arrayOfByte);
  }

  public boolean verify(String paramString, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte1 = SyslogUtility.getBytes(this.config, paramString);
    MessageDigest localMessageDigest = obtainMessageDigest();
    byte[] arrayOfByte2 = localMessageDigest.digest(arrayOfByte1);
    return Arrays.equals(arrayOfByte2, paramArrayOfByte);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.hash.HashSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */