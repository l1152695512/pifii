package org.productivity.java.syslog4j;

import java.io.Serializable;

public abstract interface SyslogMessageProcessorIF extends Serializable
{
  public abstract String createSyslogHeader(int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, boolean paramBoolean2);

  public abstract byte[] createPacketData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2);

  public abstract byte[] createPacketData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogMessageProcessorIF
 * JD-Core Version:    0.6.0
 */