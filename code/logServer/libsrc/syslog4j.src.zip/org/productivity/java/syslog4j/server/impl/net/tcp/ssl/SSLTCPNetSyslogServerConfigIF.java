package org.productivity.java.syslog4j.server.impl.net.tcp.ssl;

import org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfigIF;

public abstract interface SSLTCPNetSyslogServerConfigIF extends TCPNetSyslogServerConfigIF
{
  public abstract String getKeyStore();

  public abstract void setKeyStore(String paramString);

  public abstract String getKeyStorePassword();

  public abstract void setKeyStorePassword(String paramString);

  public abstract String getTrustStore();

  public abstract void setTrustStore(String paramString);

  public abstract String getTrustStorePassword();

  public abstract void setTrustStorePassword(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.ssl.SSLTCPNetSyslogServerConfigIF
 * JD-Core Version:    0.6.0
 */