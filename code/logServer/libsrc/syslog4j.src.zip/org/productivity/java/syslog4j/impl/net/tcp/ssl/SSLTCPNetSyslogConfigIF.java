package org.productivity.java.syslog4j.impl.net.tcp.ssl;

import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfigIF;

public abstract interface SSLTCPNetSyslogConfigIF extends TCPNetSyslogConfigIF
{
  public abstract String getKeyStore();

  public abstract void setKeyStore(String paramString);

  public abstract String getKeyStorePassword();

  public abstract void setKeyStorePassword(String paramString);

  public abstract String getTrustStore();

  public abstract void setTrustStore(String paramString);

  public abstract String getTrustStorePassword();

  public abstract void setTrustStorePassword(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslogConfigIF
 * JD-Core Version:    0.6.0
 */