package org.productivity.java.syslog4j.server;

import java.io.Serializable;

public abstract interface SyslogServerEventHandlerIF extends Serializable
{
  public abstract void initialize(SyslogServerIF paramSyslogServerIF);

  public abstract void destroy(SyslogServerIF paramSyslogServerIF);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerEventHandlerIF
 * JD-Core Version:    0.6.0
 */