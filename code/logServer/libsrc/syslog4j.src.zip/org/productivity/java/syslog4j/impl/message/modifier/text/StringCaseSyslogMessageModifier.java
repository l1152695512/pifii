package org.productivity.java.syslog4j.impl.message.modifier.text;

import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public class StringCaseSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = 8383234811585957460L;
  public static final byte LOWER_CASE = 0;
  public static final byte UPPER_CASE = 1;
  public static final StringCaseSyslogMessageModifier LOWER = new StringCaseSyslogMessageModifier(0);
  public static final StringCaseSyslogMessageModifier UPPER = new StringCaseSyslogMessageModifier(1);
  protected byte stringCase = 0;

  public StringCaseSyslogMessageModifier(byte paramByte)
  {
    this.stringCase = paramByte;
    if ((paramByte < 0) || (paramByte > 1))
      throw new SyslogRuntimeException("stringCase must be LOWER_CASE (0) or UPPER_CASE (1)");
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    String str = paramString;
    if (paramString != null)
      if (this.stringCase == 0)
        str = str.toLowerCase();
      else if (this.stringCase == 1)
        str = str.toUpperCase();
    return str;
  }

  public boolean verify(String paramString)
  {
    return true;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.text.StringCaseSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */