package org.productivity.java.syslog4j.util;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import org.productivity.java.syslog4j.SyslogCharSetIF;
import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public final class SyslogUtility
  implements SyslogConstants
{
  private static final long serialVersionUID = 915031554586613648L;

  public static final InetAddress getInetAddress(String paramString)
    throws SyslogRuntimeException
  {
    InetAddress localInetAddress = null;
    try
    {
      localInetAddress = InetAddress.getByName(paramString);
    }
    catch (UnknownHostException localUnknownHostException)
    {
      throw new SyslogRuntimeException(localUnknownHostException);
    }
    return localInetAddress;
  }

  public static final String getFacilityString(int paramInt)
  {
    switch (paramInt)
    {
    case 0:
      return "kern";
    case 8:
      return "user";
    case 16:
      return "mail";
    case 24:
      return "daemon";
    case 32:
      return "auth";
    case 40:
      return "syslog";
    case 48:
      return "lpr";
    case 56:
      return "news";
    case 64:
      return "uucp";
    case 72:
      return "cron";
    case 80:
      return "authpriv";
    case 88:
      return "ftp";
    case 128:
      return "local0";
    case 136:
      return "local1";
    case 144:
      return "local2";
    case 152:
      return "local3";
    case 160:
      return "local4";
    case 168:
      return "local5";
    case 176:
      return "local6";
    case 184:
      return "local7";
    }
    return "UNKNOWN";
  }

  public static final int getFacility(String paramString)
  {
    String str = paramString;
    if (paramString == null)
      return -1;
    str = paramString.trim();
    if ("KERN".equalsIgnoreCase(str))
      return 0;
    if ("USER".equalsIgnoreCase(paramString))
      return 8;
    if ("MAIL".equalsIgnoreCase(paramString))
      return 16;
    if ("DAEMON".equalsIgnoreCase(paramString))
      return 24;
    if ("AUTH".equalsIgnoreCase(paramString))
      return 32;
    if ("SYSLOG".equalsIgnoreCase(paramString))
      return 40;
    if ("LPR".equalsIgnoreCase(paramString))
      return 48;
    if ("NEWS".equalsIgnoreCase(paramString))
      return 56;
    if ("UUCP".equalsIgnoreCase(paramString))
      return 64;
    if ("CRON".equalsIgnoreCase(paramString))
      return 72;
    if ("AUTHPRIV".equalsIgnoreCase(paramString))
      return 80;
    if ("FTP".equalsIgnoreCase(paramString))
      return 88;
    if ("LOCAL0".equalsIgnoreCase(paramString))
      return 128;
    if ("LOCAL1".equalsIgnoreCase(paramString))
      return 136;
    if ("LOCAL2".equalsIgnoreCase(paramString))
      return 144;
    if ("LOCAL3".equalsIgnoreCase(paramString))
      return 152;
    if ("LOCAL4".equalsIgnoreCase(paramString))
      return 160;
    if ("LOCAL5".equalsIgnoreCase(paramString))
      return 168;
    if ("LOCAL6".equalsIgnoreCase(paramString))
      return 176;
    if ("LOCAL7".equalsIgnoreCase(paramString))
      return 184;
    return -1;
  }

  public static final int getLevel(String paramString)
  {
    String str = paramString;
    if (paramString == null)
      return -1;
    str = paramString.trim();
    if ("DEBUG".equalsIgnoreCase(str))
      return 7;
    if ("INFO".equalsIgnoreCase(str))
      return 6;
    if ("NOTICE".equalsIgnoreCase(str))
      return 5;
    if ("WARN".equalsIgnoreCase(str))
      return 4;
    if ("ERROR".equalsIgnoreCase(str))
      return 3;
    if ("CRITICAL".equalsIgnoreCase(str))
      return 2;
    if ("ALERT".equalsIgnoreCase(str))
      return 1;
    if ("EMERGENCY".equalsIgnoreCase(str))
      return 0;
    return -1;
  }

  public static final boolean isClassExists(String paramString)
  {
    try
    {
      Class.forName(paramString);
      return true;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
    return false;
  }

  public static final String getLocalName()
  {
    String str = "unknown";
    try
    {
      InetAddress localInetAddress = InetAddress.getLocalHost();
      str = localInetAddress.getHostName();
    }
    catch (UnknownHostException localUnknownHostException)
    {
    }
    return str;
  }

  public static final byte[] getBytes(SyslogCharSetIF paramSyslogCharSetIF, String paramString)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = paramString.getBytes(paramSyslogCharSetIF.getCharSet());
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = paramString.getBytes();
    }
    return arrayOfByte;
  }

  public static final String newString(SyslogCharSetIF paramSyslogCharSetIF, byte[] paramArrayOfByte)
  {
    String str = newString(paramSyslogCharSetIF, paramArrayOfByte, paramArrayOfByte.length);
    return str;
  }

  public static final String newString(SyslogCharSetIF paramSyslogCharSetIF, byte[] paramArrayOfByte, int paramInt)
  {
    String str = null;
    try
    {
      str = new String(paramArrayOfByte, 0, paramInt, paramSyslogCharSetIF.getCharSet());
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      str = new String(paramArrayOfByte);
    }
    return str;
  }

  public static final String getLevelString(int paramInt)
  {
    switch (paramInt)
    {
    case 7:
      return "DEBUG";
    case 6:
      return "INFO";
    case 5:
      return "NOTICE";
    case 4:
      return "WARN";
    case 3:
      return "ERROR";
    case 2:
      return "CRITICAL";
    case 1:
      return "ALERT";
    case 0:
      return "EMERGENCY";
    }
    return "UNKNOWN";
  }

  public static void sleep(long paramLong)
  {
    try
    {
      Thread.sleep(paramLong);
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.util.SyslogUtility
 * JD-Core Version:    0.6.0
 */