package org.productivity.java.syslog4j.impl.net.tcp;

import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.impl.net.AbstractNetSyslog;

public class TCPNetSyslog extends AbstractNetSyslog
{
  private static final long serialVersionUID = -2157528355215068721L;
  protected TCPNetSyslogWriter writer = null;
  protected TCPNetSyslogConfigIF tcpNetSyslogConfig = null;

  public void initialize()
    throws SyslogRuntimeException
  {
    super.initialize();
    try
    {
      this.tcpNetSyslogConfig = ((TCPNetSyslogConfigIF)this.syslogConfig);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must implement interface TCPNetSyslogConfigIF");
    }
  }

  public AbstractSyslogWriter getWriter()
  {
    return getWriter(true);
  }

  public synchronized AbstractSyslogWriter getWriter(boolean paramBoolean)
  {
    if ((this.writer != null) || (!paramBoolean))
      return this.writer;
    this.writer = ((TCPNetSyslogWriter)createWriter());
    if (this.tcpNetSyslogConfig.isThreaded())
      createWriterThread(this.writer);
    return this.writer;
  }

  protected void write(int paramInt, byte[] paramArrayOfByte)
    throws SyslogRuntimeException
  {
    AbstractSyslogWriter localAbstractSyslogWriter = getWriter();
    try
    {
      if (localAbstractSyslogWriter.hasThread())
        localAbstractSyslogWriter.queue(paramInt, paramArrayOfByte);
      else
        synchronized (localAbstractSyslogWriter)
        {
          localAbstractSyslogWriter.write(paramArrayOfByte);
        }
    }
    finally
    {
      returnWriter(localAbstractSyslogWriter);
    }
  }

  public void flush()
    throws SyslogRuntimeException
  {
    AbstractSyslogWriter localAbstractSyslogWriter = getWriter(false);
    if (localAbstractSyslogWriter != null)
      localAbstractSyslogWriter.flush();
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    AbstractSyslogWriter localAbstractSyslogWriter = getWriter(false);
    if (localAbstractSyslogWriter != null)
      localAbstractSyslogWriter.shutdown();
  }

  public void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslog
 * JD-Core Version:    0.6.0
 */