package org.productivity.java.syslog4j.impl.log4j;

import org.apache.log4j.helpers.LogLog;

public class Syslog4jAppender extends Syslog4jAppenderSkeleton
{
  private static final long serialVersionUID = -6072552977605816670L;

  public String initialize()
  {
    if (this.protocol == null)
      this.protocol = "udp";
    return this.protocol;
  }

  public boolean getHeader()
  {
    return false;
  }

  public void setHeader(boolean paramBoolean)
  {
    LogLog.warn("Syslog4jAppender ignores the \"Header\" parameter.");
  }

  public String getSyslogHost()
  {
    return this.host;
  }

  public void setSyslogHost(String paramString)
  {
    this.host = paramString;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.log4j.Syslog4jAppender
 * JD-Core Version:    0.6.0
 */