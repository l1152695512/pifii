package org.productivity.java.syslog4j.impl.net.tcp.ssl.pool;

import org.productivity.java.syslog4j.impl.net.tcp.pool.PooledTCPNetSyslogConfig;
import org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslog;
import org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslogConfigIF;
import org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslogWriter;

public class PooledSSLTCPNetSyslogConfig extends PooledTCPNetSyslogConfig
  implements SSLTCPNetSyslogConfigIF
{
  private static final long serialVersionUID = 2092268298395023976L;
  protected String keyStore = null;
  protected String keyStorePassword = null;
  protected String trustStore = null;
  protected String trustStorePassword = null;

  public PooledSSLTCPNetSyslogConfig()
  {
  }

  public PooledSSLTCPNetSyslogConfig(int paramInt1, String paramString, int paramInt2)
  {
    super(paramInt1, paramString, paramInt2);
  }

  public PooledSSLTCPNetSyslogConfig(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }

  public PooledSSLTCPNetSyslogConfig(int paramInt)
  {
    super(paramInt);
  }

  public PooledSSLTCPNetSyslogConfig(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public PooledSSLTCPNetSyslogConfig(String paramString)
  {
    super(paramString);
  }

  public String getKeyStore()
  {
    return this.keyStore;
  }

  public void setKeyStore(String paramString)
  {
    this.keyStore = paramString;
  }

  public String getKeyStorePassword()
  {
    return this.keyStorePassword;
  }

  public void setKeyStorePassword(String paramString)
  {
    this.keyStorePassword = paramString;
  }

  public String getTrustStore()
  {
    return this.trustStore;
  }

  public void setTrustStore(String paramString)
  {
    this.trustStore = paramString;
  }

  public String getTrustStorePassword()
  {
    return this.trustStorePassword;
  }

  public void setTrustStorePassword(String paramString)
  {
    this.trustStorePassword = paramString;
  }

  public Class getSyslogClass()
  {
    return SSLTCPNetSyslog.class;
  }

  public Class getSyslogWriterClass()
  {
    return SSLTCPNetSyslogWriter.class;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.ssl.pool.PooledSSLTCPNetSyslogConfig
 * JD-Core Version:    0.6.0
 */