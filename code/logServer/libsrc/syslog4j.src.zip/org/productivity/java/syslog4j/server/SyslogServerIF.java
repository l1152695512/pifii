package org.productivity.java.syslog4j.server;

import org.productivity.java.syslog4j.SyslogRuntimeException;

public abstract interface SyslogServerIF extends Runnable
{
  public abstract void initialize(String paramString, SyslogServerConfigIF paramSyslogServerConfigIF)
    throws SyslogRuntimeException;

  public abstract String getProtocol();

  public abstract SyslogServerConfigIF getConfig();

  public abstract void run();

  public abstract Thread getThread();

  public abstract void setThread(Thread paramThread);

  public abstract void shutdown();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerIF
 * JD-Core Version:    0.6.0
 */