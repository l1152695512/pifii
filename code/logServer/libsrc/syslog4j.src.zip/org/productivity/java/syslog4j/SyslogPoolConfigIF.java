package org.productivity.java.syslog4j;

import java.io.Serializable;

public abstract interface SyslogPoolConfigIF extends Serializable
{
  public abstract int getMaxActive();

  public abstract void setMaxActive(int paramInt);

  public abstract int getMaxIdle();

  public abstract void setMaxIdle(int paramInt);

  public abstract long getMaxWait();

  public abstract void setMaxWait(long paramLong);

  public abstract long getMinEvictableIdleTimeMillis();

  public abstract void setMinEvictableIdleTimeMillis(long paramLong);

  public abstract int getMinIdle();

  public abstract void setMinIdle(int paramInt);

  public abstract int getNumTestsPerEvictionRun();

  public abstract void setNumTestsPerEvictionRun(int paramInt);

  public abstract long getSoftMinEvictableIdleTimeMillis();

  public abstract void setSoftMinEvictableIdleTimeMillis(long paramLong);

  public abstract boolean isTestOnBorrow();

  public abstract void setTestOnBorrow(boolean paramBoolean);

  public abstract boolean isTestOnReturn();

  public abstract void setTestOnReturn(boolean paramBoolean);

  public abstract boolean isTestWhileIdle();

  public abstract void setTestWhileIdle(boolean paramBoolean);

  public abstract long getTimeBetweenEvictionRunsMillis();

  public abstract void setTimeBetweenEvictionRunsMillis(long paramLong);

  public abstract byte getWhenExhaustedAction();

  public abstract void setWhenExhaustedAction(byte paramByte);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogPoolConfigIF
 * JD-Core Version:    0.6.0
 */