package org.productivity.java.syslog4j.impl.backlog.log4j;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.backlog.AbstractSyslogBackLogHandler;

public class Log4jSyslogBackLogHandler extends AbstractSyslogBackLogHandler
{
  protected Logger logger = null;
  protected Level downLevel = Level.WARN;
  protected Level upLevel = Level.WARN;

  public Log4jSyslogBackLogHandler(Logger paramLogger)
    throws SyslogRuntimeException
  {
    this.logger = paramLogger;
    initialize();
  }

  public Log4jSyslogBackLogHandler(Logger paramLogger, boolean paramBoolean)
  {
    this.logger = paramLogger;
    this.appendReason = paramBoolean;
    initialize();
  }

  public Log4jSyslogBackLogHandler(Class paramClass)
  {
    if (paramClass == null)
      throw new SyslogRuntimeException("loggerClass cannot be null");
    this.logger = Logger.getLogger(paramClass);
    initialize();
  }

  public Log4jSyslogBackLogHandler(Class paramClass, boolean paramBoolean)
  {
    if (paramClass == null)
      throw new SyslogRuntimeException("loggerClass cannot be null");
    this.logger = Logger.getLogger(paramClass);
    this.appendReason = paramBoolean;
    initialize();
  }

  public Log4jSyslogBackLogHandler(String paramString)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("loggerName cannot be null");
    this.logger = Logger.getLogger(paramString);
    initialize();
  }

  public Log4jSyslogBackLogHandler(String paramString, boolean paramBoolean)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("loggerName cannot be null");
    this.logger = Logger.getLogger(paramString);
    this.appendReason = paramBoolean;
    initialize();
  }

  public Log4jSyslogBackLogHandler(String paramString, LoggerFactory paramLoggerFactory)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("loggerName cannot be null");
    if (paramLoggerFactory == null)
      throw new SyslogRuntimeException("loggerFactory cannot be null");
    this.logger = Logger.getLogger(paramString, paramLoggerFactory);
    initialize();
  }

  public Log4jSyslogBackLogHandler(String paramString, LoggerFactory paramLoggerFactory, boolean paramBoolean)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("loggerName cannot be null");
    if (paramLoggerFactory == null)
      throw new SyslogRuntimeException("loggerFactory cannot be null");
    this.logger = Logger.getLogger(paramString, paramLoggerFactory);
    this.appendReason = paramBoolean;
    initialize();
  }

  public void initialize()
    throws SyslogRuntimeException
  {
    if (this.logger == null)
      throw new SyslogRuntimeException("logger cannot be null");
  }

  protected static Level getLog4jLevel(int paramInt)
  {
    switch (paramInt)
    {
    case 7:
      return Level.DEBUG;
    case 6:
      return Level.INFO;
    case 5:
      return Level.INFO;
    case 4:
      return Level.WARN;
    case 3:
      return Level.ERROR;
    case 2:
      return Level.ERROR;
    case 1:
      return Level.ERROR;
    case 0:
      return Level.FATAL;
    }
    return Level.WARN;
  }

  public void down(SyslogIF paramSyslogIF, String paramString)
  {
    this.logger.log(this.downLevel, "Syslog protocol \"" + paramSyslogIF.getProtocol() + "\" is down: " + paramString);
  }

  public void up(SyslogIF paramSyslogIF)
  {
    this.logger.log(this.upLevel, "Syslog protocol \"" + paramSyslogIF.getProtocol() + "\" is up");
  }

  public void log(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
    throws SyslogRuntimeException
  {
    Level localLevel = getLog4jLevel(paramInt);
    String str = combine(paramSyslogIF, paramInt, paramString1, paramString2);
    this.logger.log(localLevel, str);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.log4j.Log4jSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */