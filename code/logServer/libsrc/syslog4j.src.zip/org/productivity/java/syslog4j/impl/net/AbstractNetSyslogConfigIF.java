package org.productivity.java.syslog4j.impl.net;

import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;

public abstract interface AbstractNetSyslogConfigIF extends AbstractSyslogConfigIF
{
  public abstract boolean isCacheHostAddress();

  public abstract void setCacheHostAddress(boolean paramBoolean);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfigIF
 * JD-Core Version:    0.6.0
 */