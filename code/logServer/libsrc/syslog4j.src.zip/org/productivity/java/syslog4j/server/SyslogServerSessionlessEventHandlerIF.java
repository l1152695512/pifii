package org.productivity.java.syslog4j.server;

import java.net.SocketAddress;

public abstract interface SyslogServerSessionlessEventHandlerIF extends SyslogServerEventHandlerIF
{
  public abstract void event(SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, SyslogServerEventIF paramSyslogServerEventIF);

  public abstract void exception(SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, Exception paramException);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF
 * JD-Core Version:    0.6.0
 */