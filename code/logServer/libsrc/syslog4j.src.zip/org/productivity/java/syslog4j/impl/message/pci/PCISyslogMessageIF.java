package org.productivity.java.syslog4j.impl.message.pci;

public abstract interface PCISyslogMessageIF
{
  public abstract String getUserId();

  public abstract String getEventType();

  public abstract String getDate();

  public abstract String getTime();

  public abstract String getStatus();

  public abstract String getOrigination();

  public abstract String getAffectedResource();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.pci.PCISyslogMessageIF
 * JD-Core Version:    0.6.0
 */