package org.productivity.java.syslog4j.impl.log4j;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;
import org.productivity.java.syslog4j.Syslog;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class Syslog4jAppenderSkeleton extends AppenderSkeleton
  implements SyslogConstants
{
  private static final long serialVersionUID = 5520555788232095628L;
  protected SyslogIF syslog = null;
  protected String ident = null;
  protected String localName = null;
  protected String protocol = null;
  protected String facility = null;
  protected String host = null;
  protected String port = null;
  protected String charSet = null;
  protected String threaded = null;
  protected String threadLoopInterval = null;
  protected String splitMessageBeginText = null;
  protected String splitMessageEndText = null;
  protected String maxMessageLength = null;
  protected String maxShutdownWait = null;
  protected String writeRetries = null;
  protected String truncateMessage = null;
  protected String useStructuredData = null;
  protected boolean initialized = false;

  public abstract String initialize()
    throws SyslogRuntimeException;

  protected static boolean isTrueOrOn(String paramString)
  {
    int i = 0;
    if (paramString != null)
      if (("true".equalsIgnoreCase(paramString.trim())) || ("on".equalsIgnoreCase(paramString.trim())))
        i = 1;
      else if (("false".equalsIgnoreCase(paramString.trim())) || ("off".equalsIgnoreCase(paramString.trim())))
        i = 0;
      else
        LogLog.error("Value \"" + paramString + "\" not true, on, false, or off -- assuming false");
    return i;
  }

  protected void _initialize()
  {
    String str = initialize();
    if ((str != null) && (this.protocol == null))
      this.protocol = str;
    if (this.protocol != null)
      try
      {
        this.syslog = Syslog.getInstance(this.protocol);
        if (this.host != null)
          this.syslog.getConfig().setHost(this.host);
        if (this.facility != null)
          this.syslog.getConfig().setFacility(SyslogUtility.getFacility(this.facility));
        if (this.port != null)
          try
          {
            int i = Integer.parseInt(this.port);
            this.syslog.getConfig().setPort(i);
          }
          catch (NumberFormatException localNumberFormatException1)
          {
            LogLog.error(localNumberFormatException1.toString());
          }
        if (this.charSet != null)
          this.syslog.getConfig().setCharSet(this.charSet);
        if (this.ident != null)
          this.syslog.getConfig().setIdent(this.ident);
        if (this.localName != null)
          this.syslog.getConfig().setLocalName(this.localName);
        if ((this.truncateMessage != null) && (!"".equals(this.truncateMessage.trim())))
          this.syslog.getConfig().setTruncateMessage(isTrueOrOn(this.truncateMessage));
        if ((this.maxMessageLength != null) && (this.maxMessageLength.length() > 0))
          try
          {
            int j = Integer.parseInt(this.maxMessageLength.trim());
            this.syslog.getConfig().setMaxMessageLength(j);
          }
          catch (NumberFormatException localNumberFormatException2)
          {
            LogLog.error(localNumberFormatException2.toString());
          }
        if (this.useStructuredData != null)
          this.syslog.getConfig().setUseStructuredData(isTrueOrOn(this.useStructuredData));
        if ((this.syslog.getConfig() instanceof AbstractSyslogConfigIF))
        {
          AbstractSyslogConfigIF localAbstractSyslogConfigIF = (AbstractSyslogConfigIF)this.syslog.getConfig();
          if ((this.threaded != null) && (!"".equals(this.threaded.trim())))
            localAbstractSyslogConfigIF.setThreaded(isTrueOrOn(this.threaded));
          if ((this.threadLoopInterval != null) && (this.threadLoopInterval.length() > 0))
            try
            {
              long l = Long.parseLong(this.threadLoopInterval.trim());
              localAbstractSyslogConfigIF.setThreadLoopInterval(l);
            }
            catch (NumberFormatException localNumberFormatException3)
            {
              LogLog.error(localNumberFormatException3.toString());
            }
          if (this.splitMessageBeginText != null)
            localAbstractSyslogConfigIF.setSplitMessageBeginText(SyslogUtility.getBytes(localAbstractSyslogConfigIF, this.splitMessageBeginText));
          if (this.splitMessageEndText != null)
            localAbstractSyslogConfigIF.setSplitMessageEndText(SyslogUtility.getBytes(localAbstractSyslogConfigIF, this.splitMessageEndText));
          if ((this.maxShutdownWait != null) && (this.maxShutdownWait.length() > 0))
            try
            {
              int k = Integer.parseInt(this.maxShutdownWait.trim());
              localAbstractSyslogConfigIF.setMaxShutdownWait(k);
            }
            catch (NumberFormatException localNumberFormatException4)
            {
              LogLog.error(localNumberFormatException4.toString());
            }
          if ((this.writeRetries != null) && (this.writeRetries.length() > 0))
            try
            {
              int m = Integer.parseInt(this.writeRetries.trim());
              localAbstractSyslogConfigIF.setWriteRetries(m);
            }
            catch (NumberFormatException localNumberFormatException5)
            {
              LogLog.error(localNumberFormatException5.toString());
            }
        }
        this.initialized = true;
      }
      catch (SyslogRuntimeException localSyslogRuntimeException)
      {
        LogLog.error(localSyslogRuntimeException.toString());
      }
  }

  public String getProtocol()
  {
    return this.protocol;
  }

  public void setProtocol(String paramString)
  {
    this.protocol = paramString;
  }

  protected void append(LoggingEvent paramLoggingEvent)
  {
    if (!this.initialized)
      _initialize();
    if (this.initialized)
    {
      int i = paramLoggingEvent.getLevel().getSyslogEquivalent();
      String str;
      if (this.layout != null)
      {
        str = this.layout.format(paramLoggingEvent);
        this.syslog.log(i, str);
      }
      else
      {
        str = paramLoggingEvent.getRenderedMessage();
        this.syslog.log(i, str);
      }
    }
  }

  public void close()
  {
    if (this.syslog != null)
      this.syslog.flush();
  }

  public String getFacility()
  {
    return this.facility;
  }

  public void setFacility(String paramString)
  {
    this.facility = paramString;
  }

  public String getHost()
  {
    return this.host;
  }

  public void setHost(String paramString)
  {
    this.host = paramString;
  }

  public String getLocalName()
  {
    return this.localName;
  }

  public void setLocalName(String paramString)
  {
    this.localName = paramString;
  }

  public String getPort()
  {
    return this.port;
  }

  public void setPort(String paramString)
  {
    this.port = paramString;
  }

  public String getCharSet()
  {
    return this.charSet;
  }

  public void setCharSet(String paramString)
  {
    this.charSet = paramString;
  }

  public String getIdent()
  {
    return this.ident;
  }

  public void setIdent(String paramString)
  {
    this.ident = paramString;
  }

  public String getThreaded()
  {
    return this.threaded;
  }

  public void setThreaded(String paramString)
  {
    this.threaded = paramString;
  }

  public boolean requiresLayout()
  {
    return false;
  }

  public String getThreadLoopInterval()
  {
    return this.threadLoopInterval;
  }

  public void setThreadLoopInterval(String paramString)
  {
    this.threadLoopInterval = paramString;
  }

  public String getSplitMessageBeginText()
  {
    return this.splitMessageBeginText;
  }

  public void setSplitMessageBeginText(String paramString)
  {
    this.splitMessageBeginText = paramString;
  }

  public String getSplitMessageEndText()
  {
    return this.splitMessageEndText;
  }

  public void setSplitMessageEndText(String paramString)
  {
    this.splitMessageEndText = paramString;
  }

  public String getMaxMessageLength()
  {
    return this.maxMessageLength;
  }

  public void setMaxMessageLength(String paramString)
  {
    this.maxMessageLength = paramString;
  }

  public String getMaxShutdownWait()
  {
    return this.maxShutdownWait;
  }

  public void setMaxShutdownWait(String paramString)
  {
    this.maxShutdownWait = paramString;
  }

  public String getWriteRetries()
  {
    return this.writeRetries;
  }

  public void setWriteRetries(String paramString)
  {
    this.writeRetries = paramString;
  }

  public String getTruncateMessage()
  {
    return this.truncateMessage;
  }

  public void setTruncateMessage(String paramString)
  {
    this.truncateMessage = paramString;
  }

  public String getUseStructuredData()
  {
    return this.useStructuredData;
  }

  public void setUseStructuredData(String paramString)
  {
    this.useStructuredData = paramString;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.log4j.Syslog4jAppenderSkeleton
 * JD-Core Version:    0.6.0
 */