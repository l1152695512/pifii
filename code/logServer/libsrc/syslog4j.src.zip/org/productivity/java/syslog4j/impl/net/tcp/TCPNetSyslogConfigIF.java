package org.productivity.java.syslog4j.impl.net.tcp;

import org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfigIF;

public abstract interface TCPNetSyslogConfigIF extends AbstractNetSyslogConfigIF
{
  public abstract byte[] getDelimiterSequence();

  public abstract void setDelimiterSequence(byte[] paramArrayOfByte);

  public abstract boolean isPersistentConnection();

  public abstract void setPersistentConnection(boolean paramBoolean);

  public abstract boolean isSoLinger();

  public abstract void setSoLinger(boolean paramBoolean);

  public abstract int getSoLingerSeconds();

  public abstract void setSoLingerSeconds(int paramInt);

  public abstract boolean isKeepAlive();

  public abstract void setKeepAlive(boolean paramBoolean);

  public abstract boolean isReuseAddress();

  public abstract void setReuseAddress(boolean paramBoolean);

  public abstract boolean isSetBufferSize();

  public abstract void setSetBufferSize(boolean paramBoolean);

  public abstract int getFreshConnectionInterval();

  public abstract void setFreshConnectionInterval(int paramInt);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfigIF
 * JD-Core Version:    0.6.0
 */