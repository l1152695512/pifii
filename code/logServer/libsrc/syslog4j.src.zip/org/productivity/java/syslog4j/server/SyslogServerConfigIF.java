package org.productivity.java.syslog4j.server;

import java.util.List;
import org.productivity.java.syslog4j.SyslogCharSetIF;
import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public abstract interface SyslogServerConfigIF extends SyslogConstants, SyslogCharSetIF
{
  public abstract Class getSyslogServerClass();

  public abstract String getHost();

  public abstract void setHost(String paramString)
    throws SyslogRuntimeException;

  public abstract int getPort();

  public abstract void setPort(int paramInt)
    throws SyslogRuntimeException;

  public abstract boolean isUseDaemonThread();

  public abstract void setUseDaemonThread(boolean paramBoolean);

  public abstract int getThreadPriority();

  public abstract void setThreadPriority(int paramInt);

  public abstract List getEventHandlers();

  public abstract long getShutdownWait();

  public abstract void setShutdownWait(long paramLong);

  public abstract void addEventHandler(SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF);

  public abstract void insertEventHandler(int paramInt, SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF);

  public abstract void removeEventHandler(SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF);

  public abstract void removeAllEventHandlers();

  public abstract boolean isUseStructuredData();

  public abstract void setUseStructuredData(boolean paramBoolean);

  public abstract Object getDateTimeFormatter();

  public abstract void setDateTimeFormatter(Object paramObject);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerConfigIF
 * JD-Core Version:    0.6.0
 */