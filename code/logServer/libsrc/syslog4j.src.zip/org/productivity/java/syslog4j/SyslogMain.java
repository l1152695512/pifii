package org.productivity.java.syslog4j;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class SyslogMain
{
  public static boolean CALL_SYSTEM_EXIT_ON_FAILURE = true;

  public static void usage(String paramString)
  {
    if (paramString != null)
    {
      System.out.println("Error: " + paramString);
      System.out.println();
    }
    System.out.println("Usage:");
    System.out.println();
    System.out.println("Syslog [-h <host>] [-p <port>] [-l <level>] [-f <facility>]");
    System.out.println("       <protocol>");
    System.out.println();
    System.out.println("Syslog [-h <host>] [-p <port>] [-l <level>] [-f <facility>]");
    System.out.println("       <protocol> [message...]");
    System.out.println();
    System.out.println("Syslog [-h <host>] [-p <port>] [-l <level>] [-f <facility>]");
    System.out.println("       -i <file> <protocol>");
    System.out.println();
    System.out.println("-h <host>      host or IP to send message (default: localhost)");
    System.out.println("-p <port>      port to send message (default: 514)");
    System.out.println("-l <level>     syslog level to use (default: INFO)");
    System.out.println("-f <facility>  syslog facility to use (default: USER)");
    System.out.println("-i <file>      input taken from the specified file");
    System.out.println();
    System.out.println("-q             do not write anything to standard out");
    System.out.println();
    System.out.println("protocol       Syslog4j protocol implementation");
    System.out.println("message        syslog message text");
    System.out.println();
    System.out.println("Notes:");
    System.out.println();
    System.out.println("Additional message arguments will be concatenated into the same");
    System.out.println("syslog message; calling SyslogMain will only send one message per call.");
    System.out.println();
    System.out.println("If the message argument is ommited, lines will be taken from the");
    System.out.println("standard input.");
  }

  public static Options parseOptions(String[] paramArrayOfString)
  {
    Options localOptions = new Options();
    int i = 0;
    while (i < paramArrayOfString.length)
    {
      String str = paramArrayOfString[(i++)];
      int j = 0;
      if ("-h".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify host with -h";
          return localOptions;
        }
        j = 1;
        localOptions.host = paramArrayOfString[(i++)];
      }
      if ("-p".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify port with -p";
          return localOptions;
        }
        j = 1;
        localOptions.port = paramArrayOfString[(i++)];
      }
      if ("-l".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify level with -l";
          return localOptions;
        }
        j = 1;
        localOptions.level = paramArrayOfString[(i++)];
      }
      if ("-f".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify facility with -f";
          return localOptions;
        }
        j = 1;
        localOptions.facility = paramArrayOfString[(i++)];
      }
      if ("-i".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify file with -i";
          return localOptions;
        }
        j = 1;
        localOptions.fileName = paramArrayOfString[(i++)];
      }
      if ("-q".equals(str))
      {
        j = 1;
        localOptions.quiet = true;
      }
      if ((localOptions.protocol == null) && (j == 0))
      {
        j = 1;
        localOptions.protocol = str;
      }
      if (j != 0)
        continue;
      if (localOptions.message == null)
      {
        localOptions.message = str;
        continue;
      }
      Options tmp271_270 = localOptions;
      tmp271_270.message = (tmp271_270.message + " " + str);
    }
    if (localOptions.protocol == null)
    {
      localOptions.usage = "Must specify protocol";
      return localOptions;
    }
    if ((localOptions.message != null) && (localOptions.fileName != null))
    {
      localOptions.usage = "Must specify either -i <file> or <message>, not both";
      return localOptions;
    }
    return localOptions;
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    main(paramArrayOfString, true);
  }

  public static void main(String[] paramArrayOfString, boolean paramBoolean)
    throws Exception
  {
    Options localOptions = parseOptions(paramArrayOfString);
    if (localOptions.usage != null)
    {
      usage(localOptions.usage);
      if (CALL_SYSTEM_EXIT_ON_FAILURE)
        System.exit(1);
      else
        return;
    }
    if (!localOptions.quiet)
      System.out.println("Syslog " + Syslog.getVersion());
    if (!Syslog.exists(localOptions.protocol))
    {
      usage("Protocol \"" + localOptions.protocol + "\" not supported");
      if (CALL_SYSTEM_EXIT_ON_FAILURE)
        System.exit(1);
      else
        return;
    }
    SyslogIF localSyslogIF = Syslog.getInstance(localOptions.protocol);
    SyslogConfigIF localSyslogConfigIF = localSyslogIF.getConfig();
    if (localOptions.host != null)
    {
      localSyslogConfigIF.setHost(localOptions.host);
      if (!localOptions.quiet)
        System.out.println("Sending to host: " + localOptions.host);
    }
    if (localOptions.port != null)
    {
      localSyslogConfigIF.setPort(Integer.parseInt(localOptions.port));
      if (!localOptions.quiet)
        System.out.println("Sending to port: " + localOptions.port);
    }
    int i = SyslogUtility.getLevel(localOptions.level);
    localSyslogConfigIF.setFacility(localOptions.facility);
    if (localOptions.message != null)
    {
      if (!localOptions.quiet)
        System.out.println("Sending " + localOptions.facility + "." + localOptions.level + " message \"" + localOptions.message + "\"");
      localSyslogIF.log(i, localOptions.message);
    }
    else
    {
      Object localObject = null;
      if (localOptions.fileName != null)
        localObject = new FileInputStream(localOptions.fileName);
      else
        localObject = System.in;
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader((InputStream)localObject));
      for (String str = localBufferedReader.readLine(); (str != null) && (str.length() > 0); str = localBufferedReader.readLine())
      {
        if (!localOptions.quiet)
          System.out.println("Sending " + localOptions.facility + "." + localOptions.level + " message \"" + str + "\"");
        localSyslogIF.log(i, str);
      }
    }
    if (paramBoolean)
      Syslog.shutdown();
  }

  public static class Options
  {
    public String host = null;
    public String port = null;
    public String level = "INFO";
    public String facility = "USER";
    public String protocol = null;
    public String message = null;
    public String fileName = null;
    public boolean quiet = false;
    public String usage = null;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogMain
 * JD-Core Version:    0.6.0
 */