package org.productivity.java.syslog4j.impl.net.tcp;

import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfig;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class TCPNetSyslogConfig extends AbstractNetSyslogConfig
  implements TCPNetSyslogConfigIF
{
  private static final long serialVersionUID = 9023152050686365460L;
  public static byte[] SYSTEM_DELIMITER_SEQUENCE = null;
  protected byte[] delimiterSequence = SYSTEM_DELIMITER_SEQUENCE;
  protected boolean persistentConnection = true;
  protected boolean soLinger = true;
  protected int soLingerSeconds = 1;
  protected boolean keepAlive = true;
  protected boolean reuseAddress = true;
  protected boolean setBufferSize = true;
  protected int freshConnectionInterval = -1;

  public TCPNetSyslogConfig()
  {
    initialize();
  }

  protected void initialize()
  {
  }

  public TCPNetSyslogConfig(int paramInt1, String paramString, int paramInt2)
  {
    super(paramInt1, paramString, paramInt2);
    initialize();
  }

  public TCPNetSyslogConfig(int paramInt, String paramString)
  {
    super(paramInt, paramString);
    initialize();
  }

  public TCPNetSyslogConfig(int paramInt)
  {
    super(paramInt);
    initialize();
  }

  public TCPNetSyslogConfig(String paramString, int paramInt)
  {
    super(paramString, paramInt);
    initialize();
  }

  public TCPNetSyslogConfig(String paramString)
  {
    super(paramString);
    initialize();
  }

  public Class getSyslogClass()
  {
    return TCPNetSyslog.class;
  }

  public byte[] getDelimiterSequence()
  {
    return this.delimiterSequence;
  }

  public void setDelimiterSequence(byte[] paramArrayOfByte)
  {
    this.delimiterSequence = paramArrayOfByte;
  }

  public void setDelimiterSequence(String paramString)
  {
    this.delimiterSequence = SyslogUtility.getBytes(this, paramString);
  }

  public boolean isPersistentConnection()
  {
    return this.persistentConnection;
  }

  public void setPersistentConnection(boolean paramBoolean)
  {
    this.persistentConnection = paramBoolean;
  }

  public boolean isSoLinger()
  {
    return this.soLinger;
  }

  public void setSoLinger(boolean paramBoolean)
  {
    this.soLinger = paramBoolean;
  }

  public int getSoLingerSeconds()
  {
    return this.soLingerSeconds;
  }

  public void setSoLingerSeconds(int paramInt)
  {
    this.soLingerSeconds = paramInt;
  }

  public boolean isKeepAlive()
  {
    return this.keepAlive;
  }

  public void setKeepAlive(boolean paramBoolean)
  {
    this.keepAlive = paramBoolean;
  }

  public boolean isReuseAddress()
  {
    return this.reuseAddress;
  }

  public void setReuseAddress(boolean paramBoolean)
  {
    this.reuseAddress = paramBoolean;
  }

  public boolean isSetBufferSize()
  {
    return this.setBufferSize;
  }

  public void setSetBufferSize(boolean paramBoolean)
  {
    this.setBufferSize = paramBoolean;
  }

  public int getFreshConnectionInterval()
  {
    return this.freshConnectionInterval;
  }

  public void setFreshConnectionInterval(int paramInt)
  {
    this.freshConnectionInterval = paramInt;
  }

  public Class getSyslogWriterClass()
  {
    return TCPNetSyslogWriter.class;
  }

  static
  {
    String str = System.getProperty("line.separator");
    SYSTEM_DELIMITER_SEQUENCE = str.getBytes();
    if ((SYSTEM_DELIMITER_SEQUENCE == null) || (SYSTEM_DELIMITER_SEQUENCE.length < 1))
      SYSTEM_DELIMITER_SEQUENCE = SyslogConstants.TCP_DELIMITER_SEQUENCE_DEFAULT;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfig
 * JD-Core Version:    0.6.0
 */