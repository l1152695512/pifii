package org.productivity.java.syslog4j.impl.net;

import org.productivity.java.syslog4j.impl.AbstractSyslogConfig;

public abstract class AbstractNetSyslogConfig extends AbstractSyslogConfig
  implements AbstractNetSyslogConfigIF
{
  private static final long serialVersionUID = 7240133962159244924L;
  protected String host = "localhost";
  protected int port = 514;
  protected boolean cacheHostAddress = true;
  protected int maxQueueSize = -1;

  public AbstractNetSyslogConfig()
  {
  }

  public AbstractNetSyslogConfig(int paramInt)
  {
    this.facility = paramInt;
  }

  public AbstractNetSyslogConfig(int paramInt, String paramString)
  {
    this.facility = paramInt;
    this.host = paramString;
  }

  public AbstractNetSyslogConfig(String paramString)
  {
    this.host = paramString;
  }

  public AbstractNetSyslogConfig(int paramInt1, String paramString, int paramInt2)
  {
    this.facility = paramInt1;
    this.host = paramString;
    this.port = paramInt2;
  }

  public AbstractNetSyslogConfig(String paramString, int paramInt)
  {
    this.host = paramString;
    this.port = paramInt;
  }

  public boolean isCacheHostAddress()
  {
    return this.cacheHostAddress;
  }

  public void setCacheHostAddress(boolean paramBoolean)
  {
    this.cacheHostAddress = paramBoolean;
  }

  public String getHost()
  {
    return this.host;
  }

  public void setHost(String paramString)
  {
    this.host = paramString;
  }

  public int getPort()
  {
    return this.port;
  }

  public void setPort(int paramInt)
  {
    this.port = paramInt;
  }

  public int getMaxQueueSize()
  {
    return this.maxQueueSize;
  }

  public void setMaxQueueSize(int paramInt)
  {
    this.maxQueueSize = paramInt;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfig
 * JD-Core Version:    0.6.0
 */