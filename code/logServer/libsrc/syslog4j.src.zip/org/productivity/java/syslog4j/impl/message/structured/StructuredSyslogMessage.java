package org.productivity.java.syslog4j.impl.message.structured;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.productivity.java.syslog4j.impl.message.AbstractSyslogMessage;

public class StructuredSyslogMessage extends AbstractSyslogMessage
  implements StructuredSyslogMessageIF
{
  private static final long serialVersionUID = 3669887659567965965L;
  private String messageId;
  private Map structuredData;
  private String message;

  private StructuredSyslogMessage()
  {
    this.messageId = null;
    this.message = null;
    this.structuredData = null;
  }

  public StructuredSyslogMessage(String paramString1, Map paramMap, String paramString2)
  {
    this.messageId = paramString1;
    this.structuredData = paramMap;
    this.message = paramString2;
    ensureCorrectMapType();
  }

  private void ensureCorrectMapType()
  {
    if (getStructuredData() != null)
    {
      Set localSet1 = getStructuredData().entrySet();
      while (true)
      {
        Iterator localIterator1 = localSet1.iterator();
        while (true)
          if (localIterator1.hasNext())
          {
            Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
            if (!(localEntry1.getKey() instanceof String))
              throw new IllegalArgumentException("Structured data map must be a map of String -> (Map of String,String)");
            if (!(localEntry1.getValue() instanceof Map))
              throw new IllegalArgumentException("Structured data map must be a map of String -> (Map of String,String)");
            Set localSet2 = ((Map)localEntry1.getValue()).entrySet();
            Iterator localIterator2 = localSet2.iterator();
            if (!localIterator2.hasNext())
              continue;
            Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
            if (!(localEntry2.getKey() instanceof String))
              throw new IllegalArgumentException("Structured data map must be a map of String -> (Map of String,String)");
            if ((localEntry2.getValue() instanceof String))
              break;
            throw new IllegalArgumentException("Structured data map must be a map of String -> (Map of String,String)");
          }
      }
    }
  }

  public static StructuredSyslogMessage fromString(String paramString)
  {
    StructuredSyslogMessage localStructuredSyslogMessage = new StructuredSyslogMessage();
    localStructuredSyslogMessage.deserialize(paramString);
    return localStructuredSyslogMessage;
  }

  private void deserialize(String paramString)
  {
    if (paramString.indexOf('[') <= 0)
      throw new IllegalArgumentException("Invalid Syslog string format: " + paramString);
    String str1 = paramString.substring(0, paramString.indexOf('['));
    String str2 = paramString.substring(paramString.indexOf('['), paramString.lastIndexOf(']') + 1);
    if (paramString.lastIndexOf(']') + 2 <= paramString.length())
      this.message = paramString.substring(paramString.lastIndexOf(']') + 2);
    else
      this.message = "";
    String[] arrayOfString1 = str1.split(" ");
    if (arrayOfString1.length != 1)
      throw new IllegalArgumentException("Invalid Syslog string format: " + paramString);
    this.messageId = ("-".equals(arrayOfString1[0]) ? null : arrayOfString1[0]);
    this.structuredData = new HashMap();
    if (!"[0@0]".equals(str2))
      while (!"".equals(str2))
      {
        if ((!str2.startsWith("[")) || (str2.indexOf(']') == -1))
          throw new IllegalArgumentException("Invalid structured data format in Syslog message: " + paramString);
        String str3 = str2.substring(1, str2.indexOf(']'));
        HashMap localHashMap = new HashMap();
        String[] arrayOfString2 = str3.split(" ");
        for (int i = 1; i < arrayOfString2.length; i++)
        {
          String[] arrayOfString3 = arrayOfString2[i].split("=");
          if (arrayOfString3.length != 2)
            throw new IllegalArgumentException("Invalid structured data format in Syslog message: " + paramString);
          if ((!arrayOfString3[1].startsWith("\"")) || (!arrayOfString3[1].endsWith("\"")))
            throw new IllegalArgumentException("Invalid structured data format in Syslog message: " + paramString);
          localHashMap.put(arrayOfString3[0], arrayOfString3[1].substring(1, arrayOfString3[1].length() - 1));
        }
        this.structuredData.put(arrayOfString2[0], localHashMap);
        if (str2.indexOf(']') != str2.lastIndexOf(']'))
        {
          str2 = str2.substring(str2.indexOf(']') + 1);
          continue;
        }
        str2 = "";
      }
  }

  public String getMessageId()
  {
    return this.messageId;
  }

  public Map getStructuredData()
  {
    return this.structuredData;
  }

  public String getMessage()
  {
    return this.message;
  }

  public String createMessage()
  {
    return serialize();
  }

  private String serialize()
  {
    if (!checkIsPrintable(getMessageId()))
      throw new IllegalArgumentException("Invalid message id: " + getMessageId());
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(nilProtect(getMessageId()));
    localStringBuffer.append(' ');
    if ((getStructuredData() == null) || (getStructuredData().size() == 0))
    {
      localStringBuffer.append("[0@0]");
    }
    else
    {
      Set localSet1 = getStructuredData().entrySet();
      Iterator localIterator1 = localSet1.iterator();
      while (localIterator1.hasNext())
      {
        Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
        String str1 = (String)localEntry1.getKey();
        if ((str1 == null) || (str1.length() == 0) || (!checkIsPrintable(str1)))
          throw new IllegalArgumentException("Illegal structured data id: " + str1);
        localStringBuffer.append('[').append(str1);
        Map localMap = (Map)localEntry1.getValue();
        if (localMap != null)
        {
          Set localSet2 = localMap.entrySet();
          Iterator localIterator2 = localSet2.iterator();
          while (localIterator2.hasNext())
          {
            Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
            String str2 = (String)localEntry2.getKey();
            String str3 = (String)localEntry2.getValue();
            if ((str2 == null) || (str2.length() == 0) || (!checkIsPrintable(str2)))
              throw new IllegalArgumentException("Illegal structured data parameter name: " + str2);
            if (str3 == null)
              throw new IllegalArgumentException("Null structured data parameter value for parameter name: " + str2);
            localStringBuffer.append(' ');
            localStringBuffer.append(str2);
            localStringBuffer.append('=').append('"');
            sdEscape(localStringBuffer, str3);
            localStringBuffer.append('"');
          }
        }
        localStringBuffer.append(']');
      }
    }
    if ((getMessage() != null) && (getMessage().length() != 0))
    {
      localStringBuffer.append(' ');
      localStringBuffer.append(nilProtect(getMessage()));
    }
    return localStringBuffer.toString();
  }

  public static void sdEscape(StringBuffer paramStringBuffer, String paramString)
  {
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if ((c == '"') || (c == '\\') || (c == ']'))
        paramStringBuffer.append('\\');
      paramStringBuffer.append(c);
    }
  }

  public static boolean checkIsPrintable(String paramString)
  {
    if (paramString == null)
      return true;
    for (int i = 0; i < paramString.length(); i++)
    {
      int j = paramString.charAt(i);
      if ((j < 33) || (j > 126))
        return false;
    }
    return true;
  }

  public static String nilProtect(String paramString)
  {
    if ((paramString == null) || (paramString.trim().length() == 0))
      return "-";
    return paramString;
  }

  public int hashCode()
  {
    int i = 1;
    i = 31 * i + (this.message == null ? 0 : this.message.hashCode());
    i = 31 * i + (this.messageId == null ? 0 : this.messageId.hashCode());
    i = 31 * i + (this.structuredData == null ? 0 : this.structuredData.hashCode());
    return i;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if (getClass() != paramObject.getClass())
      return false;
    StructuredSyslogMessage localStructuredSyslogMessage = (StructuredSyslogMessage)paramObject;
    if (this.message == null)
    {
      if (localStructuredSyslogMessage.message != null)
        return false;
    }
    else if (!this.message.equals(localStructuredSyslogMessage.message))
      return false;
    if (this.messageId == null)
    {
      if (localStructuredSyslogMessage.messageId != null)
        return false;
    }
    else if (!this.messageId.equals(localStructuredSyslogMessage.messageId))
      return false;
    if (this.structuredData == null)
    {
      if (localStructuredSyslogMessage.structuredData != null)
        return false;
    }
    else if (!this.structuredData.equals(localStructuredSyslogMessage.structuredData))
      return false;
    return true;
  }

  public String toString()
  {
    return serialize();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessage
 * JD-Core Version:    0.6.0
 */