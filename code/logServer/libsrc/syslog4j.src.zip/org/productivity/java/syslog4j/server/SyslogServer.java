package org.productivity.java.syslog4j.server;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfig;
import org.productivity.java.syslog4j.server.impl.net.udp.UDPNetSyslogServerConfig;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class SyslogServer
  implements SyslogConstants
{
  private static final long serialVersionUID = -2260889360828258602L;
  private static boolean SUPPRESS_RUNTIME_EXCEPTIONS = false;
  protected static final Map instances = new Hashtable();

  public static final String getVersion()
  {
    return "Syslog4j 0.9.46 2011-01-23 14:49:24 jpy";
  }

  public static void setSuppressRuntimeExceptions(boolean paramBoolean)
  {
    SUPPRESS_RUNTIME_EXCEPTIONS = paramBoolean;
  }

  public static boolean getSuppressRuntimeExceptions()
  {
    return SUPPRESS_RUNTIME_EXCEPTIONS;
  }

  private static void throwRuntimeException(String paramString)
    throws SyslogRuntimeException
  {
    if (SUPPRESS_RUNTIME_EXCEPTIONS)
      return;
    throw new SyslogRuntimeException(paramString.toString());
  }

  public static final SyslogServerIF getInstance(String paramString)
    throws SyslogRuntimeException
  {
    String str = paramString.toLowerCase();
    if (instances.containsKey(str))
      return (SyslogServerIF)instances.get(str);
    throwRuntimeException("SyslogServer instance \"" + str + "\" not defined; use \"tcp\" or \"udp\" or call SyslogServer.createInstance(protocol,config) first");
    return null;
  }

  public static final SyslogServerIF getThreadedInstance(String paramString)
    throws SyslogRuntimeException
  {
    SyslogServerIF localSyslogServerIF = getInstance(paramString);
    if (localSyslogServerIF.getThread() == null)
    {
      Thread localThread = new Thread(localSyslogServerIF);
      localThread.setName("SyslogServer: " + paramString);
      localThread.setDaemon(localSyslogServerIF.getConfig().isUseDaemonThread());
      if (localSyslogServerIF.getConfig().getThreadPriority() > -1)
        localThread.setPriority(localSyslogServerIF.getConfig().getThreadPriority());
      localSyslogServerIF.setThread(localThread);
      localThread.start();
    }
    return localSyslogServerIF;
  }

  public static final boolean exists(String paramString)
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
      return false;
    return instances.containsKey(paramString.toLowerCase());
  }

  public static final SyslogServerIF createInstance(String paramString, SyslogServerConfigIF paramSyslogServerConfigIF)
    throws SyslogRuntimeException
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
    {
      throwRuntimeException("Instance protocol cannot be null or empty");
      return null;
    }
    if (paramSyslogServerConfigIF == null)
    {
      throwRuntimeException("SyslogServerConfig cannot be null");
      return null;
    }
    String str = paramString.toLowerCase();
    SyslogServerIF localSyslogServerIF = null;
    synchronized (instances)
    {
      if (instances.containsKey(str))
      {
        throwRuntimeException("SyslogServer instance \"" + str + "\" already defined.");
        return null;
      }
      try
      {
        Class localClass = paramSyslogServerConfigIF.getSyslogServerClass();
        localSyslogServerIF = (SyslogServerIF)localClass.newInstance();
      }
      catch (ClassCastException localClassCastException)
      {
        throw new SyslogRuntimeException(localClassCastException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new SyslogRuntimeException(localIllegalAccessException);
      }
      catch (InstantiationException localInstantiationException)
      {
        throw new SyslogRuntimeException(localInstantiationException);
      }
      localSyslogServerIF.initialize(str, paramSyslogServerConfigIF);
      instances.put(str, localSyslogServerIF);
    }
    return localSyslogServerIF;
  }

  public static final SyslogServerIF createThreadedInstance(String paramString, SyslogServerConfigIF paramSyslogServerConfigIF)
    throws SyslogRuntimeException
  {
    createInstance(paramString, paramSyslogServerConfigIF);
    SyslogServerIF localSyslogServerIF = getThreadedInstance(paramString);
    return localSyslogServerIF;
  }

  public static final synchronized void destroyInstance(String paramString)
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
      return;
    String str = paramString.toLowerCase();
    if (instances.containsKey(str))
    {
      SyslogUtility.sleep(500L);
      SyslogServerIF localSyslogServerIF = (SyslogServerIF)instances.get(str);
      try
      {
        localSyslogServerIF.shutdown();
      }
      finally
      {
        instances.remove(str);
      }
    }
    else
    {
      throwRuntimeException("Cannot destroy server protocol \"" + paramString + "\" instance; call shutdown instead");
      return;
    }
  }

  public static final synchronized void destroyInstance(SyslogServerIF paramSyslogServerIF)
  {
    if (paramSyslogServerIF == null)
      return;
    String str = paramSyslogServerIF.getProtocol().toLowerCase();
    if (instances.containsKey(str))
    {
      SyslogUtility.sleep(500L);
      try
      {
        paramSyslogServerIF.shutdown();
      }
      finally
      {
        instances.remove(str);
      }
    }
    else
    {
      throwRuntimeException("Cannot destroy server protocol \"" + str + "\" instance; call shutdown instead");
    }
  }

  public static synchronized void initialize()
  {
    createInstance("udp", new UDPNetSyslogServerConfig());
    createInstance("tcp", new TCPNetSyslogServerConfig());
  }

  public static final synchronized void shutdown()
    throws SyslogRuntimeException
  {
    Set localSet = instances.keySet();
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      SyslogServerIF localSyslogServerIF = (SyslogServerIF)instances.get(str);
      localSyslogServerIF.shutdown();
    }
    instances.clear();
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    SyslogServerMain.main(paramArrayOfString);
  }

  static
  {
    initialize();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServer
 * JD-Core Version:    0.6.0
 */