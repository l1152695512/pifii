package org.productivity.java.syslog4j;

import java.io.Serializable;

public abstract interface SyslogMessageIF extends Serializable
{
  public abstract String createMessage();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogMessageIF
 * JD-Core Version:    0.6.0
 */