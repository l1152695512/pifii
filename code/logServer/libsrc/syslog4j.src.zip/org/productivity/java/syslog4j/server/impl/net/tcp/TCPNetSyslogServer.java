package org.productivity.java.syslog4j.server.impl.net.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Iterator;
import javax.net.ServerSocketFactory;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.SyslogServerIF;
import org.productivity.java.syslog4j.server.impl.AbstractSyslogServer;
import org.productivity.java.syslog4j.server.impl.AbstractSyslogServer.Sessions;
import org.productivity.java.syslog4j.server.impl.AbstractSyslogServerConfig;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class TCPNetSyslogServer extends AbstractSyslogServer
{
  protected ServerSocket serverSocket = null;
  protected final AbstractSyslogServer.Sessions sessions = new AbstractSyslogServer.Sessions();
  protected TCPNetSyslogServerConfigIF tcpNetSyslogServerConfig = null;

  public void initialize()
    throws SyslogRuntimeException
  {
    this.tcpNetSyslogServerConfig = null;
    try
    {
      this.tcpNetSyslogServerConfig = ((TCPNetSyslogServerConfigIF)this.syslogServerConfig);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must be of type TCPNetSyslogServerConfig");
    }
    if (this.syslogServerConfig == null)
      throw new SyslogRuntimeException("config cannot be null");
    if (this.tcpNetSyslogServerConfig.getBacklog() < 1)
      this.tcpNetSyslogServerConfig.setBacklog(50);
  }

  public AbstractSyslogServer.Sessions getSessions()
  {
    return this.sessions;
  }

  public synchronized void shutdown()
  {
    super.shutdown();
    try
    {
      if (this.serverSocket != null)
      {
        if (this.syslogServerConfig.getShutdownWait() > 0L)
          SyslogUtility.sleep(this.syslogServerConfig.getShutdownWait());
        this.serverSocket.close();
      }
      synchronized (this.sessions)
      {
        Iterator localIterator = this.sessions.getSockets();
        if (localIterator != null)
          while (localIterator.hasNext())
          {
            Socket localSocket = (Socket)localIterator.next();
            localSocket.close();
          }
      }
    }
    catch (IOException localIOException)
    {
    }
    if (this.thread != null)
    {
      this.thread.interrupt();
      this.thread = null;
    }
  }

  protected ServerSocketFactory getServerSocketFactory()
    throws IOException
  {
    ServerSocketFactory localServerSocketFactory = ServerSocketFactory.getDefault();
    return localServerSocketFactory;
  }

  protected ServerSocket createServerSocket()
    throws IOException
  {
    ServerSocket localServerSocket = null;
    ServerSocketFactory localServerSocketFactory = getServerSocketFactory();
    if (this.syslogServerConfig.getHost() != null)
    {
      InetAddress localInetAddress = InetAddress.getByName(this.syslogServerConfig.getHost());
      localServerSocket = localServerSocketFactory.createServerSocket(this.syslogServerConfig.getPort(), this.tcpNetSyslogServerConfig.getBacklog(), localInetAddress);
    }
    else if (this.tcpNetSyslogServerConfig.getBacklog() < 1)
    {
      localServerSocket = localServerSocketFactory.createServerSocket(this.syslogServerConfig.getPort());
    }
    else
    {
      localServerSocket = localServerSocketFactory.createServerSocket(this.syslogServerConfig.getPort(), this.tcpNetSyslogServerConfig.getBacklog());
    }
    return localServerSocket;
  }

  public void run()
  {
    try
    {
      this.serverSocket = createServerSocket();
      this.shutdown = false;
    }
    catch (SocketException localSocketException1)
    {
      throw new SyslogRuntimeException(localSocketException1);
    }
    catch (IOException localIOException1)
    {
      throw new SyslogRuntimeException(localIOException1);
    }
    handleInitialize(this);
    while (!this.shutdown)
      try
      {
        Socket localSocket = this.serverSocket.accept();
        if (this.tcpNetSyslogServerConfig.getTimeout() > 0)
          localSocket.setSoTimeout(this.tcpNetSyslogServerConfig.getTimeout());
        if ((this.tcpNetSyslogServerConfig.getMaxActiveSockets() > 0) && (this.sessions.size() >= this.tcpNetSyslogServerConfig.getMaxActiveSockets()))
          if (this.tcpNetSyslogServerConfig.getMaxActiveSocketsBehavior() == 1)
          {
            try
            {
              localSocket.close();
            }
            catch (Exception localException)
            {
            }
            localSocket = null;
          }
          else if (this.tcpNetSyslogServerConfig.getMaxActiveSocketsBehavior() == 0)
          {
            while ((!this.shutdown) && (this.sessions.size() >= this.tcpNetSyslogServerConfig.getMaxActiveSockets()) && (localSocket.isConnected()) && (!localSocket.isClosed()))
              SyslogUtility.sleep(500L);
          }
        if (localSocket != null)
        {
          TCPNetSyslogSocketHandler localTCPNetSyslogSocketHandler = new TCPNetSyslogSocketHandler(this.sessions, this, localSocket);
          Thread localThread = new Thread(localTCPNetSyslogSocketHandler);
          localThread.start();
        }
      }
      catch (SocketException localSocketException2)
      {
        if ("Socket closed".equals(localSocketException2.getMessage()))
          this.shutdown = true;
      }
      catch (IOException localIOException2)
      {
      }
    handleDestroy(this);
  }

  public static class TCPNetSyslogSocketHandler
    implements Runnable
  {
    protected SyslogServerIF server = null;
    protected Socket socket = null;
    protected AbstractSyslogServer.Sessions sessions = null;

    public TCPNetSyslogSocketHandler(AbstractSyslogServer.Sessions paramSessions, SyslogServerIF paramSyslogServerIF, Socket paramSocket)
    {
      this.sessions = paramSessions;
      this.server = paramSyslogServerIF;
      this.socket = paramSocket;
      synchronized (this.sessions)
      {
        this.sessions.addSocket(paramSocket);
      }
    }

    public void run()
    {
      boolean bool = false;
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
        String str = localBufferedReader.readLine();
        if (str != null)
          AbstractSyslogServer.handleSessionOpen(this.sessions, this.server, this.socket);
        while ((str != null) && (str.length() != 0))
        {
          SyslogServerEventIF localSyslogServerEventIF = TCPNetSyslogServer.access$000(this.server.getConfig(), str, this.socket.getInetAddress());
          AbstractSyslogServer.handleEvent(this.sessions, this.server, this.socket, localSyslogServerEventIF);
          str = localBufferedReader.readLine();
        }
      }
      catch (SocketTimeoutException localSocketTimeoutException)
      {
        bool = true;
      }
      catch (SocketException localSocketException)
      {
        AbstractSyslogServer.handleException(this.sessions, this.server, this.socket.getRemoteSocketAddress(), localSocketException);
        if (!"Socket closed".equals(localSocketException.getMessage()));
      }
      catch (IOException localIOException1)
      {
        AbstractSyslogServer.handleException(this.sessions, this.server, this.socket.getRemoteSocketAddress(), localIOException1);
      }
      try
      {
        AbstractSyslogServer.handleSessionClosed(this.sessions, this.server, this.socket, bool);
        this.sessions.removeSocket(this.socket);
        this.socket.close();
      }
      catch (IOException localIOException2)
      {
        AbstractSyslogServer.handleException(this.sessions, this.server, this.socket.getRemoteSocketAddress(), localIOException2);
      }
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServer
 * JD-Core Version:    0.6.0
 */