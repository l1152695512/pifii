package org.productivity.java.syslog4j.impl.net;

import java.net.InetAddress;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractNetSyslog extends AbstractSyslog
{
  private static final long serialVersionUID = -3250858945515853967L;
  protected static final Object cachedHostAddressSyncObject = new Object();
  protected InetAddress cachedHostAddress = null;
  protected AbstractNetSyslogConfigIF netSyslogConfig = null;

  protected void initialize()
    throws SyslogRuntimeException
  {
    try
    {
      this.netSyslogConfig = ((AbstractNetSyslogConfigIF)this.syslogConfig);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must implement interface AbstractNetSyslogConfigIF");
    }
  }

  public InetAddress getHostAddress()
  {
    InetAddress localInetAddress = null;
    if (this.netSyslogConfig.isCacheHostAddress())
    {
      if (this.cachedHostAddress == null)
        synchronized (cachedHostAddressSyncObject)
        {
          if (this.cachedHostAddress == null)
            this.cachedHostAddress = SyslogUtility.getInetAddress(this.syslogConfig.getHost());
        }
      localInetAddress = this.cachedHostAddress;
    }
    else
    {
      localInetAddress = SyslogUtility.getInetAddress(this.syslogConfig.getHost());
    }
    return localInetAddress;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.AbstractNetSyslog
 * JD-Core Version:    0.6.0
 */