package org.productivity.java.syslog4j.server;

import java.net.SocketAddress;

public abstract interface SyslogServerSessionEventHandlerIF extends SyslogServerEventHandlerIF
{
  public abstract Object sessionOpened(SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress);

  public abstract void event(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, SyslogServerEventIF paramSyslogServerEventIF);

  public abstract void exception(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, Exception paramException);

  public abstract void sessionClosed(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, boolean paramBoolean);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerSessionEventHandlerIF
 * JD-Core Version:    0.6.0
 */