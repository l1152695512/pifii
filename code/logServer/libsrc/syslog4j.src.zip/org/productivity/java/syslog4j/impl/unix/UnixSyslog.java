package org.productivity.java.syslog4j.impl.unix;

import com.sun.jna.Library;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import org.productivity.java.syslog4j.SyslogMessageProcessorIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;
import org.productivity.java.syslog4j.util.OSDetectUtility;

public class UnixSyslog extends AbstractSyslog
{
  private static final long serialVersionUID = 4973353204252276740L;
  protected UnixSyslogConfig unixSyslogConfig = null;
  protected static int currentFacility = -1;
  protected static boolean openlogCalled = false;
  protected static CLibrary libraryInstance = null;

  protected static synchronized void loadLibrary(UnixSyslogConfig paramUnixSyslogConfig)
    throws SyslogRuntimeException
  {
    if (!OSDetectUtility.isUnix())
      throw new SyslogRuntimeException("UnixSyslog not supported on non-Unix platforms");
    if (libraryInstance == null)
      libraryInstance = (CLibrary)Native.loadLibrary(paramUnixSyslogConfig.getLibrary(), CLibrary.class);
  }

  public void initialize()
    throws SyslogRuntimeException
  {
    try
    {
      this.unixSyslogConfig = ((UnixSyslogConfig)this.syslogConfig);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must be of type UnixSyslogConfig");
    }
    loadLibrary(this.unixSyslogConfig);
  }

  protected static void write(int paramInt, String paramString, UnixSyslogConfig paramUnixSyslogConfig)
    throws SyslogRuntimeException
  {
    synchronized (libraryInstance)
    {
      if (currentFacility != paramUnixSyslogConfig.getFacility())
      {
        if (openlogCalled)
        {
          libraryInstance.closelog();
          openlogCalled = false;
        }
        currentFacility = paramUnixSyslogConfig.getFacility();
      }
      if (!openlogCalled)
      {
        String str = paramUnixSyslogConfig.getIdent();
        if ((str != null) && ("".equals(str.trim())))
          str = null;
        Memory localMemory = null;
        if (str != null)
        {
          localMemory = new Memory(128L);
          localMemory.setString(0L, str, false);
        }
        libraryInstance.openlog(localMemory, paramUnixSyslogConfig.getOption(), currentFacility);
        openlogCalled = true;
      }
      int i = currentFacility | paramInt;
      libraryInstance.syslog(i, "%s", paramString);
    }
  }

  protected void write(int paramInt, byte[] paramArrayOfByte)
    throws SyslogRuntimeException
  {
  }

  public void log(SyslogMessageProcessorIF paramSyslogMessageProcessorIF, int paramInt, String paramString)
  {
    write(paramInt, paramString, this.unixSyslogConfig);
  }

  public void flush()
    throws SyslogRuntimeException
  {
    synchronized (libraryInstance)
    {
      libraryInstance.closelog();
      openlogCalled = false;
    }
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    flush();
  }

  public AbstractSyslogWriter getWriter()
  {
    return null;
  }

  public void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
  }

  protected static abstract interface CLibrary extends Library
  {
    public abstract void openlog(Memory paramMemory, int paramInt1, int paramInt2);

    public abstract void syslog(int paramInt, String paramString1, String paramString2);

    public abstract void closelog();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.unix.UnixSyslog
 * JD-Core Version:    0.6.0
 */