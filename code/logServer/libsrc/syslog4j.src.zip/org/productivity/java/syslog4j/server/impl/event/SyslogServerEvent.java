package org.productivity.java.syslog4j.server.impl.event;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class SyslogServerEvent
  implements SyslogServerEventIF
{
  private static final long serialVersionUID = 6136043067089899962L;
  public static final String DATE_FORMAT = "MMM dd HH:mm:ss yyyy";
  protected String charSet = "UTF-8";
  protected String rawString = null;
  protected byte[] rawBytes = null;
  protected int rawLength = -1;
  protected Date date = null;
  protected int level = -1;
  protected int facility = -1;
  protected String host = null;
  protected boolean isHostStrippedFromMessage = false;
  protected String message = null;
  protected InetAddress inetAddress = null;

  protected SyslogServerEvent()
  {
  }

  public SyslogServerEvent(String paramString, InetAddress paramInetAddress)
  {
    initialize(paramString, paramInetAddress);
    parse();
  }

  public SyslogServerEvent(byte[] paramArrayOfByte, int paramInt, InetAddress paramInetAddress)
  {
    initialize(paramArrayOfByte, paramInt, paramInetAddress);
    parse();
  }

  protected void initialize(String paramString, InetAddress paramInetAddress)
  {
    this.rawString = paramString;
    this.rawLength = paramString.length();
    this.inetAddress = paramInetAddress;
    this.message = paramString;
  }

  protected void initialize(byte[] paramArrayOfByte, int paramInt, InetAddress paramInetAddress)
  {
    this.rawBytes = paramArrayOfByte;
    this.rawLength = paramInt;
    this.inetAddress = paramInetAddress;
  }

  protected void parseHost()
  {
    int i = this.message.indexOf(' ');
    if (i > -1)
    {
      String str1 = null;
      String str2 = null;
      String str3 = this.message.substring(0, i).trim();
      str1 = this.inetAddress.getHostAddress();
      if (str3.equalsIgnoreCase(str1))
      {
        this.host = str1;
        this.message = this.message.substring(i + 1);
        this.isHostStrippedFromMessage = true;
      }
      if (this.host == null)
      {
        str2 = this.inetAddress.getHostName();
        if (!str2.equalsIgnoreCase(str1))
        {
          if (str3.equalsIgnoreCase(str2))
          {
            this.host = str2;
            this.message = this.message.substring(i + 1);
            this.isHostStrippedFromMessage = true;
          }
          if (this.host == null)
          {
            int j = str2.indexOf('.');
            if (j > -1)
              str2 = str2.substring(0, j);
            if (str3.equalsIgnoreCase(str2))
            {
              this.host = str2;
              this.message = this.message.substring(i + 1);
              this.isHostStrippedFromMessage = true;
            }
          }
        }
      }
      if (this.host == null)
        this.host = (str2 != null ? str2 : str1);
    }
  }

  protected void parseDate()
  {
    if ((this.message.length() >= 16) && (this.message.charAt(3) == ' ') && (this.message.charAt(6) == ' '))
    {
      String str1 = Integer.toString(Calendar.getInstance().get(1));
      String str2 = this.message.substring(0, 15) + " " + str1;
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("MMM dd HH:mm:ss yyyy");
      try
      {
        this.date = localSimpleDateFormat.parse(str2);
        this.message = this.message.substring(16);
      }
      catch (ParseException localParseException)
      {
        this.date = new Date();
      }
    }
    parseHost();
  }

  protected void parsePriority()
  {
    if (this.message.charAt(0) == '<')
    {
      int i = this.message.indexOf(">");
      if ((i <= 4) && (i > -1))
      {
        String str = this.message.substring(1, i);
        int j = 0;
        try
        {
          j = Integer.parseInt(str);
          this.facility = (j >> 3);
          this.level = (j - (this.facility << 3));
          this.message = this.message.substring(i + 1);
          parseDate();
        }
        catch (NumberFormatException localNumberFormatException)
        {
        }
        parseHost();
      }
    }
  }

  protected void parse()
  {
    if (this.message == null)
      this.message = SyslogUtility.newString(this, this.rawBytes, this.rawLength);
    parsePriority();
  }

  public int getFacility()
  {
    return this.facility;
  }

  public void setFacility(int paramInt)
  {
    this.facility = paramInt;
  }

  public byte[] getRaw()
  {
    if (this.rawString != null)
    {
      arrayOfByte = SyslogUtility.getBytes(this, this.rawString);
      return arrayOfByte;
    }
    if (this.rawBytes.length == this.rawLength)
      return this.rawBytes;
    byte[] arrayOfByte = new byte[this.rawLength];
    System.arraycopy(this.rawBytes, 0, arrayOfByte, 0, this.rawLength);
    return arrayOfByte;
  }

  public int getRawLength()
  {
    return this.rawLength;
  }

  public Date getDate()
  {
    return this.date;
  }

  public void setDate(Date paramDate)
  {
    this.date = paramDate;
  }

  public int getLevel()
  {
    return this.level;
  }

  public void setLevel(int paramInt)
  {
    this.level = paramInt;
  }

  public String getHost()
  {
    return this.host;
  }

  public void setHost(String paramString)
  {
    this.host = paramString;
  }

  public boolean isHostStrippedFromMessage()
  {
    return this.isHostStrippedFromMessage;
  }

  public String getMessage()
  {
    return this.message;
  }

  public void setMessage(String paramString)
  {
    this.message = paramString;
  }

  public String getCharSet()
  {
    return this.charSet;
  }

  public void setCharSet(String paramString)
  {
    this.charSet = paramString;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.event.SyslogServerEvent
 * JD-Core Version:    0.6.0
 */