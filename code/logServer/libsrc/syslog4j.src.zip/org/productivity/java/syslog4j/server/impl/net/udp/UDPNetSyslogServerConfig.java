package org.productivity.java.syslog4j.server.impl.net.udp;

import org.productivity.java.syslog4j.server.impl.net.AbstractNetSyslogServerConfig;

public class UDPNetSyslogServerConfig extends AbstractNetSyslogServerConfig
{
  private static final long serialVersionUID = -2005919161187055486L;

  public UDPNetSyslogServerConfig()
  {
  }

  public UDPNetSyslogServerConfig(int paramInt)
  {
    this.port = paramInt;
  }

  public UDPNetSyslogServerConfig(String paramString)
  {
    this.host = paramString;
  }

  public UDPNetSyslogServerConfig(String paramString, int paramInt)
  {
    this.host = paramString;
    this.port = paramInt;
  }

  public Class getSyslogServerClass()
  {
    return UDPNetSyslogServer.class;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.udp.UDPNetSyslogServerConfig
 * JD-Core Version:    0.6.0
 */