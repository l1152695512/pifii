package org.productivity.java.syslog4j;

public final class Syslog4jVersion
{
  public static final String VERSION = "Syslog4j 0.9.46 2011-01-23 14:49:24 jpy";
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.Syslog4jVersion
 * JD-Core Version:    0.6.0
 */