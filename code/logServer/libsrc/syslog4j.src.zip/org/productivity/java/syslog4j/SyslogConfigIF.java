package org.productivity.java.syslog4j;

public abstract interface SyslogConfigIF extends SyslogConstants, SyslogCharSetIF
{
  public abstract Class getSyslogClass();

  public abstract int getFacility();

  public abstract void setFacility(int paramInt);

  public abstract void setFacility(String paramString);

  public abstract int getPort();

  public abstract void setPort(int paramInt)
    throws SyslogRuntimeException;

  public abstract String getLocalName();

  public abstract void setLocalName(String paramString)
    throws SyslogRuntimeException;

  public abstract String getHost();

  public abstract void setHost(String paramString)
    throws SyslogRuntimeException;

  public abstract String getIdent();

  public abstract void setIdent(String paramString);

  public abstract String getCharSet();

  public abstract void setCharSet(String paramString);

  public abstract boolean isIncludeIdentInMessageModifier();

  public abstract void setIncludeIdentInMessageModifier(boolean paramBoolean);

  public abstract boolean isThrowExceptionOnInitialize();

  public abstract void setThrowExceptionOnInitialize(boolean paramBoolean);

  public abstract boolean isThrowExceptionOnWrite();

  public abstract void setThrowExceptionOnWrite(boolean paramBoolean);

  public abstract boolean isSendLocalTimestamp();

  public abstract void setSendLocalTimestamp(boolean paramBoolean);

  public abstract boolean isSendLocalName();

  public abstract void setSendLocalName(boolean paramBoolean);

  public abstract boolean isTruncateMessage();

  public abstract void setTruncateMessage(boolean paramBoolean);

  public abstract boolean isUseStructuredData();

  public abstract void setUseStructuredData(boolean paramBoolean);

  public abstract int getMaxMessageLength();

  public abstract void setMaxMessageLength(int paramInt);

  public abstract void addMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF);

  public abstract void insertMessageModifier(int paramInt, SyslogMessageModifierIF paramSyslogMessageModifierIF);

  public abstract void removeMessageModifier(SyslogMessageModifierIF paramSyslogMessageModifierIF);

  public abstract void removeAllMessageModifiers();

  public abstract void addBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF);

  public abstract void insertBackLogHandler(int paramInt, SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF);

  public abstract void removeBackLogHandler(SyslogBackLogHandlerIF paramSyslogBackLogHandlerIF);

  public abstract void removeAllBackLogHandlers();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogConfigIF
 * JD-Core Version:    0.6.0
 */