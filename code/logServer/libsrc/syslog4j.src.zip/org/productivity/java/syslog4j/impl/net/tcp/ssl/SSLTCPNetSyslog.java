package org.productivity.java.syslog4j.impl.net.tcp.ssl;

import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslog;

public class SSLTCPNetSyslog extends TCPNetSyslog
{
  private static final long serialVersionUID = 2766654802524487317L;

  public void initialize()
    throws SyslogRuntimeException
  {
    super.initialize();
    SSLTCPNetSyslogConfigIF localSSLTCPNetSyslogConfigIF = (SSLTCPNetSyslogConfigIF)this.tcpNetSyslogConfig;
    String str1 = localSSLTCPNetSyslogConfigIF.getKeyStore();
    if ((str1 != null) && (!"".equals(str1.trim())))
      System.setProperty("javax.net.ssl.keyStore", str1);
    String str2 = localSSLTCPNetSyslogConfigIF.getKeyStorePassword();
    if ((str2 != null) && (!"".equals(str2.trim())))
      System.setProperty("javax.net.ssl.keyStorePassword", str2);
    String str3 = localSSLTCPNetSyslogConfigIF.getTrustStore();
    if ((str3 != null) && (!"".equals(str3.trim())))
      System.setProperty("javax.net.ssl.trustStore", str3);
    String str4 = localSSLTCPNetSyslogConfigIF.getTrustStorePassword();
    if ((str4 != null) && (!"".equals(str4.trim())))
      System.setProperty("javax.net.ssl.trustStorePassword", str4);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.ssl.SSLTCPNetSyslog
 * JD-Core Version:    0.6.0
 */