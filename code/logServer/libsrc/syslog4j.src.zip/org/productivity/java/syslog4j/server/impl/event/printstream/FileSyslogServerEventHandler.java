package org.productivity.java.syslog4j.server.impl.event.printstream;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class FileSyslogServerEventHandler extends PrintStreamSyslogServerEventHandler
{
  private static final long serialVersionUID = -755824686809731430L;

  protected static PrintStream createPrintStream(String paramString, boolean paramBoolean)
    throws IOException
  {
    File localFile = new File(paramString);
    FileOutputStream localFileOutputStream = new FileOutputStream(localFile, paramBoolean);
    PrintStream localPrintStream = new PrintStream(localFileOutputStream);
    return localPrintStream;
  }

  public FileSyslogServerEventHandler(String paramString)
    throws IOException
  {
    super(createPrintStream(paramString, true));
  }

  public FileSyslogServerEventHandler(String paramString, boolean paramBoolean)
    throws IOException
  {
    super(createPrintStream(paramString, paramBoolean));
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.event.printstream.FileSyslogServerEventHandler
 * JD-Core Version:    0.6.0
 */