package org.productivity.java.syslog4j.impl.backlog.printstream;

import java.io.PrintStream;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.backlog.AbstractSyslogBackLogHandler;

public class PrintStreamSyslogBackLogHandler extends AbstractSyslogBackLogHandler
{
  protected PrintStream printStream = null;
  protected boolean appendLinefeed = false;

  public PrintStreamSyslogBackLogHandler(PrintStream paramPrintStream)
  {
    this.printStream = paramPrintStream;
    initialize();
  }

  public PrintStreamSyslogBackLogHandler(PrintStream paramPrintStream, boolean paramBoolean)
  {
    this.printStream = paramPrintStream;
    this.appendLinefeed = paramBoolean;
    initialize();
  }

  public PrintStreamSyslogBackLogHandler(PrintStream paramPrintStream, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.printStream = paramPrintStream;
    this.appendLinefeed = paramBoolean1;
    this.appendReason = paramBoolean2;
    initialize();
  }

  public void initialize()
    throws SyslogRuntimeException
  {
    if (this.printStream == null)
      throw new SyslogRuntimeException("PrintStream cannot be null");
  }

  public void down(SyslogIF paramSyslogIF, String paramString)
  {
    this.printStream.println(paramSyslogIF.getProtocol() + ": DOWN" + ((paramString != null) && (!"".equals(paramString.trim())) ? " (" + paramString + ")" : ""));
  }

  public void up(SyslogIF paramSyslogIF)
  {
    this.printStream.println(paramSyslogIF.getProtocol() + ": UP");
  }

  public void log(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
  {
    String str = combine(paramSyslogIF, paramInt, paramString1, paramString2);
    if (this.appendLinefeed)
      this.printStream.println(str);
    else
      this.printStream.print(str);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.printstream.PrintStreamSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */