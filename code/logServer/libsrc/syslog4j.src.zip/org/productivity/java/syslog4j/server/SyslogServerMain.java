package org.productivity.java.syslog4j.server;

import java.io.PrintStream;
import org.productivity.java.syslog4j.server.impl.event.printstream.FileSyslogServerEventHandler;
import org.productivity.java.syslog4j.server.impl.event.printstream.SystemOutSyslogServerEventHandler;
import org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfigIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class SyslogServerMain
{
  public static boolean CALL_SYSTEM_EXIT_ON_FAILURE = true;

  public static void usage(String paramString)
  {
    if (paramString != null)
    {
      System.out.println("Error: " + paramString);
      System.out.println();
    }
    System.out.println("Usage:");
    System.out.println();
    System.out.println("SyslogServer [-h <host>] [-p <port>] [-o <file>] [-a] [-q] <protocol>");
    System.out.println();
    System.out.println("-h <host>    host or IP to bind");
    System.out.println("-p <port>    port to bind");
    System.out.println("-t <timeout> socket timeout (in milliseconds)");
    System.out.println("-o <file>    file to write entries (overwrites by default)");
    System.out.println();
    System.out.println("-a           append to file (instead of overwrite)");
    System.out.println("-q           do not write anything to standard out");
    System.out.println();
    System.out.println("protocol     Syslog4j protocol implementation (tcp, udp, ...)");
  }

  public static Options parseOptions(String[] paramArrayOfString)
  {
    Options localOptions = new Options();
    int i = 0;
    while (i < paramArrayOfString.length)
    {
      String str = paramArrayOfString[(i++)];
      int j = 0;
      if ("-h".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify host with -h";
          return localOptions;
        }
        j = 1;
        localOptions.host = paramArrayOfString[(i++)];
      }
      if ("-p".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify port with -p";
          return localOptions;
        }
        j = 1;
        localOptions.port = paramArrayOfString[(i++)];
      }
      if ("-t".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify value (in milliseconds)";
          return localOptions;
        }
        j = 1;
        localOptions.timeout = paramArrayOfString[(i++)];
      }
      if ("-o".equals(str))
      {
        if (i == paramArrayOfString.length)
        {
          localOptions.usage = "Must specify file with -o";
          return localOptions;
        }
        j = 1;
        localOptions.fileName = paramArrayOfString[(i++)];
      }
      if ("-a".equals(str))
      {
        j = 1;
        localOptions.append = true;
      }
      if ("-q".equals(str))
      {
        j = 1;
        localOptions.quiet = true;
      }
      if (j != 0)
        continue;
      if (localOptions.protocol != null)
      {
        localOptions.usage = "Only one protocol definition allowed";
        return localOptions;
      }
      localOptions.protocol = str;
    }
    if (localOptions.protocol == null)
    {
      localOptions.usage = "Must specify protocol";
      return localOptions;
    }
    if ((localOptions.fileName == null) && (localOptions.append))
    {
      localOptions.usage = "Cannot specify -a without specifying -f <file>";
      return localOptions;
    }
    return localOptions;
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Options localOptions = parseOptions(paramArrayOfString);
    if (localOptions.usage != null)
    {
      usage(localOptions.usage);
      if (CALL_SYSTEM_EXIT_ON_FAILURE)
        System.exit(1);
      else
        return;
    }
    if (!localOptions.quiet)
      System.out.println("SyslogServer " + SyslogServer.getVersion());
    if (!SyslogServer.exists(localOptions.protocol))
    {
      usage("Protocol \"" + localOptions.protocol + "\" not supported");
      if (CALL_SYSTEM_EXIT_ON_FAILURE)
        System.exit(1);
      else
        return;
    }
    SyslogServerIF localSyslogServerIF = SyslogServer.getInstance(localOptions.protocol);
    SyslogServerConfigIF localSyslogServerConfigIF = localSyslogServerIF.getConfig();
    if (localOptions.host != null)
    {
      localSyslogServerConfigIF.setHost(localOptions.host);
      if (!localOptions.quiet)
        System.out.println("Listening on host: " + localOptions.host);
    }
    if (localOptions.port != null)
    {
      localSyslogServerConfigIF.setPort(Integer.parseInt(localOptions.port));
      if (!localOptions.quiet)
        System.out.println("Listening on port: " + localOptions.port);
    }
    if (localOptions.timeout != null)
      if ((localSyslogServerConfigIF instanceof TCPNetSyslogServerConfigIF))
      {
        ((TCPNetSyslogServerConfigIF)localSyslogServerConfigIF).setTimeout(Integer.parseInt(localOptions.timeout));
        if (!localOptions.quiet)
          System.out.println("Timeout: " + localOptions.timeout);
      }
      else
      {
        System.err.println("Timeout not supported for protocol \"" + localOptions.protocol + "\" (ignored)");
      }
    Object localObject;
    if (localOptions.fileName != null)
    {
      localObject = new FileSyslogServerEventHandler(localOptions.fileName, localOptions.append);
      localSyslogServerConfigIF.addEventHandler((SyslogServerEventHandlerIF)localObject);
      if (!localOptions.quiet)
        System.out.println((localOptions.append ? "Appending" : "Writing") + " to file: " + localOptions.fileName);
    }
    if (!localOptions.quiet)
    {
      localObject = SystemOutSyslogServerEventHandler.create();
      localSyslogServerConfigIF.addEventHandler((SyslogServerEventHandlerIF)localObject);
    }
    if (!localOptions.quiet)
      System.out.println();
    SyslogServer.getThreadedInstance(localOptions.protocol);
    while (true)
      SyslogUtility.sleep(1000L);
  }

  public static class Options
  {
    public String protocol = null;
    public String fileName = null;
    public boolean append = false;
    public boolean quiet = false;
    public String host = null;
    public String port = null;
    public String timeout = null;
    public String usage = null;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerMain
 * JD-Core Version:    0.6.0
 */