package org.productivity.java.syslog4j.impl.backlog;

import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;
import org.productivity.java.syslog4j.SyslogIF;

public class NullSyslogBackLogHandler
  implements SyslogBackLogHandlerIF
{
  public static final NullSyslogBackLogHandler INSTANCE = new NullSyslogBackLogHandler();

  public void initialize()
  {
  }

  public void down(SyslogIF paramSyslogIF, String paramString)
  {
  }

  public void up(SyslogIF paramSyslogIF)
  {
  }

  public void log(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
  {
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.NullSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */