package org.productivity.java.syslog4j.impl.multiple;

import java.util.List;
import org.productivity.java.syslog4j.Syslog;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageIF;
import org.productivity.java.syslog4j.SyslogMessageProcessorIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public class MultipleSyslog
  implements SyslogIF
{
  private static final long serialVersionUID = 587308197526365108L;
  protected String syslogProtocol = null;
  protected MultipleSyslogConfig multipleSyslogConfig = null;

  public void initialize(String paramString, SyslogConfigIF paramSyslogConfigIF)
    throws SyslogRuntimeException
  {
    this.syslogProtocol = paramString;
    try
    {
      this.multipleSyslogConfig = ((MultipleSyslogConfig)paramSyslogConfigIF);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must be of type MultipleSyslogConfig");
    }
  }

  public SyslogConfigIF getConfig()
  {
    return this.multipleSyslogConfig;
  }

  public void debug(String paramString)
  {
    log(7, paramString);
  }

  public void debug(SyslogMessageIF paramSyslogMessageIF)
  {
    log(7, paramSyslogMessageIF);
  }

  public void critical(String paramString)
  {
    log(2, paramString);
  }

  public void critical(SyslogMessageIF paramSyslogMessageIF)
  {
    log(2, paramSyslogMessageIF);
  }

  public void error(String paramString)
  {
    log(3, paramString);
  }

  public void error(SyslogMessageIF paramSyslogMessageIF)
  {
    log(3, paramSyslogMessageIF);
  }

  public void alert(String paramString)
  {
    log(1, paramString);
  }

  public void alert(SyslogMessageIF paramSyslogMessageIF)
  {
    log(1, paramSyslogMessageIF);
  }

  public void notice(String paramString)
  {
    log(5, paramString);
  }

  public void notice(SyslogMessageIF paramSyslogMessageIF)
  {
    log(5, paramSyslogMessageIF);
  }

  public void emergency(String paramString)
  {
    log(0, paramString);
  }

  public void emergency(SyslogMessageIF paramSyslogMessageIF)
  {
    log(0, paramSyslogMessageIF);
  }

  public void info(String paramString)
  {
    log(6, paramString);
  }

  public void info(SyslogMessageIF paramSyslogMessageIF)
  {
    log(6, paramSyslogMessageIF);
  }

  public void warn(String paramString)
  {
    log(4, paramString);
  }

  public void warn(SyslogMessageIF paramSyslogMessageIF)
  {
    log(4, paramSyslogMessageIF);
  }

  public void log(int paramInt, String paramString)
  {
    for (int i = 0; i < this.multipleSyslogConfig.getProtocols().size(); i++)
    {
      String str = (String)this.multipleSyslogConfig.getProtocols().get(i);
      SyslogIF localSyslogIF = Syslog.getInstance(str);
      localSyslogIF.log(paramInt, paramString);
    }
  }

  public void log(int paramInt, SyslogMessageIF paramSyslogMessageIF)
  {
    for (int i = 0; i < this.multipleSyslogConfig.getProtocols().size(); i++)
    {
      String str = (String)this.multipleSyslogConfig.getProtocols().get(i);
      SyslogIF localSyslogIF = Syslog.getInstance(str);
      localSyslogIF.log(paramInt, paramSyslogMessageIF);
    }
  }

  public void flush()
    throws SyslogRuntimeException
  {
    for (int i = 0; i < this.multipleSyslogConfig.getProtocols().size(); i++)
    {
      String str = (String)this.multipleSyslogConfig.getProtocols().get(i);
      SyslogIF localSyslogIF = Syslog.getInstance(str);
      localSyslogIF.flush();
    }
  }

  public void shutdown()
    throws SyslogRuntimeException
  {
    for (int i = 0; i < this.multipleSyslogConfig.getProtocols().size(); i++)
    {
      String str = (String)this.multipleSyslogConfig.getProtocols().get(i);
      SyslogIF localSyslogIF = Syslog.getInstance(str);
      localSyslogIF.shutdown();
    }
  }

  public void backLog(int paramInt, String paramString, Throwable paramThrowable)
  {
  }

  public void backLog(int paramInt, String paramString1, String paramString2)
  {
  }

  public void setMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public SyslogMessageProcessorIF getMessageProcessor()
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public void setStructuredMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF)
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public SyslogMessageProcessorIF getStructuredMessageProcessor()
  {
    throw new SyslogRuntimeException("MultipleSyslog is an aggregator; please set the individual protocols");
  }

  public String getProtocol()
  {
    return this.syslogProtocol;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.multiple.MultipleSyslog
 * JD-Core Version:    0.6.0
 */