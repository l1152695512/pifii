package org.productivity.java.syslog4j.impl.message.modifier.mac;

import java.security.Key;
import javax.crypto.spec.SecretKeySpec;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifierConfig;
import org.productivity.java.syslog4j.util.Base64;

public class MacSyslogMessageModifierConfig extends AbstractSyslogMessageModifierConfig
{
  private static final long serialVersionUID = 4524180892377960695L;
  protected String macAlgorithm = null;
  protected String keyAlgorithm = null;
  protected Key key = null;

  public MacSyslogMessageModifierConfig(String paramString1, String paramString2, Key paramKey)
  {
    this.macAlgorithm = paramString1;
    this.keyAlgorithm = paramString2;
    this.key = paramKey;
  }

  public MacSyslogMessageModifierConfig(String paramString1, String paramString2, byte[] paramArrayOfByte)
  {
    this.macAlgorithm = paramString1;
    this.keyAlgorithm = paramString2;
    try
    {
      this.key = new SecretKeySpec(paramArrayOfByte, paramString2);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new SyslogRuntimeException(localIllegalArgumentException);
    }
  }

  public MacSyslogMessageModifierConfig(String paramString1, String paramString2, String paramString3)
  {
    this.macAlgorithm = paramString1;
    this.keyAlgorithm = paramString2;
    byte[] arrayOfByte = Base64.decode(paramString3);
    try
    {
      this.key = new SecretKeySpec(arrayOfByte, paramString2);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new SyslogRuntimeException(localIllegalArgumentException);
    }
  }

  public static MacSyslogMessageModifierConfig createHmacSHA1(Key paramKey)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA1", "SHA1", paramKey);
  }

  public static MacSyslogMessageModifierConfig createHmacSHA1(String paramString)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA1", "SHA1", paramString);
  }

  public static MacSyslogMessageModifierConfig createHmacSHA256(Key paramKey)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA256", "SHA-256", paramKey);
  }

  public static MacSyslogMessageModifierConfig createHmacSHA256(String paramString)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA256", "SHA-256", paramString);
  }

  public static MacSyslogMessageModifierConfig createHmacSHA512(Key paramKey)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA512", "SHA-512", paramKey);
  }

  public static MacSyslogMessageModifierConfig createHmacSHA512(String paramString)
  {
    return new MacSyslogMessageModifierConfig("HmacSHA512", "SHA-512", paramString);
  }

  public static MacSyslogMessageModifierConfig createHmacMD5(Key paramKey)
  {
    return new MacSyslogMessageModifierConfig("HmacMD5", "MD5", paramKey);
  }

  public static MacSyslogMessageModifierConfig createHmacMD5(String paramString)
  {
    return new MacSyslogMessageModifierConfig("HmacMD5", "MD5", paramString);
  }

  public String getMacAlgorithm()
  {
    return this.macAlgorithm;
  }

  public String getKeyAlgorithm()
  {
    return this.keyAlgorithm;
  }

  public Key getKey()
  {
    return this.key;
  }

  public void setKey(Key paramKey)
  {
    this.key = paramKey;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.mac.MacSyslogMessageModifierConfig
 * JD-Core Version:    0.6.0
 */