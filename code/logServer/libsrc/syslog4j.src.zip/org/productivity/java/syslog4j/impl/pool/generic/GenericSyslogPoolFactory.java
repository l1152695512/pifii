package org.productivity.java.syslog4j.impl.pool.generic;

import org.apache.commons.pool.ObjectPool;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.productivity.java.syslog4j.SyslogPoolConfigIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.pool.AbstractSyslogPoolFactory;

public class GenericSyslogPoolFactory extends AbstractSyslogPoolFactory
{
  protected void configureGenericObjectPool(GenericObjectPool paramGenericObjectPool)
    throws SyslogRuntimeException
  {
    SyslogPoolConfigIF localSyslogPoolConfigIF = null;
    try
    {
      localSyslogPoolConfigIF = (SyslogPoolConfigIF)this.syslog.getConfig();
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must implement interface SyslogPoolConfigIF");
    }
    paramGenericObjectPool.setMaxActive(localSyslogPoolConfigIF.getMaxActive());
    paramGenericObjectPool.setMaxIdle(localSyslogPoolConfigIF.getMaxIdle());
    paramGenericObjectPool.setMaxWait(localSyslogPoolConfigIF.getMaxWait());
    paramGenericObjectPool.setMinEvictableIdleTimeMillis(localSyslogPoolConfigIF.getMinEvictableIdleTimeMillis());
    paramGenericObjectPool.setMinIdle(localSyslogPoolConfigIF.getMinIdle());
    paramGenericObjectPool.setNumTestsPerEvictionRun(localSyslogPoolConfigIF.getNumTestsPerEvictionRun());
    paramGenericObjectPool.setSoftMinEvictableIdleTimeMillis(localSyslogPoolConfigIF.getSoftMinEvictableIdleTimeMillis());
    paramGenericObjectPool.setTestOnBorrow(localSyslogPoolConfigIF.isTestOnBorrow());
    paramGenericObjectPool.setTestOnReturn(localSyslogPoolConfigIF.isTestOnReturn());
    paramGenericObjectPool.setTestWhileIdle(localSyslogPoolConfigIF.isTestWhileIdle());
    paramGenericObjectPool.setTimeBetweenEvictionRunsMillis(localSyslogPoolConfigIF.getTimeBetweenEvictionRunsMillis());
    paramGenericObjectPool.setWhenExhaustedAction(localSyslogPoolConfigIF.getWhenExhaustedAction());
  }

  public ObjectPool createPool()
    throws SyslogRuntimeException
  {
    GenericObjectPool localGenericObjectPool = new GenericObjectPool(this);
    configureGenericObjectPool(localGenericObjectPool);
    return localGenericObjectPool;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.pool.generic.GenericSyslogPoolFactory
 * JD-Core Version:    0.6.0
 */