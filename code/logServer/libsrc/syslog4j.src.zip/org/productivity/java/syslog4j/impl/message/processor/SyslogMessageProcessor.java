package org.productivity.java.syslog4j.impl.message.processor;

public class SyslogMessageProcessor extends AbstractSyslogMessageProcessor
{
  private static final long serialVersionUID = -4232803978024990353L;
  private static final SyslogMessageProcessor INSTANCE = new SyslogMessageProcessor();
  protected static SyslogMessageProcessor defaultInstance = INSTANCE;

  public static void setDefault(SyslogMessageProcessor paramSyslogMessageProcessor)
  {
    if (paramSyslogMessageProcessor != null)
      defaultInstance = paramSyslogMessageProcessor;
  }

  public static SyslogMessageProcessor getDefault()
  {
    return defaultInstance;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.processor.SyslogMessageProcessor
 * JD-Core Version:    0.6.0
 */