package org.productivity.java.syslog4j.server.impl;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.productivity.java.syslog4j.SyslogCharSetIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.server.SyslogServerConfigIF;
import org.productivity.java.syslog4j.server.SyslogServerEventHandlerIF;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.SyslogServerIF;
import org.productivity.java.syslog4j.server.SyslogServerSessionEventHandlerIF;
import org.productivity.java.syslog4j.server.SyslogServerSessionlessEventHandlerIF;
import org.productivity.java.syslog4j.server.impl.event.SyslogServerEvent;
import org.productivity.java.syslog4j.server.impl.event.structured.StructuredSyslogServerEvent;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractSyslogServer
  implements SyslogServerIF
{
  protected String syslogProtocol = null;
  protected AbstractSyslogServerConfig syslogServerConfig = null;
  protected Thread thread = null;
  protected boolean shutdown = false;

  public void initialize(String paramString, SyslogServerConfigIF paramSyslogServerConfigIF)
    throws SyslogRuntimeException
  {
    this.syslogProtocol = paramString;
    try
    {
      this.syslogServerConfig = ((AbstractSyslogServerConfig)paramSyslogServerConfigIF);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException(localClassCastException);
    }
    initialize();
  }

  public String getProtocol()
  {
    return this.syslogProtocol;
  }

  public SyslogServerConfigIF getConfig()
  {
    return this.syslogServerConfig;
  }

  protected abstract void initialize()
    throws SyslogRuntimeException;

  public void shutdown()
    throws SyslogRuntimeException
  {
    this.shutdown = true;
  }

  public Thread getThread()
  {
    return this.thread;
  }

  public void setThread(Thread paramThread)
  {
    this.thread = paramThread;
  }

  protected static boolean isStructuredMessage(SyslogCharSetIF paramSyslogCharSetIF, byte[] paramArrayOfByte)
  {
    String str = SyslogUtility.newString(paramSyslogCharSetIF, paramArrayOfByte);
    boolean bool = isStructuredMessage(paramSyslogCharSetIF, str);
    return bool;
  }

  protected static boolean isStructuredMessage(SyslogCharSetIF paramSyslogCharSetIF, String paramString)
  {
    int i = paramString.indexOf('>');
    return (i != -1) && (paramString.length() > i + 1) && (Character.isDigit(paramString.charAt(i + 1)));
  }

  protected static SyslogServerEventIF createEvent(SyslogServerConfigIF paramSyslogServerConfigIF, byte[] paramArrayOfByte, int paramInt, InetAddress paramInetAddress)
  {
    Object localObject = null;
    if ((paramSyslogServerConfigIF.isUseStructuredData()) && (isStructuredMessage(paramSyslogServerConfigIF, paramArrayOfByte)))
    {
      localObject = new StructuredSyslogServerEvent(paramArrayOfByte, paramInt, paramInetAddress);
      if (paramSyslogServerConfigIF.getDateTimeFormatter() != null)
        ((StructuredSyslogServerEvent)localObject).setDateTimeFormatter(paramSyslogServerConfigIF.getDateTimeFormatter());
    }
    else
    {
      localObject = new SyslogServerEvent(paramArrayOfByte, paramInt, paramInetAddress);
    }
    return (SyslogServerEventIF)localObject;
  }

  protected static SyslogServerEventIF createEvent(SyslogServerConfigIF paramSyslogServerConfigIF, String paramString, InetAddress paramInetAddress)
  {
    Object localObject = null;
    if ((paramSyslogServerConfigIF.isUseStructuredData()) && (isStructuredMessage(paramSyslogServerConfigIF, paramString)))
      localObject = new StructuredSyslogServerEvent(paramString, paramInetAddress);
    else
      localObject = new SyslogServerEvent(paramString, paramInetAddress);
    return (SyslogServerEventIF)localObject;
  }

  public static void handleInitialize(SyslogServerIF paramSyslogServerIF)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      try
      {
        localSyslogServerEventHandlerIF.initialize(paramSyslogServerIF);
      }
      catch (Exception localException)
      {
      }
    }
  }

  public static void handleDestroy(SyslogServerIF paramSyslogServerIF)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      try
      {
        localSyslogServerEventHandlerIF.destroy(paramSyslogServerIF);
      }
      catch (Exception localException)
      {
      }
    }
  }

  public static void handleSessionOpen(Sessions paramSessions, SyslogServerIF paramSyslogServerIF, Socket paramSocket)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      if (!(localSyslogServerEventHandlerIF instanceof SyslogServerSessionEventHandlerIF))
        continue;
      try
      {
        Object localObject = ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).sessionOpened(paramSyslogServerIF, paramSocket.getRemoteSocketAddress());
        if (localObject != null)
          paramSessions.addSession(paramSocket, localSyslogServerEventHandlerIF, localObject);
      }
      catch (Exception localException1)
      {
        try
        {
          ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).exception(null, paramSyslogServerIF, paramSocket.getRemoteSocketAddress(), localException1);
        }
        catch (Exception localException2)
        {
        }
      }
    }
  }

  public static void handleSessionClosed(Sessions paramSessions, SyslogServerIF paramSyslogServerIF, Socket paramSocket, boolean paramBoolean)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      if (!(localSyslogServerEventHandlerIF instanceof SyslogServerSessionEventHandlerIF))
        continue;
      Object localObject = paramSessions.getSession(paramSocket, localSyslogServerEventHandlerIF);
      try
      {
        ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).sessionClosed(localObject, paramSyslogServerIF, paramSocket.getRemoteSocketAddress(), paramBoolean);
      }
      catch (Exception localException1)
      {
        try
        {
          ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).exception(localObject, paramSyslogServerIF, paramSocket.getRemoteSocketAddress(), localException1);
        }
        catch (Exception localException2)
        {
        }
      }
    }
  }

  public static void handleEvent(Sessions paramSessions, SyslogServerIF paramSyslogServerIF, DatagramPacket paramDatagramPacket, SyslogServerEventIF paramSyslogServerEventIF)
  {
    handleEvent(paramSessions, paramSyslogServerIF, null, paramDatagramPacket.getSocketAddress(), paramSyslogServerEventIF);
  }

  public static void handleEvent(Sessions paramSessions, SyslogServerIF paramSyslogServerIF, Socket paramSocket, SyslogServerEventIF paramSyslogServerEventIF)
  {
    handleEvent(paramSessions, paramSyslogServerIF, paramSocket, paramSocket.getRemoteSocketAddress(), paramSyslogServerEventIF);
  }

  protected static void handleEvent(Sessions paramSessions, SyslogServerIF paramSyslogServerIF, Socket paramSocket, SocketAddress paramSocketAddress, SyslogServerEventIF paramSyslogServerEventIF)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      Object localObject = (paramSessions != null) && (paramSocket != null) ? paramSessions.getSession(paramSocket, localSyslogServerEventHandlerIF) : null;
      if ((localSyslogServerEventHandlerIF instanceof SyslogServerSessionEventHandlerIF))
      {
        try
        {
          ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).event(localObject, paramSyslogServerIF, paramSocketAddress, paramSyslogServerEventIF);
        }
        catch (Exception localException1)
        {
          try
          {
            ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).exception(localObject, paramSyslogServerIF, paramSocketAddress, localException1);
          }
          catch (Exception localException3)
          {
          }
        }
      }
      else
      {
        if (!(localSyslogServerEventHandlerIF instanceof SyslogServerSessionlessEventHandlerIF))
          continue;
        try
        {
          ((SyslogServerSessionlessEventHandlerIF)localSyslogServerEventHandlerIF).event(paramSyslogServerIF, paramSocketAddress, paramSyslogServerEventIF);
        }
        catch (Exception localException2)
        {
          try
          {
            ((SyslogServerSessionlessEventHandlerIF)localSyslogServerEventHandlerIF).exception(paramSyslogServerIF, paramSocketAddress, localException2);
          }
          catch (Exception localException4)
          {
          }
        }
      }
    }
  }

  public static void handleException(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, Exception paramException)
  {
    List localList = paramSyslogServerIF.getConfig().getEventHandlers();
    for (int i = 0; i < localList.size(); i++)
    {
      SyslogServerEventHandlerIF localSyslogServerEventHandlerIF = (SyslogServerEventHandlerIF)localList.get(i);
      if ((localSyslogServerEventHandlerIF instanceof SyslogServerSessionEventHandlerIF))
      {
        try
        {
          ((SyslogServerSessionEventHandlerIF)localSyslogServerEventHandlerIF).exception(paramObject, paramSyslogServerIF, paramSocketAddress, paramException);
        }
        catch (Exception localException1)
        {
        }
      }
      else
      {
        if (!(localSyslogServerEventHandlerIF instanceof SyslogServerSessionlessEventHandlerIF))
          continue;
        try
        {
          ((SyslogServerSessionlessEventHandlerIF)localSyslogServerEventHandlerIF).exception(paramSyslogServerIF, paramSocketAddress, paramException);
        }
        catch (Exception localException2)
        {
        }
      }
    }
  }

  public static class Sessions extends HashMap
  {
    private static final long serialVersionUID = -4438949276263772580L;
    public static final Object syncObject = new Object();

    public void addSocket(Socket paramSocket)
    {
      synchronized (syncObject)
      {
        put(paramSocket, new HashMap());
      }
    }

    public Iterator getSockets()
    {
      if (size() > 0)
        return keySet().iterator();
      return null;
    }

    public void addSession(Socket paramSocket, SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF, Object paramObject)
    {
      synchronized (syncObject)
      {
        Object localObject1 = getHandlerMap(paramSocket);
        if (localObject1 == null)
          localObject1 = new HashMap();
        ((Map)localObject1).put(paramSyslogServerEventHandlerIF, paramObject);
      }
    }

    public void removeSocket(Socket paramSocket)
    {
      synchronized (syncObject)
      {
        Map localMap = getHandlerMap(paramSocket);
        if (localMap != null)
          localMap.clear();
      }
    }

    protected Map getHandlerMap(Socket paramSocket)
    {
      Map localMap = null;
      if (containsKey(paramSocket))
        localMap = (Map)get(paramSocket);
      return localMap;
    }

    public Object getSession(Socket paramSocket, SyslogServerEventHandlerIF paramSyslogServerEventHandlerIF)
    {
      synchronized (syncObject)
      {
        Map localMap = getHandlerMap(paramSocket);
        Object localObject1 = localMap.get(paramSyslogServerEventHandlerIF);
        return localObject1;
      }
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.AbstractSyslogServer
 * JD-Core Version:    0.6.0
 */