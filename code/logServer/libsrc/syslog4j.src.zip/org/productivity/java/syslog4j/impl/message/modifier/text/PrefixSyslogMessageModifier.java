package org.productivity.java.syslog4j.impl.message.modifier.text;

import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;

public class PrefixSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = 6718826215583513972L;
  protected String prefix = null;
  protected String delimiter = " ";

  public PrefixSyslogMessageModifier()
  {
  }

  public PrefixSyslogMessageModifier(String paramString)
  {
    this.prefix = paramString;
  }

  public PrefixSyslogMessageModifier(String paramString1, String paramString2)
  {
    this.prefix = paramString1;
    if (paramString2 != null)
      this.delimiter = paramString2;
  }

  public String getPrefix()
  {
    return this.prefix;
  }

  public void setPrefix(String paramString)
  {
    this.prefix = paramString;
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    if ((this.prefix == null) || ("".equals(this.prefix.trim())))
      return paramString;
    return this.prefix + this.delimiter + paramString;
  }

  public boolean verify(String paramString)
  {
    return true;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.text.PrefixSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */