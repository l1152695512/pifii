package org.productivity.java.syslog4j;

import java.io.Serializable;

public abstract interface SyslogCharSetIF extends Serializable
{
  public abstract String getCharSet();

  public abstract void setCharSet(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogCharSetIF
 * JD-Core Version:    0.6.0
 */