package org.productivity.java.syslog4j.server;

import java.util.Date;
import org.productivity.java.syslog4j.SyslogCharSetIF;

public abstract interface SyslogServerEventIF extends SyslogCharSetIF
{
  public abstract byte[] getRaw();

  public abstract int getFacility();

  public abstract void setFacility(int paramInt);

  public abstract Date getDate();

  public abstract void setDate(Date paramDate);

  public abstract int getLevel();

  public abstract void setLevel(int paramInt);

  public abstract String getHost();

  public abstract void setHost(String paramString);

  public abstract boolean isHostStrippedFromMessage();

  public abstract String getMessage();

  public abstract void setMessage(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.SyslogServerEventIF
 * JD-Core Version:    0.6.0
 */