package org.productivity.java.syslog4j.impl.message.processor.structured;

import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.productivity.java.syslog4j.impl.message.processor.AbstractSyslogMessageProcessor;
import org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessage;

public class StructuredSyslogMessageProcessor extends AbstractSyslogMessageProcessor
{
  private static final long serialVersionUID = -1563777226913475257L;
  public static String VERSION = "1";
  private static final StructuredSyslogMessageProcessor INSTANCE = new StructuredSyslogMessageProcessor();
  protected static StructuredSyslogMessageProcessor defaultInstance = INSTANCE;
  private String applicationName = "unknown";
  private String processId = "-";
  private DateTimeFormatter dateTimeFormatter = ISODateTimeFormat.dateTime();

  public static void setDefault(StructuredSyslogMessageProcessor paramStructuredSyslogMessageProcessor)
  {
    if (paramStructuredSyslogMessageProcessor != null)
      defaultInstance = paramStructuredSyslogMessageProcessor;
  }

  public static StructuredSyslogMessageProcessor getDefault()
  {
    return defaultInstance;
  }

  public StructuredSyslogMessageProcessor()
  {
  }

  public StructuredSyslogMessageProcessor(String paramString)
  {
    this.applicationName = paramString;
  }

  public DateTimeFormatter getDateTimeFormatter()
  {
    return this.dateTimeFormatter;
  }

  public void setDateTimeFormatter(DateTimeFormatter paramDateTimeFormatter)
  {
    this.dateTimeFormatter = paramDateTimeFormatter;
  }

  public String getApplicationName()
  {
    return this.applicationName;
  }

  public void setApplicationName(String paramString)
  {
    this.applicationName = paramString;
  }

  public String getProcessId()
  {
    return this.processId;
  }

  public void setProcessId(String paramString)
  {
    this.processId = paramString;
  }

  public String createSyslogHeader(int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    appendPriority(localStringBuffer, paramInt1, paramInt2);
    localStringBuffer.append(VERSION);
    localStringBuffer.append(' ');
    getDateTimeFormatter().printTo(localStringBuffer, System.currentTimeMillis());
    localStringBuffer.append(' ');
    appendLocalName(localStringBuffer, paramString);
    localStringBuffer.append(StructuredSyslogMessage.nilProtect(this.applicationName)).append(' ');
    localStringBuffer.append(StructuredSyslogMessage.nilProtect(this.processId)).append(' ');
    return localStringBuffer.toString();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.processor.structured.StructuredSyslogMessageProcessor
 * JD-Core Version:    0.6.0
 */