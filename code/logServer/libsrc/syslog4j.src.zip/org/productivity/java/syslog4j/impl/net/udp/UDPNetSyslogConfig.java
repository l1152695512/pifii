package org.productivity.java.syslog4j.impl.net.udp;

import org.productivity.java.syslog4j.impl.net.AbstractNetSyslogConfig;

public class UDPNetSyslogConfig extends AbstractNetSyslogConfig
{
  private static final long serialVersionUID = 4465067182562754345L;

  public UDPNetSyslogConfig()
  {
  }

  public UDPNetSyslogConfig(int paramInt1, String paramString, int paramInt2)
  {
    super(paramInt1, paramString, paramInt2);
  }

  public UDPNetSyslogConfig(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }

  public UDPNetSyslogConfig(int paramInt)
  {
    super(paramInt);
  }

  public UDPNetSyslogConfig(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public UDPNetSyslogConfig(String paramString)
  {
    super(paramString);
  }

  public Class getSyslogClass()
  {
    return UDPNetSyslog.class;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.udp.UDPNetSyslogConfig
 * JD-Core Version:    0.6.0
 */