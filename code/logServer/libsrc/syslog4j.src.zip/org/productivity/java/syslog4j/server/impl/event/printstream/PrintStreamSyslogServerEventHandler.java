package org.productivity.java.syslog4j.server.impl.event.printstream;

import java.io.PrintStream;
import java.net.SocketAddress;
import java.util.Date;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.SyslogServerIF;
import org.productivity.java.syslog4j.server.SyslogServerSessionEventHandlerIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class PrintStreamSyslogServerEventHandler
  implements SyslogServerSessionEventHandlerIF
{
  private static final long serialVersionUID = 6036415838696050746L;
  protected PrintStream stream = null;

  public PrintStreamSyslogServerEventHandler(PrintStream paramPrintStream)
  {
    this.stream = paramPrintStream;
  }

  public void initialize(SyslogServerIF paramSyslogServerIF)
  {
  }

  public Object sessionOpened(SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress)
  {
    return null;
  }

  public void event(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, SyslogServerEventIF paramSyslogServerEventIF)
  {
    String str1 = (paramSyslogServerEventIF.getDate() == null ? new Date() : paramSyslogServerEventIF.getDate()).toString();
    String str2 = SyslogUtility.getFacilityString(paramSyslogServerEventIF.getFacility());
    String str3 = SyslogUtility.getLevelString(paramSyslogServerEventIF.getLevel());
    this.stream.println("{" + str2 + "} " + str1 + " " + str3 + " " + paramSyslogServerEventIF.getMessage());
  }

  public void exception(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, Exception paramException)
  {
  }

  public void sessionClosed(Object paramObject, SyslogServerIF paramSyslogServerIF, SocketAddress paramSocketAddress, boolean paramBoolean)
  {
  }

  public void destroy(SyslogServerIF paramSyslogServerIF)
  {
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.event.printstream.PrintStreamSyslogServerEventHandler
 * JD-Core Version:    0.6.0
 */