package org.productivity.java.syslog4j.impl.backlog;

import org.productivity.java.syslog4j.Syslog;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;

public class Syslog4jBackLogHandler extends AbstractSyslogBackLogHandler
{
  protected SyslogIF syslog = null;
  protected int downLevel = 4;
  protected int upLevel = 4;

  public Syslog4jBackLogHandler(String paramString)
  {
    this.syslog = Syslog.getInstance(paramString);
  }

  public Syslog4jBackLogHandler(String paramString, boolean paramBoolean)
  {
    this.syslog = Syslog.getInstance(paramString);
    this.appendReason = paramBoolean;
  }

  public Syslog4jBackLogHandler(SyslogIF paramSyslogIF)
  {
    this.syslog = paramSyslogIF;
  }

  public Syslog4jBackLogHandler(SyslogIF paramSyslogIF, boolean paramBoolean)
  {
    this.syslog = paramSyslogIF;
    this.appendReason = paramBoolean;
  }

  public void initialize()
    throws SyslogRuntimeException
  {
  }

  public void log(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
    throws SyslogRuntimeException
  {
    if (this.syslog.getProtocol().equals(paramSyslogIF.getProtocol()))
      throw new SyslogRuntimeException("Ignoring this log entry since the backLog protocol \"" + this.syslog.getProtocol() + "\" is the same as the main protocol");
    String str = combine(paramSyslogIF, paramInt, paramString1, paramString2);
    this.syslog.log(paramInt, str);
  }

  public void down(SyslogIF paramSyslogIF, String paramString)
  {
    if (!this.syslog.getProtocol().equals(paramSyslogIF.getProtocol()))
      this.syslog.log(this.downLevel, "Syslog protocol \"" + paramSyslogIF.getProtocol() + "\" is down: " + paramString);
  }

  public void up(SyslogIF paramSyslogIF)
  {
    if (!this.syslog.getProtocol().equals(paramSyslogIF.getProtocol()))
      this.syslog.log(this.downLevel, "Syslog protocol \"" + paramSyslogIF.getProtocol() + "\" is up");
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.Syslog4jBackLogHandler
 * JD-Core Version:    0.6.0
 */