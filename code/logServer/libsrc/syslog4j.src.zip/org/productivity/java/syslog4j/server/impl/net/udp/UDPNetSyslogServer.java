package org.productivity.java.syslog4j.server.impl.net.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.server.SyslogServerEventIF;
import org.productivity.java.syslog4j.server.impl.AbstractSyslogServer;
import org.productivity.java.syslog4j.server.impl.AbstractSyslogServerConfig;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class UDPNetSyslogServer extends AbstractSyslogServer
{
  protected DatagramSocket ds = null;

  public void initialize()
    throws SyslogRuntimeException
  {
  }

  public void shutdown()
  {
    super.shutdown();
    if (this.syslogServerConfig.getShutdownWait() > 0L)
      SyslogUtility.sleep(this.syslogServerConfig.getShutdownWait());
    if ((this.ds != null) && (!this.ds.isClosed()))
      this.ds.close();
  }

  protected DatagramSocket createDatagramSocket()
    throws SocketException, UnknownHostException
  {
    DatagramSocket localDatagramSocket = null;
    if (this.syslogServerConfig.getHost() != null)
    {
      InetAddress localInetAddress = InetAddress.getByName(this.syslogServerConfig.getHost());
      localDatagramSocket = new DatagramSocket(this.syslogServerConfig.getPort(), localInetAddress);
    }
    else
    {
      localDatagramSocket = new DatagramSocket(this.syslogServerConfig.getPort());
    }
    return localDatagramSocket;
  }

  public void run()
  {
    try
    {
      this.ds = createDatagramSocket();
      this.shutdown = false;
    }
    catch (SocketException localSocketException1)
    {
      return;
    }
    catch (UnknownHostException localUnknownHostException)
    {
      return;
    }
    byte[] arrayOfByte = new byte[1024];
    handleInitialize(this);
    while (!this.shutdown)
    {
      DatagramPacket localDatagramPacket = null;
      try
      {
        localDatagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length);
        this.ds.receive(localDatagramPacket);
        SyslogServerEventIF localSyslogServerEventIF = createEvent(getConfig(), arrayOfByte, localDatagramPacket.getLength(), localDatagramPacket.getAddress());
        handleEvent(null, this, localDatagramPacket, localSyslogServerEventIF);
      }
      catch (SocketException localSocketException2)
      {
        int i = localSocketException2.getMessage() == null ? -1 : localSocketException2.getMessage().toLowerCase().indexOf("socket closed");
        if (i == -1)
          handleException(null, this, localDatagramPacket.getSocketAddress(), localSocketException2);
      }
      catch (IOException localIOException)
      {
        handleException(null, this, localDatagramPacket.getSocketAddress(), localIOException);
      }
    }
    handleDestroy(this);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.udp.UDPNetSyslogServer
 * JD-Core Version:    0.6.0
 */