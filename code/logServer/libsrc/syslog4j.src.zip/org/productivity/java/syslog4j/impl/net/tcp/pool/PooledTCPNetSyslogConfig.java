package org.productivity.java.syslog4j.impl.net.tcp.pool;

import org.productivity.java.syslog4j.SyslogPoolConfigIF;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfig;

public class PooledTCPNetSyslogConfig extends TCPNetSyslogConfig
  implements SyslogPoolConfigIF
{
  private static final long serialVersionUID = 2283355983363422888L;
  protected int maxActive = 4;
  protected int maxIdle = 4;
  protected long maxWait = 1000L;
  protected long minEvictableIdleTimeMillis = 0L;
  protected int minIdle = 4;
  protected int numTestsPerEvictionRun = 0;
  protected long softMinEvictableIdleTimeMillis = 0L;
  protected long timeBetweenEvictionRunsMillis = 0L;
  protected byte whenExhaustedAction = 1;
  protected boolean testOnBorrow = false;
  protected boolean testOnReturn = false;
  protected boolean testWhileIdle = false;

  public PooledTCPNetSyslogConfig()
  {
  }

  public PooledTCPNetSyslogConfig(int paramInt1, String paramString, int paramInt2)
  {
    super(paramInt1, paramString, paramInt2);
  }

  public PooledTCPNetSyslogConfig(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }

  public PooledTCPNetSyslogConfig(int paramInt)
  {
    super(paramInt);
  }

  public PooledTCPNetSyslogConfig(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public PooledTCPNetSyslogConfig(String paramString)
  {
    super(paramString);
  }

  protected void configureThreadedValues(int paramInt)
  {
    if (isThreaded())
    {
      this.minIdle = paramInt;
      this.maxIdle = paramInt;
      this.maxActive = paramInt;
    }
  }

  public int getMaxActive()
  {
    return this.maxActive;
  }

  public void setMaxActive(int paramInt)
  {
    configureThreadedValues(paramInt);
    this.maxActive = paramInt;
  }

  public int getMaxIdle()
  {
    return this.maxIdle;
  }

  public void setMaxIdle(int paramInt)
  {
    configureThreadedValues(paramInt);
    this.maxIdle = paramInt;
  }

  public long getMaxWait()
  {
    return this.maxWait;
  }

  public void setMaxWait(long paramLong)
  {
    this.maxWait = paramLong;
  }

  public long getMinEvictableIdleTimeMillis()
  {
    return this.minEvictableIdleTimeMillis;
  }

  public void setMinEvictableIdleTimeMillis(long paramLong)
  {
    this.minEvictableIdleTimeMillis = paramLong;
  }

  public int getMinIdle()
  {
    return this.minIdle;
  }

  public void setMinIdle(int paramInt)
  {
    configureThreadedValues(paramInt);
    this.minIdle = paramInt;
  }

  public int getNumTestsPerEvictionRun()
  {
    return this.numTestsPerEvictionRun;
  }

  public void setNumTestsPerEvictionRun(int paramInt)
  {
    this.numTestsPerEvictionRun = paramInt;
  }

  public long getSoftMinEvictableIdleTimeMillis()
  {
    return this.softMinEvictableIdleTimeMillis;
  }

  public void setSoftMinEvictableIdleTimeMillis(long paramLong)
  {
    this.softMinEvictableIdleTimeMillis = paramLong;
  }

  public long getTimeBetweenEvictionRunsMillis()
  {
    return this.timeBetweenEvictionRunsMillis;
  }

  public void setTimeBetweenEvictionRunsMillis(long paramLong)
  {
    this.timeBetweenEvictionRunsMillis = paramLong;
  }

  public byte getWhenExhaustedAction()
  {
    return this.whenExhaustedAction;
  }

  public void setWhenExhaustedAction(byte paramByte)
  {
    this.whenExhaustedAction = paramByte;
  }

  public boolean isTestOnBorrow()
  {
    return this.testOnBorrow;
  }

  public void setTestOnBorrow(boolean paramBoolean)
  {
    this.testOnBorrow = paramBoolean;
  }

  public boolean isTestOnReturn()
  {
    return this.testOnReturn;
  }

  public void setTestOnReturn(boolean paramBoolean)
  {
    this.testOnReturn = paramBoolean;
  }

  public boolean isTestWhileIdle()
  {
    return this.testWhileIdle;
  }

  public void setTestWhileIdle(boolean paramBoolean)
  {
    this.testWhileIdle = paramBoolean;
  }

  public Class getSyslogClass()
  {
    return PooledTCPNetSyslog.class;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.net.tcp.pool.PooledTCPNetSyslogConfig
 * JD-Core Version:    0.6.0
 */