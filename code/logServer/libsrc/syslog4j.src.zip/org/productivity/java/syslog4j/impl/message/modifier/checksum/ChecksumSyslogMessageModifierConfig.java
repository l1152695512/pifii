package org.productivity.java.syslog4j.impl.message.modifier.checksum;

import java.util.zip.Adler32;
import java.util.zip.CRC32;
import java.util.zip.Checksum;
import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifierConfig;

public class ChecksumSyslogMessageModifierConfig extends AbstractSyslogMessageModifierConfig
{
  private static final long serialVersionUID = -8298600135683882489L;
  protected Checksum checksum = null;
  protected boolean continuous = false;

  public static final ChecksumSyslogMessageModifierConfig createCRC32()
  {
    ChecksumSyslogMessageModifierConfig localChecksumSyslogMessageModifierConfig = new ChecksumSyslogMessageModifierConfig(new CRC32());
    return localChecksumSyslogMessageModifierConfig;
  }

  public static final ChecksumSyslogMessageModifierConfig createADLER32()
  {
    ChecksumSyslogMessageModifierConfig localChecksumSyslogMessageModifierConfig = new ChecksumSyslogMessageModifierConfig(new Adler32());
    return localChecksumSyslogMessageModifierConfig;
  }

  public ChecksumSyslogMessageModifierConfig(Checksum paramChecksum)
  {
    this.checksum = paramChecksum;
  }

  public Checksum getChecksum()
  {
    return this.checksum;
  }

  public void setChecksum(Checksum paramChecksum)
  {
    this.checksum = paramChecksum;
  }

  public boolean isContinuous()
  {
    return this.continuous;
  }

  public void setContinuous(boolean paramBoolean)
  {
    this.continuous = paramBoolean;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.checksum.ChecksumSyslogMessageModifierConfig
 * JD-Core Version:    0.6.0
 */