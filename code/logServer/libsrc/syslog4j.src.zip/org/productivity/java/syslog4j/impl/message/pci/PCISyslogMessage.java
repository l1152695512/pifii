package org.productivity.java.syslog4j.impl.message.pci;

import java.util.Date;
import java.util.Map;
import org.productivity.java.syslog4j.impl.message.AbstractSyslogMessage;

public class PCISyslogMessage extends AbstractSyslogMessage
  implements PCISyslogMessageIF
{
  private static final long serialVersionUID = 3571696218386879119L;
  public static final String USER_ID = "userId";
  public static final String EVENT_TYPE = "eventType";
  public static final String DATE = "date";
  public static final String TIME = "time";
  public static final String STATUS = "status";
  public static final String ORIGINATION = "origination";
  public static final String AFFECTED_RESOURCE = "affectedResource";
  protected String userId = "undefined";
  protected String eventType = "undefined";
  protected String date = null;
  protected String time = null;
  protected String status = "undefined";
  protected String origination = null;
  protected String affectedResource = "undefined";

  public PCISyslogMessage()
  {
  }

  public PCISyslogMessage(PCISyslogMessageIF paramPCISyslogMessageIF)
  {
    init(paramPCISyslogMessageIF);
  }

  public PCISyslogMessage(Map paramMap)
  {
    init(paramMap);
  }

  protected void init(PCISyslogMessageIF paramPCISyslogMessageIF)
  {
    this.userId = paramPCISyslogMessageIF.getUserId();
    this.eventType = paramPCISyslogMessageIF.getEventType();
    this.date = paramPCISyslogMessageIF.getDate();
    this.time = paramPCISyslogMessageIF.getTime();
    this.status = paramPCISyslogMessageIF.getStatus();
    this.origination = paramPCISyslogMessageIF.getOrigination();
    this.affectedResource = paramPCISyslogMessageIF.getAffectedResource();
  }

  protected void init(Map paramMap)
  {
    if (paramMap.containsKey("userId"))
      this.userId = ((String)paramMap.get("userId"));
    if (paramMap.containsKey("eventType"))
      this.eventType = ((String)paramMap.get("eventType"));
    if ((paramMap.containsKey("date")) && ((paramMap.get("date") instanceof String)))
      this.date = ((String)paramMap.get("date"));
    if ((paramMap.containsKey("date")) && ((paramMap.get("date") instanceof Date)))
      setDate((Date)paramMap.get("date"));
    if (paramMap.containsKey("time"))
      this.time = ((String)paramMap.get("time"));
    if (paramMap.containsKey("status"))
      this.status = ((String)paramMap.get("status"));
    if (paramMap.containsKey("origination"))
      this.origination = ((String)paramMap.get("origination"));
    if (paramMap.containsKey("affectedResource"))
      this.affectedResource = ((String)paramMap.get("affectedResource"));
  }

  public PCISyslogMessage(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    this.status = paramString3;
    this.affectedResource = paramString4;
  }

  public PCISyslogMessage(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    this.status = paramString3;
    this.origination = paramString4;
    this.affectedResource = paramString5;
  }

  public PCISyslogMessage(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    this.date = paramString3;
    this.time = paramString4;
    this.status = paramString5;
    this.affectedResource = paramString6;
  }

  public PCISyslogMessage(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    this.date = paramString3;
    this.time = paramString4;
    this.status = paramString5;
    this.origination = paramString6;
    this.affectedResource = paramString7;
  }

  public PCISyslogMessage(String paramString1, String paramString2, Date paramDate, String paramString3, String paramString4)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    String[] arrayOfString = generateDateAndTime(paramDate);
    this.date = arrayOfString[0];
    this.time = arrayOfString[1];
    this.status = paramString3;
    this.affectedResource = paramString4;
  }

  public PCISyslogMessage(String paramString1, String paramString2, Date paramDate, String paramString3, String paramString4, String paramString5)
  {
    this.userId = paramString1;
    this.eventType = paramString2;
    String[] arrayOfString = generateDateAndTime(paramDate);
    this.date = arrayOfString[0];
    this.time = arrayOfString[1];
    this.status = paramString3;
    this.origination = paramString4;
    this.affectedResource = paramString5;
  }

  public String getUserId()
  {
    if (nullOrEmpty(this.userId))
      return "undefined";
    return this.userId;
  }

  public void setUserId(String paramString)
  {
    this.userId = paramString;
  }

  public String getEventType()
  {
    if (nullOrEmpty(this.eventType))
      return "undefined";
    return this.eventType;
  }

  public void setEventType(String paramString)
  {
    this.eventType = paramString;
  }

  public String getDate()
  {
    if (nullOrEmpty(this.date))
    {
      String str = generateDate();
      return str;
    }
    return this.date;
  }

  public void setDate(String paramString)
  {
    this.date = paramString;
  }

  public void setDate(Date paramDate)
  {
    String[] arrayOfString = generateDateAndTime(paramDate);
    this.date = arrayOfString[0];
    this.time = arrayOfString[1];
  }

  public String getTime()
  {
    if (nullOrEmpty(this.time))
    {
      String str = generateTime();
      return str;
    }
    return this.time;
  }

  public void setTime(String paramString)
  {
    this.time = paramString;
  }

  public String getStatus()
  {
    if (nullOrEmpty(this.status))
      return "undefined";
    return this.status;
  }

  public void setStatus(String paramString)
  {
    this.status = paramString;
  }

  public String getOrigination()
  {
    if (nullOrEmpty(this.origination))
    {
      String str = generateLocalHostName();
      return str;
    }
    return this.origination;
  }

  public void setOrigination(String paramString)
  {
    this.origination = paramString;
  }

  public String getAffectedResource()
  {
    if (nullOrEmpty(this.affectedResource))
      return "undefined";
    return this.affectedResource;
  }

  public void setAffectedResource(String paramString)
  {
    this.affectedResource = paramString;
  }

  public String createMessage()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    char c = getDelimiter();
    String str = getReplaceDelimiter();
    localStringBuffer.append(replaceDelimiter("userId", getUserId(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("eventType", getEventType(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("date", getDate(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("time", getTime(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("status", getStatus(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("origination", getOrigination(), c, str));
    localStringBuffer.append(c);
    localStringBuffer.append(replaceDelimiter("affectedResource", getAffectedResource(), c, str));
    return localStringBuffer.toString();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.pci.PCISyslogMessage
 * JD-Core Version:    0.6.0
 */