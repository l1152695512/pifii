package org.productivity.java.syslog4j;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.productivity.java.syslog4j.impl.net.tcp.TCPNetSyslogConfig;
import org.productivity.java.syslog4j.impl.net.udp.UDPNetSyslogConfig;
import org.productivity.java.syslog4j.impl.unix.UnixSyslogConfig;
import org.productivity.java.syslog4j.impl.unix.socket.UnixSocketSyslogConfig;
import org.productivity.java.syslog4j.util.OSDetectUtility;
import org.productivity.java.syslog4j.util.SyslogUtility;

public final class Syslog
  implements SyslogConstants
{
  private static final long serialVersionUID = -4662318148650646144L;
  private static boolean SUPPRESS_RUNTIME_EXCEPTIONS = false;
  protected static final Map instances = new Hashtable();

  public static final String getVersion()
  {
    return "Syslog4j 0.9.46 2011-01-23 14:49:24 jpy";
  }

  public static void setSuppressRuntimeExceptions(boolean paramBoolean)
  {
    SUPPRESS_RUNTIME_EXCEPTIONS = paramBoolean;
  }

  public static boolean getSuppressRuntimeExceptions()
  {
    return SUPPRESS_RUNTIME_EXCEPTIONS;
  }

  private static void throwRuntimeException(String paramString)
    throws SyslogRuntimeException
  {
    if (SUPPRESS_RUNTIME_EXCEPTIONS)
      return;
    throw new SyslogRuntimeException(paramString.toString());
  }

  public static final SyslogIF getInstance(String paramString)
    throws SyslogRuntimeException
  {
    String str1 = paramString.toLowerCase();
    if (instances.containsKey(str1))
      return (SyslogIF)instances.get(str1);
    StringBuffer localStringBuffer = new StringBuffer("Syslog protocol \"" + paramString + "\" not defined; call Syslogger.createSyslogInstance(protocol,config) first");
    if (instances.size() > 0)
    {
      localStringBuffer.append(" or use one of the following instances: ");
      Iterator localIterator = instances.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str2 = (String)localIterator.next();
        localStringBuffer.append(str2);
        if (!localIterator.hasNext())
          continue;
        localStringBuffer.append(' ');
      }
    }
    throwRuntimeException(localStringBuffer.toString());
    return null;
  }

  public static final SyslogIF createInstance(String paramString, SyslogConfigIF paramSyslogConfigIF)
    throws SyslogRuntimeException
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
    {
      throwRuntimeException("Instance protocol cannot be null or empty");
      return null;
    }
    if (paramSyslogConfigIF == null)
    {
      throwRuntimeException("SyslogConfig cannot be null");
      return null;
    }
    String str = paramString.toLowerCase();
    SyslogIF localSyslogIF = null;
    synchronized (instances)
    {
      if (instances.containsKey(str))
      {
        throwRuntimeException("Syslog protocol \"" + paramString + "\" already defined");
        return null;
      }
      try
      {
        Class localClass = paramSyslogConfigIF.getSyslogClass();
        localSyslogIF = (SyslogIF)localClass.newInstance();
      }
      catch (ClassCastException localClassCastException)
      {
        if (!paramSyslogConfigIF.isThrowExceptionOnInitialize())
          throw new SyslogRuntimeException(localClassCastException);
        return null;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        if (!paramSyslogConfigIF.isThrowExceptionOnInitialize())
          throw new SyslogRuntimeException(localIllegalAccessException);
        return null;
      }
      catch (InstantiationException localInstantiationException)
      {
        if (!paramSyslogConfigIF.isThrowExceptionOnInitialize())
          throw new SyslogRuntimeException(localInstantiationException);
        return null;
      }
      localSyslogIF.initialize(str, paramSyslogConfigIF);
      instances.put(str, localSyslogIF);
    }
    return localSyslogIF;
  }

  public static final synchronized void initialize()
  {
    createInstance("udp", new UDPNetSyslogConfig());
    createInstance("tcp", new TCPNetSyslogConfig());
    if ((OSDetectUtility.isUnix()) && (SyslogUtility.isClassExists("com.sun.jna.Native")))
    {
      createInstance("unix_syslog", new UnixSyslogConfig());
      createInstance("unix_socket", new UnixSocketSyslogConfig());
    }
  }

  public static final boolean exists(String paramString)
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
      return false;
    return instances.containsKey(paramString.toLowerCase());
  }

  public static final synchronized void shutdown()
  {
    Set localSet = instances.keySet();
    if (localSet.size() > 0)
    {
      Iterator localIterator = localSet.iterator();
      SyslogUtility.sleep(500L);
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        SyslogIF localSyslogIF = (SyslogIF)instances.get(str);
        localSyslogIF.shutdown();
      }
      instances.clear();
    }
  }

  public static final synchronized void destroyInstance(String paramString)
    throws SyslogRuntimeException
  {
    if ((paramString == null) || ("".equals(paramString.trim())))
      return;
    String str = paramString.toLowerCase();
    if (instances.containsKey(str))
    {
      SyslogUtility.sleep(500L);
      SyslogIF localSyslogIF = (SyslogIF)instances.get(str);
      try
      {
        localSyslogIF.shutdown();
      }
      finally
      {
        instances.remove(str);
      }
    }
    else
    {
      throwRuntimeException("Cannot destroy protocol \"" + paramString + "\" instance; call shutdown instead");
      return;
    }
  }

  public static final synchronized void destroyInstance(SyslogIF paramSyslogIF)
    throws SyslogRuntimeException
  {
    if (paramSyslogIF == null)
      return;
    String str = paramSyslogIF.getProtocol().toLowerCase();
    if (instances.containsKey(str))
    {
      try
      {
        paramSyslogIF.shutdown();
      }
      finally
      {
        instances.remove(str);
      }
    }
    else
    {
      throwRuntimeException("Cannot destroy protocol \"" + str + "\" instance; call shutdown instead");
      return;
    }
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    SyslogMain.main(paramArrayOfString);
  }

  static
  {
    initialize();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.Syslog
 * JD-Core Version:    0.6.0
 */