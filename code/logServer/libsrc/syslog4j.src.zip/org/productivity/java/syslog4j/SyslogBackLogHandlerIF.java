package org.productivity.java.syslog4j;

public abstract interface SyslogBackLogHandlerIF
{
  public abstract void initialize()
    throws SyslogRuntimeException;

  public abstract void down(SyslogIF paramSyslogIF, String paramString);

  public abstract void up(SyslogIF paramSyslogIF);

  public abstract void log(SyslogIF paramSyslogIF, int paramInt, String paramString1, String paramString2)
    throws SyslogRuntimeException;
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogBackLogHandlerIF
 * JD-Core Version:    0.6.0
 */