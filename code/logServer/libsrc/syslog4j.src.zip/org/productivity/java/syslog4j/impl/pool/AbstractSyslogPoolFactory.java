package org.productivity.java.syslog4j.impl.pool;

import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.commons.pool.ObjectPool;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslog;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF;
import org.productivity.java.syslog4j.impl.AbstractSyslogWriter;

public abstract class AbstractSyslogPoolFactory extends BasePoolableObjectFactory
{
  private static final long serialVersionUID = -7441569603980981508L;
  protected AbstractSyslog syslog = null;
  protected AbstractSyslogConfigIF syslogConfig = null;
  protected ObjectPool pool = null;

  public void initialize(AbstractSyslog paramAbstractSyslog)
    throws SyslogRuntimeException
  {
    this.syslog = paramAbstractSyslog;
    try
    {
      this.syslogConfig = ((AbstractSyslogConfigIF)this.syslog.getConfig());
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("config must implement AbstractSyslogConfigIF");
    }
    this.pool = createPool();
  }

  public Object makeObject()
    throws Exception
  {
    AbstractSyslogWriter localAbstractSyslogWriter = this.syslog.createWriter();
    if (this.syslogConfig.isThreaded())
      this.syslog.createWriterThread(localAbstractSyslogWriter);
    return localAbstractSyslogWriter;
  }

  public void destroyObject(Object paramObject)
    throws Exception
  {
    AbstractSyslogWriter localAbstractSyslogWriter = (AbstractSyslogWriter)paramObject;
    localAbstractSyslogWriter.shutdown();
    super.destroyObject(localAbstractSyslogWriter);
  }

  public abstract ObjectPool createPool()
    throws SyslogRuntimeException;

  public AbstractSyslogWriter borrowSyslogWriter()
    throws Exception
  {
    AbstractSyslogWriter localAbstractSyslogWriter = (AbstractSyslogWriter)this.pool.borrowObject();
    return localAbstractSyslogWriter;
  }

  public void returnSyslogWriter(AbstractSyslogWriter paramAbstractSyslogWriter)
    throws Exception
  {
    this.pool.returnObject(paramAbstractSyslogWriter);
  }

  public void clear()
    throws Exception
  {
    this.pool.clear();
  }

  public void close()
    throws Exception
  {
    this.pool.close();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.pool.AbstractSyslogPoolFactory
 * JD-Core Version:    0.6.0
 */