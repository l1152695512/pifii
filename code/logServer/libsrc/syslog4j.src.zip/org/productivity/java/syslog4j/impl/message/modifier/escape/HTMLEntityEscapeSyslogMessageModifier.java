package org.productivity.java.syslog4j.impl.message.modifier.escape;

import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;

public class HTMLEntityEscapeSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = -8481773209240762293L;

  public static final SyslogMessageModifierIF createDefault()
  {
    return new HTMLEntityEscapeSyslogMessageModifier();
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    if ((paramString != null) && (!"".equals(paramString.trim())))
    {
      String str = escapeHtml(paramString);
      return str;
    }
    return paramString;
  }

  public boolean verify(String paramString)
  {
    return true;
  }

  public static String escapeHtml(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramString.length());
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if (c == '<')
      {
        localStringBuffer.append("&lt;");
      }
      else if (c == '>')
      {
        localStringBuffer.append("&gt;");
      }
      else if (c == '"')
      {
        localStringBuffer.append("&quot;");
      }
      else if (c == '\'')
      {
        localStringBuffer.append("&#39;");
      }
      else if (c == '&')
      {
        localStringBuffer.append("&amp;");
      }
      else if ((c >= ' ') && (c <= '~'))
      {
        localStringBuffer.append(c);
      }
      else if (Character.isWhitespace(c))
      {
        localStringBuffer.append("&#").append(c).append(";");
      }
      else
      {
        if ((Character.isISOControl(c)) || (!Character.isDefined(c)))
          continue;
        localStringBuffer.append("&#").append(c).append(";");
      }
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.escape.HTMLEntityEscapeSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */