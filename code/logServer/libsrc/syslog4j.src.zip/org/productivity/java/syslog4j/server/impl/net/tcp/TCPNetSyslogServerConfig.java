package org.productivity.java.syslog4j.server.impl.net.tcp;

import org.productivity.java.syslog4j.server.impl.net.AbstractNetSyslogServerConfig;

public class TCPNetSyslogServerConfig extends AbstractNetSyslogServerConfig
  implements TCPNetSyslogServerConfigIF
{
  private static final long serialVersionUID = -1546696301177599370L;
  protected int timeout = 0;
  protected int backlog = 0;
  protected int maxActiveSockets = 0;
  protected byte maxActiveSocketsBehavior = 0;

  public TCPNetSyslogServerConfig()
  {
  }

  public TCPNetSyslogServerConfig(int paramInt)
  {
    this.port = paramInt;
  }

  public TCPNetSyslogServerConfig(int paramInt1, int paramInt2)
  {
    this.port = paramInt1;
    this.backlog = paramInt2;
  }

  public TCPNetSyslogServerConfig(String paramString)
  {
    this.host = paramString;
  }

  public TCPNetSyslogServerConfig(String paramString, int paramInt)
  {
    this.host = paramString;
    this.port = paramInt;
  }

  public TCPNetSyslogServerConfig(String paramString, int paramInt1, int paramInt2)
  {
    this.host = paramString;
    this.port = paramInt1;
    this.backlog = paramInt2;
  }

  public Class getSyslogServerClass()
  {
    return TCPNetSyslogServer.class;
  }

  public int getTimeout()
  {
    return this.timeout;
  }

  public void setTimeout(int paramInt)
  {
    this.timeout = paramInt;
  }

  public int getBacklog()
  {
    return this.backlog;
  }

  public void setBacklog(int paramInt)
  {
    this.backlog = paramInt;
  }

  public int getMaxActiveSockets()
  {
    return this.maxActiveSockets;
  }

  public void setMaxActiveSockets(int paramInt)
  {
    this.maxActiveSockets = paramInt;
  }

  public byte getMaxActiveSocketsBehavior()
  {
    return this.maxActiveSocketsBehavior;
  }

  public void setMaxActiveSocketsBehavior(byte paramByte)
  {
    this.maxActiveSocketsBehavior = paramByte;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfig
 * JD-Core Version:    0.6.0
 */