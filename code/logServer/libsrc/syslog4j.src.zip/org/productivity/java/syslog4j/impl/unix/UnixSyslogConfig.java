package org.productivity.java.syslog4j.impl.unix;

import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfig;

public class UnixSyslogConfig extends AbstractSyslogConfig
{
  private static final long serialVersionUID = -4805767812011660656L;
  protected String library = "c";
  protected int option = 0;

  public UnixSyslogConfig()
  {
    setSendLocalName(false);
  }

  public Class getSyslogClass()
  {
    return UnixSyslog.class;
  }

  public String getHost()
  {
    return null;
  }

  public int getPort()
  {
    return 0;
  }

  public void setHost(String paramString)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("Host not appropriate for class \"" + getClass().getName() + "\"");
  }

  public void setPort(int paramInt)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("Port not appropriate for class \"" + getClass().getName() + "\"");
  }

  public String getLibrary()
  {
    return this.library;
  }

  public void setLibrary(String paramString)
  {
    this.library = paramString;
  }

  public int getOption()
  {
    return this.option;
  }

  public void setOption(int paramInt)
  {
    this.option = paramInt;
  }

  public int getMaxQueueSize()
  {
    throw new SyslogRuntimeException("UnixSyslog protocol does not uses a queueing mechanism");
  }

  public void setMaxQueueSize(int paramInt)
  {
    throw new SyslogRuntimeException("UnixSyslog protocol does not uses a queueing mechanism");
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.unix.UnixSyslogConfig
 * JD-Core Version:    0.6.0
 */