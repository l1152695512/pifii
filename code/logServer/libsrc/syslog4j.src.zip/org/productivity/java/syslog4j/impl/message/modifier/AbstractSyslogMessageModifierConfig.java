package org.productivity.java.syslog4j.impl.message.modifier;

import org.productivity.java.syslog4j.SyslogCharSetIF;
import org.productivity.java.syslog4j.SyslogMessageModifierConfigIF;

public abstract class AbstractSyslogMessageModifierConfig
  implements SyslogMessageModifierConfigIF, SyslogCharSetIF
{
  private static final long serialVersionUID = 5036574188079124884L;
  protected String prefix = " {";
  protected String suffix = "}";
  protected String charSet = "UTF-8";

  public String getPrefix()
  {
    return this.prefix;
  }

  public String getSuffix()
  {
    return this.suffix;
  }

  public void setPrefix(String paramString)
  {
    if (paramString == null)
      this.prefix = "";
    else
      this.prefix = paramString;
  }

  public void setSuffix(String paramString)
  {
    if (paramString == null)
      this.suffix = "";
    else
      this.suffix = paramString;
  }

  public String getCharSet()
  {
    return this.charSet;
  }

  public void setCharSet(String paramString)
  {
    this.charSet = paramString;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifierConfig
 * JD-Core Version:    0.6.0
 */