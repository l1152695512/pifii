package org.productivity.java.syslog4j.impl.message.modifier.hash;

import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifierConfig;

public class HashSyslogMessageModifierConfig extends AbstractSyslogMessageModifierConfig
{
  private static final long serialVersionUID = -3148300281439874231L;
  protected String hashAlgorithm = null;

  public static final HashSyslogMessageModifierConfig createMD5()
  {
    HashSyslogMessageModifierConfig localHashSyslogMessageModifierConfig = new HashSyslogMessageModifierConfig("MD5");
    return localHashSyslogMessageModifierConfig;
  }

  public static final HashSyslogMessageModifierConfig createSHA1()
  {
    HashSyslogMessageModifierConfig localHashSyslogMessageModifierConfig = new HashSyslogMessageModifierConfig("SHA1");
    return localHashSyslogMessageModifierConfig;
  }

  public static final HashSyslogMessageModifierConfig createSHA160()
  {
    return createSHA1();
  }

  public static final HashSyslogMessageModifierConfig createSHA256()
  {
    HashSyslogMessageModifierConfig localHashSyslogMessageModifierConfig = new HashSyslogMessageModifierConfig("SHA-256");
    return localHashSyslogMessageModifierConfig;
  }

  public static final HashSyslogMessageModifierConfig createSHA384()
  {
    HashSyslogMessageModifierConfig localHashSyslogMessageModifierConfig = new HashSyslogMessageModifierConfig("SHA-384");
    return localHashSyslogMessageModifierConfig;
  }

  public static final HashSyslogMessageModifierConfig createSHA512()
  {
    HashSyslogMessageModifierConfig localHashSyslogMessageModifierConfig = new HashSyslogMessageModifierConfig("SHA-512");
    return localHashSyslogMessageModifierConfig;
  }

  public HashSyslogMessageModifierConfig(String paramString)
  {
    this.hashAlgorithm = paramString;
  }

  public String getHashAlgorithm()
  {
    return this.hashAlgorithm;
  }

  public void setHashAlgorithm(String paramString)
  {
    this.hashAlgorithm = paramString;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.hash.HashSyslogMessageModifierConfig
 * JD-Core Version:    0.6.0
 */