package org.productivity.java.syslog4j.impl.message;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.productivity.java.syslog4j.SyslogMessageIF;

public abstract class AbstractSyslogMessage
  implements SyslogMessageIF
{
  private static final long serialVersionUID = 414124277626756491L;
  public static final String UNDEFINED = "undefined";
  public static final String DEFAULT_DATE_FORMAT = "yyyy/MM/dd";
  public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";
  public static final char DEFAULT_DELIMITER = ' ';
  public static final String DEFAULT_REPLACE_DELIMITER = "_";

  protected char getDelimiter()
  {
    return ' ';
  }

  protected String getReplaceDelimiter()
  {
    return "_";
  }

  protected String getDateFormat()
  {
    return "yyyy/MM/dd";
  }

  protected String getTimeFormat()
  {
    return "HH:mm:ss";
  }

  protected String generateDate()
  {
    String str = new SimpleDateFormat(getDateFormat()).format(new Date());
    return str;
  }

  protected String generateTime()
  {
    String str = new SimpleDateFormat(getTimeFormat()).format(new Date());
    return str;
  }

  protected String[] generateDateAndTime(Date paramDate)
  {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = new SimpleDateFormat(getDateFormat()).format(paramDate);
    arrayOfString[1] = new SimpleDateFormat(getTimeFormat()).format(paramDate);
    return arrayOfString;
  }

  protected String generateLocalHostName()
  {
    String str = "undefined";
    try
    {
      str = InetAddress.getLocalHost().getHostName();
    }
    catch (UnknownHostException localUnknownHostException)
    {
    }
    return str;
  }

  protected boolean nullOrEmpty(String paramString)
  {
    return (paramString == null) || ("".equals(paramString.trim()));
  }

  protected String replaceDelimiter(String paramString1, String paramString2, char paramChar, String paramString3)
  {
    if ((paramString3 == null) || (paramString3.length() < 1) || (paramString2 == null) || (paramString2.length() < 1))
      return paramString2;
    String str = paramString2.replaceAll("\\" + paramChar, paramString3);
    return str;
  }

  public abstract String createMessage();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.AbstractSyslogMessage
 * JD-Core Version:    0.6.0
 */