package org.productivity.java.syslog4j.server.impl.net.tcp.ssl;

import org.productivity.java.syslog4j.server.impl.net.tcp.TCPNetSyslogServerConfig;

public class SSLTCPNetSyslogServerConfig extends TCPNetSyslogServerConfig
  implements SSLTCPNetSyslogServerConfigIF
{
  private static final long serialVersionUID = -840102682868286462L;
  protected String keyStore = null;
  protected String keyStorePassword = null;
  protected String trustStore = null;
  protected String trustStorePassword = null;

  public String getKeyStore()
  {
    return this.keyStore;
  }

  public void setKeyStore(String paramString)
  {
    this.keyStore = paramString;
  }

  public String getKeyStorePassword()
  {
    return this.keyStorePassword;
  }

  public void setKeyStorePassword(String paramString)
  {
    this.keyStorePassword = paramString;
  }

  public String getTrustStore()
  {
    return this.trustStore;
  }

  public void setTrustStore(String paramString)
  {
    this.trustStore = paramString;
  }

  public String getTrustStorePassword()
  {
    return this.trustStorePassword;
  }

  public void setTrustStorePassword(String paramString)
  {
    this.trustStorePassword = paramString;
  }

  public Class getSyslogServerClass()
  {
    return SSLTCPNetSyslogServer.class;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.server.impl.net.tcp.ssl.SSLTCPNetSyslogServerConfig
 * JD-Core Version:    0.6.0
 */