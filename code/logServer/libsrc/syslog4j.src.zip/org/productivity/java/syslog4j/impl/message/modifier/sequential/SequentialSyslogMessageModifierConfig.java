package org.productivity.java.syslog4j.impl.message.modifier.sequential;

import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifierConfig;

public class SequentialSyslogMessageModifierConfig extends AbstractSyslogMessageModifierConfig
{
  private static final long serialVersionUID = 1570930406228960303L;
  protected long firstNumber = 0L;
  protected long lastNumber = 9999L;
  protected char padChar = '0';
  protected boolean usePadding = true;

  public static final SequentialSyslogMessageModifierConfig createDefault()
  {
    SequentialSyslogMessageModifierConfig localSequentialSyslogMessageModifierConfig = new SequentialSyslogMessageModifierConfig();
    return localSequentialSyslogMessageModifierConfig;
  }

  public SequentialSyslogMessageModifierConfig()
  {
    setPrefix(" #");
    setSuffix("");
  }

  public long getLastNumberDigits()
  {
    return Long.toString(this.lastNumber).length();
  }

  public long getFirstNumber()
  {
    return this.firstNumber;
  }

  public void setFirstNumber(long paramLong)
  {
    if (paramLong < this.lastNumber)
      this.firstNumber = paramLong;
  }

  public long getLastNumber()
  {
    return this.lastNumber;
  }

  public void setLastNumber(long paramLong)
  {
    if (paramLong > this.firstNumber)
      this.lastNumber = paramLong;
  }

  public boolean isUsePadding()
  {
    return this.usePadding;
  }

  public void setUsePadding(boolean paramBoolean)
  {
    this.usePadding = paramBoolean;
  }

  public char getPadChar()
  {
    return this.padChar;
  }

  public void setPadChar(char paramChar)
  {
    this.padChar = paramChar;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.sequential.SequentialSyslogMessageModifierConfig
 * JD-Core Version:    0.6.0
 */