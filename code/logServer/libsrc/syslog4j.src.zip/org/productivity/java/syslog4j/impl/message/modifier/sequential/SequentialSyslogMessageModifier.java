package org.productivity.java.syslog4j.impl.message.modifier.sequential;

import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;

public class SequentialSyslogMessageModifier
  implements SyslogMessageModifierIF
{
  private static final long serialVersionUID = 6107735010240030785L;
  protected SequentialSyslogMessageModifierConfig config = null;
  protected long[] currentSequence = new long[8];

  public static final SequentialSyslogMessageModifier createDefault()
  {
    SequentialSyslogMessageModifier localSequentialSyslogMessageModifier = new SequentialSyslogMessageModifier(SequentialSyslogMessageModifierConfig.createDefault());
    return localSequentialSyslogMessageModifier;
  }

  public SequentialSyslogMessageModifier(SequentialSyslogMessageModifierConfig paramSequentialSyslogMessageModifierConfig)
  {
    this.config = paramSequentialSyslogMessageModifierConfig;
    for (int i = 0; i < 8; i++)
      this.currentSequence[i] = paramSequentialSyslogMessageModifierConfig.getFirstNumber();
  }

  protected String pad(long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer(Long.toString(paramLong));
    while (localStringBuffer.length() < this.config.getLastNumberDigits())
      localStringBuffer.insert(0, this.config.getPadChar());
    return localStringBuffer.toString();
  }

  public void setNextSequence(int paramInt, long paramLong)
  {
    if ((paramLong >= this.config.getFirstNumber()) && (paramLong < this.config.getLastNumber()))
      synchronized (this)
      {
        this.currentSequence[paramInt] = paramLong;
      }
  }

  protected String nextSequence(int paramInt)
  {
    long l = -1L;
    synchronized (this)
    {
      l = this.currentSequence[paramInt];
      if (this.currentSequence[paramInt] >= this.config.getLastNumber())
        this.currentSequence[paramInt] = this.config.getFirstNumber();
      else
        this.currentSequence[paramInt] += 1L;
    }
    ??? = null;
    if (this.config.isUsePadding())
      ??? = pad(l);
    else
      ??? = Long.toString(l);
    return (String)???;
  }

  public SequentialSyslogMessageModifierConfig getConfig()
  {
    return this.config;
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramString);
    localStringBuffer.append(this.config.getPrefix());
    localStringBuffer.append(nextSequence(paramInt2));
    localStringBuffer.append(this.config.getSuffix());
    return localStringBuffer.toString();
  }

  public boolean verify(String paramString)
  {
    return true;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.sequential.SequentialSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */