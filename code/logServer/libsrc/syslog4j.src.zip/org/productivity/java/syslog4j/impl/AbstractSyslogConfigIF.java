package org.productivity.java.syslog4j.impl;

import java.util.List;
import org.productivity.java.syslog4j.SyslogConfigIF;

public abstract interface AbstractSyslogConfigIF extends SyslogConfigIF
{
  public abstract Class getSyslogWriterClass();

  public abstract List getBackLogHandlers();

  public abstract List getMessageModifiers();

  public abstract byte[] getSplitMessageBeginText();

  public abstract void setSplitMessageBeginText(byte[] paramArrayOfByte);

  public abstract byte[] getSplitMessageEndText();

  public abstract void setSplitMessageEndText(byte[] paramArrayOfByte);

  public abstract boolean isThreaded();

  public abstract void setThreaded(boolean paramBoolean);

  public abstract boolean isUseDaemonThread();

  public abstract void setUseDaemonThread(boolean paramBoolean);

  public abstract int getThreadPriority();

  public abstract void setThreadPriority(int paramInt);

  public abstract long getThreadLoopInterval();

  public abstract void setThreadLoopInterval(long paramLong);

  public abstract long getMaxShutdownWait();

  public abstract void setMaxShutdownWait(long paramLong);

  public abstract int getWriteRetries();

  public abstract void setWriteRetries(int paramInt);

  public abstract int getMaxQueueSize();

  public abstract void setMaxQueueSize(int paramInt);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.AbstractSyslogConfigIF
 * JD-Core Version:    0.6.0
 */