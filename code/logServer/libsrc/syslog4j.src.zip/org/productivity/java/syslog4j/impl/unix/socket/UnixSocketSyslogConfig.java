package org.productivity.java.syslog4j.impl.unix.socket;

import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.AbstractSyslogConfig;

public class UnixSocketSyslogConfig extends AbstractSyslogConfig
{
  private static final long serialVersionUID = -3145794243736015707L;
  protected int type = 2;
  protected short family = 1;
  protected int protocol = 0;
  protected String library = "c";
  protected String path = "/dev/log";

  public UnixSocketSyslogConfig()
  {
    setSendLocalName(false);
    setIdent("java");
  }

  public Class getSyslogClass()
  {
    return UnixSocketSyslog.class;
  }

  public UnixSocketSyslogConfig(int paramInt)
  {
    this.facility = paramInt;
  }

  public UnixSocketSyslogConfig(int paramInt, String paramString)
  {
    this.facility = paramInt;
    this.path = paramString;
  }

  public UnixSocketSyslogConfig(String paramString)
  {
    this.path = paramString;
  }

  public String getHost()
  {
    return null;
  }

  public int getPort()
  {
    return -1;
  }

  public void setHost(String paramString)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("Host not appropriate for class \"" + getClass().getName() + "\"");
  }

  public void setPort(int paramInt)
    throws SyslogRuntimeException
  {
    throw new SyslogRuntimeException("Port not appropriate for class \"" + getClass().getName() + "\"");
  }

  public String getLibrary()
  {
    return this.library;
  }

  public void setLibrary(String paramString)
  {
    this.library = paramString;
  }

  public String getPath()
  {
    return this.path;
  }

  public void setPath(String paramString)
  {
    this.path = paramString;
  }

  public int getType()
  {
    return this.type;
  }

  public void setType(int paramInt)
  {
    this.type = paramInt;
  }

  public void setType(String paramString)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("Type cannot be null for class \"" + getClass().getName() + "\"");
    if ("SOCK_STREAM".equalsIgnoreCase(paramString.trim()))
      this.type = 1;
    else if ("SOCK_DGRAM".equalsIgnoreCase(paramString.trim()))
      this.type = 2;
    else
      throw new SyslogRuntimeException("Type must be \"SOCK_STREAM\" or \"SOCK_DGRAM\" for class \"" + getClass().getName() + "\"");
  }

  public short getFamily()
  {
    return this.family;
  }

  public void setFamily(short paramShort)
  {
    this.family = paramShort;
  }

  public void setFamily(String paramString)
  {
    if (paramString == null)
      throw new SyslogRuntimeException("Family cannot be null for class \"" + getClass().getName() + "\"");
    if ("AF_UNIX".equalsIgnoreCase(paramString.trim()))
      this.family = 1;
    else
      throw new SyslogRuntimeException("Family must be \"AF_UNIX\" for class \"" + getClass().getName() + "\"");
  }

  public int getProtocol()
  {
    return this.protocol;
  }

  public void setProtocol(int paramInt)
  {
    this.protocol = paramInt;
  }

  public int getMaxQueueSize()
  {
    return -1;
  }

  public void setMaxQueueSize(int paramInt)
  {
    throw new SyslogRuntimeException("UnixSyslog protocol does not uses a queueing mechanism");
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.unix.socket.UnixSocketSyslogConfig
 * JD-Core Version:    0.6.0
 */