package org.productivity.java.syslog4j.impl.message.structured;

import org.productivity.java.syslog4j.SyslogMessageIF;

public abstract interface StructuredSyslogMessageIF extends SyslogMessageIF
{
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessageIF
 * JD-Core Version:    0.6.0
 */