package org.productivity.java.syslog4j.impl;

import java.util.ArrayList;
import java.util.List;
import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;
import org.productivity.java.syslog4j.SyslogConfigIF;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogMessageIF;
import org.productivity.java.syslog4j.SyslogMessageModifierIF;
import org.productivity.java.syslog4j.SyslogMessageProcessorIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.message.processor.SyslogMessageProcessor;
import org.productivity.java.syslog4j.impl.message.processor.structured.StructuredSyslogMessageProcessor;
import org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessage;
import org.productivity.java.syslog4j.impl.message.structured.StructuredSyslogMessageIF;
import org.productivity.java.syslog4j.util.SyslogUtility;

public abstract class AbstractSyslog
  implements SyslogIF
{
  private static final long serialVersionUID = 2632017043774808264L;
  protected String syslogProtocol = null;
  protected AbstractSyslogConfigIF syslogConfig = null;
  protected SyslogMessageProcessorIF syslogMessageProcessor = null;
  protected SyslogMessageProcessorIF structuredSyslogMessageProcessor = null;
  protected Object backLogStatusSyncObject = new Object();
  protected boolean backLogStatus = false;
  protected List notifiedBackLogHandlers = new ArrayList();

  protected boolean getBackLogStatus()
  {
    synchronized (this.backLogStatusSyncObject)
    {
      return this.backLogStatus;
    }
  }

  public void setBackLogStatus(boolean paramBoolean)
  {
    if (this.backLogStatus != paramBoolean)
      synchronized (this.backLogStatusSyncObject)
      {
        if (!paramBoolean)
        {
          for (int i = 0; i < this.notifiedBackLogHandlers.size(); i++)
          {
            SyslogBackLogHandlerIF localSyslogBackLogHandlerIF = (SyslogBackLogHandlerIF)this.notifiedBackLogHandlers.get(i);
            localSyslogBackLogHandlerIF.up(this);
          }
          this.notifiedBackLogHandlers.clear();
        }
        this.backLogStatus = paramBoolean;
      }
  }

  public void initialize(String paramString, SyslogConfigIF paramSyslogConfigIF)
    throws SyslogRuntimeException
  {
    this.syslogProtocol = paramString;
    try
    {
      this.syslogConfig = ((AbstractSyslogConfigIF)paramSyslogConfigIF);
    }
    catch (ClassCastException localClassCastException)
    {
      throw new SyslogRuntimeException("provided config must implement AbstractSyslogConfigIF");
    }
    initialize();
  }

  public SyslogMessageProcessorIF getMessageProcessor()
  {
    if (this.syslogMessageProcessor == null)
      this.syslogMessageProcessor = SyslogMessageProcessor.getDefault();
    return this.syslogMessageProcessor;
  }

  public SyslogMessageProcessorIF getStructuredMessageProcessor()
  {
    if (this.structuredSyslogMessageProcessor == null)
      this.structuredSyslogMessageProcessor = StructuredSyslogMessageProcessor.getDefault();
    return this.structuredSyslogMessageProcessor;
  }

  public void setMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF)
  {
    this.syslogMessageProcessor = paramSyslogMessageProcessorIF;
  }

  public void setStructuredMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF)
  {
    this.structuredSyslogMessageProcessor = paramSyslogMessageProcessorIF;
  }

  public String getProtocol()
  {
    return this.syslogProtocol;
  }

  public SyslogConfigIF getConfig()
  {
    return this.syslogConfig;
  }

  public void log(int paramInt, String paramString)
  {
    if (this.syslogConfig.isUseStructuredData())
    {
      StructuredSyslogMessage localStructuredSyslogMessage = new StructuredSyslogMessage(null, null, paramString);
      log(getStructuredMessageProcessor(), paramInt, localStructuredSyslogMessage.createMessage());
    }
    else
    {
      log(getMessageProcessor(), paramInt, paramString);
    }
  }

  public void log(int paramInt, SyslogMessageIF paramSyslogMessageIF)
  {
    if ((paramSyslogMessageIF instanceof StructuredSyslogMessageIF))
    {
      if ((getMessageProcessor() instanceof StructuredSyslogMessageProcessor))
        log(getMessageProcessor(), paramInt, paramSyslogMessageIF.createMessage());
      else
        log(getStructuredMessageProcessor(), paramInt, paramSyslogMessageIF.createMessage());
    }
    else
      log(getMessageProcessor(), paramInt, paramSyslogMessageIF.createMessage());
  }

  public void debug(String paramString)
  {
    log(7, paramString);
  }

  public void notice(String paramString)
  {
    log(5, paramString);
  }

  public void info(String paramString)
  {
    log(6, paramString);
  }

  public void warn(String paramString)
  {
    log(4, paramString);
  }

  public void error(String paramString)
  {
    log(3, paramString);
  }

  public void critical(String paramString)
  {
    log(2, paramString);
  }

  public void alert(String paramString)
  {
    log(1, paramString);
  }

  public void emergency(String paramString)
  {
    log(0, paramString);
  }

  public void debug(SyslogMessageIF paramSyslogMessageIF)
  {
    log(7, paramSyslogMessageIF);
  }

  public void notice(SyslogMessageIF paramSyslogMessageIF)
  {
    log(5, paramSyslogMessageIF);
  }

  public void info(SyslogMessageIF paramSyslogMessageIF)
  {
    log(6, paramSyslogMessageIF);
  }

  public void warn(SyslogMessageIF paramSyslogMessageIF)
  {
    log(4, paramSyslogMessageIF);
  }

  public void error(SyslogMessageIF paramSyslogMessageIF)
  {
    log(3, paramSyslogMessageIF);
  }

  public void critical(SyslogMessageIF paramSyslogMessageIF)
  {
    log(2, paramSyslogMessageIF);
  }

  public void alert(SyslogMessageIF paramSyslogMessageIF)
  {
    log(1, paramSyslogMessageIF);
  }

  public void emergency(SyslogMessageIF paramSyslogMessageIF)
  {
    log(0, paramSyslogMessageIF);
  }

  protected String prefixMessage(String paramString1, String paramString2)
  {
    String str1 = this.syslogConfig.getIdent();
    String str2 = ((str1 == null) || ("".equals(str1.trim())) ? "" : new StringBuffer().append(str1).append(paramString2).toString()) + paramString1;
    return str2;
  }

  public void log(SyslogMessageProcessorIF paramSyslogMessageProcessorIF, int paramInt, String paramString)
  {
    String str = null;
    if (this.syslogConfig.isIncludeIdentInMessageModifier())
    {
      str = prefixMessage(paramString, ": ");
      str = modifyMessage(paramInt, str);
    }
    else
    {
      str = modifyMessage(paramInt, paramString);
      str = prefixMessage(str, ": ");
    }
    try
    {
      write(paramSyslogMessageProcessorIF, paramInt, str);
    }
    catch (SyslogRuntimeException localSyslogRuntimeException)
    {
      if (localSyslogRuntimeException.getCause() != null)
        backLog(paramInt, str, localSyslogRuntimeException.getCause());
      else
        backLog(paramInt, str, localSyslogRuntimeException);
      if (this.syslogConfig.isThrowExceptionOnWrite())
        throw localSyslogRuntimeException;
    }
  }

  protected void write(SyslogMessageProcessorIF paramSyslogMessageProcessorIF, int paramInt, String paramString)
    throws SyslogRuntimeException
  {
    String str = paramSyslogMessageProcessorIF.createSyslogHeader(this.syslogConfig.getFacility(), paramInt, this.syslogConfig.getLocalName(), this.syslogConfig.isSendLocalTimestamp(), this.syslogConfig.isSendLocalName());
    byte[] arrayOfByte1 = SyslogUtility.getBytes(this.syslogConfig, str);
    byte[] arrayOfByte2 = SyslogUtility.getBytes(this.syslogConfig, paramString);
    int i = arrayOfByte2.length;
    int j = this.syslogConfig.getMaxMessageLength() - arrayOfByte1.length;
    if ((this.syslogConfig.isTruncateMessage()) && (j > 0) && (i > j))
      i = j;
    byte[] arrayOfByte3;
    if (i <= j)
    {
      arrayOfByte3 = paramSyslogMessageProcessorIF.createPacketData(arrayOfByte1, arrayOfByte2, 0, i);
      write(paramInt, arrayOfByte3);
    }
    else
    {
      arrayOfByte3 = this.syslogConfig.getSplitMessageBeginText();
      byte[] arrayOfByte4 = this.syslogConfig.getSplitMessageEndText();
      int k = 0;
      int m = i;
      while (m > 0)
      {
        int n = k == 0 ? 1 : 0;
        int i1 = (arrayOfByte3 != null) && (n == 0) ? 1 : 0;
        int i2 = (arrayOfByte3 != null) && ((n != 0) || (m > j - arrayOfByte3.length)) ? 1 : 0;
        int i3 = j;
        i3 -= ((arrayOfByte3 != null) && (i1 != 0) ? arrayOfByte3.length : 0);
        i3 -= ((arrayOfByte4 != null) && (i2 != 0) ? arrayOfByte4.length : 0);
        if (i3 > m)
          i3 = m;
        if (i3 < 0)
          throw new SyslogRuntimeException("Message length < 0; recommendation: increase the size of maxMessageLength");
        byte[] arrayOfByte5 = paramSyslogMessageProcessorIF.createPacketData(arrayOfByte1, arrayOfByte2, k, i3, i1 != 0 ? arrayOfByte3 : null, i2 != 0 ? arrayOfByte4 : null);
        write(paramInt, arrayOfByte5);
        k += i3;
        m -= i3;
      }
    }
  }

  protected abstract void initialize()
    throws SyslogRuntimeException;

  protected abstract void write(int paramInt, byte[] paramArrayOfByte)
    throws SyslogRuntimeException;

  protected String modifyMessage(int paramInt, String paramString)
  {
    List localList = this.syslogConfig.getMessageModifiers();
    if ((localList == null) || (localList.size() < 1))
      return paramString;
    String str = paramString;
    int i = this.syslogConfig.getFacility();
    for (int j = 0; j < localList.size(); j++)
    {
      SyslogMessageModifierIF localSyslogMessageModifierIF = (SyslogMessageModifierIF)localList.get(j);
      str = localSyslogMessageModifierIF.modify(this, i, paramInt, str);
    }
    return str;
  }

  public void backLog(int paramInt, String paramString, Throwable paramThrowable)
  {
    backLog(paramInt, paramString, paramThrowable != null ? paramThrowable.toString() : "UNKNOWN");
  }

  public void backLog(int paramInt, String paramString1, String paramString2)
  {
    boolean bool = getBackLogStatus();
    if (!bool)
      setBackLogStatus(true);
    List localList = this.syslogConfig.getBackLogHandlers();
    int i = 0;
    while (i < localList.size())
    {
      SyslogBackLogHandlerIF localSyslogBackLogHandlerIF = (SyslogBackLogHandlerIF)localList.get(i);
      try
      {
        if (!bool)
        {
          localSyslogBackLogHandlerIF.down(this, paramString2);
          this.notifiedBackLogHandlers.add(localSyslogBackLogHandlerIF);
        }
        localSyslogBackLogHandlerIF.log(this, paramInt, paramString1, paramString2);
      }
      catch (Exception localException)
      {
        i++;
      }
    }
  }

  public abstract AbstractSyslogWriter getWriter();

  public abstract void returnWriter(AbstractSyslogWriter paramAbstractSyslogWriter);

  public Thread createWriterThread(AbstractSyslogWriter paramAbstractSyslogWriter)
  {
    Thread localThread = new Thread(paramAbstractSyslogWriter);
    localThread.setName("SyslogWriter: " + getProtocol());
    localThread.setDaemon(this.syslogConfig.isUseDaemonThread());
    if (this.syslogConfig.getThreadPriority() > -1)
      localThread.setPriority(this.syslogConfig.getThreadPriority());
    paramAbstractSyslogWriter.setThread(localThread);
    localThread.start();
    return localThread;
  }

  public AbstractSyslogWriter createWriter()
  {
    Class localClass = this.syslogConfig.getSyslogWriterClass();
    AbstractSyslogWriter localAbstractSyslogWriter = null;
    try
    {
      localAbstractSyslogWriter = (AbstractSyslogWriter)localClass.newInstance();
      localAbstractSyslogWriter.initialize(this);
    }
    catch (InstantiationException localInstantiationException)
    {
      if (this.syslogConfig.isThrowExceptionOnInitialize())
        throw new SyslogRuntimeException(localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      if (this.syslogConfig.isThrowExceptionOnInitialize())
        throw new SyslogRuntimeException(localIllegalAccessException);
    }
    return localAbstractSyslogWriter;
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.AbstractSyslog
 * JD-Core Version:    0.6.0
 */