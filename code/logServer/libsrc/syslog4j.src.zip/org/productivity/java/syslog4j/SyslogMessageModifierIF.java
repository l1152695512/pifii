package org.productivity.java.syslog4j;

public abstract interface SyslogMessageModifierIF extends SyslogConstants
{
  public abstract String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString);

  public abstract boolean verify(String paramString);
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogMessageModifierIF
 * JD-Core Version:    0.6.0
 */