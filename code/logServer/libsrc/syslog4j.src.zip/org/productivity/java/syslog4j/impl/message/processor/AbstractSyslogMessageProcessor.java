package org.productivity.java.syslog4j.impl.message.processor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.productivity.java.syslog4j.SyslogConstants;
import org.productivity.java.syslog4j.SyslogMessageProcessorIF;

public abstract class AbstractSyslogMessageProcessor
  implements SyslogMessageProcessorIF, SyslogConstants
{
  private static final long serialVersionUID = -5413127301924500938L;
  protected String localName = null;

  public byte[] createPacketData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
  {
    return createPacketData(paramArrayOfByte1, paramArrayOfByte2, paramInt1, paramInt2, null, null);
  }

  public byte[] createPacketData(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramInt1 < 0) || (paramInt2 < 0))
      return null;
    int i = paramArrayOfByte1.length + paramInt2;
    if (paramArrayOfByte3 != null)
      i += paramArrayOfByte3.length;
    if (paramArrayOfByte4 != null)
      i += paramArrayOfByte4.length;
    byte[] arrayOfByte = new byte[i];
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramArrayOfByte1.length);
    int j = paramArrayOfByte1.length;
    if (paramArrayOfByte3 != null)
    {
      System.arraycopy(paramArrayOfByte3, 0, arrayOfByte, j, paramArrayOfByte3.length);
      j += paramArrayOfByte3.length;
    }
    System.arraycopy(paramArrayOfByte2, paramInt1, arrayOfByte, j, paramInt2);
    j += paramInt2;
    if (paramArrayOfByte4 != null)
      System.arraycopy(paramArrayOfByte4, 0, arrayOfByte, j, paramArrayOfByte4.length);
    return arrayOfByte;
  }

  protected void appendPriority(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    int i = paramInt1 | paramInt2;
    paramStringBuffer.append("<");
    paramStringBuffer.append(i);
    paramStringBuffer.append(">");
  }

  protected void appendLocalTimestamp(StringBuffer paramStringBuffer)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("MMM dd HH:mm:ss ", Locale.ENGLISH);
    String str = localSimpleDateFormat.format(new Date());
    int i = paramStringBuffer.length() + 4;
    paramStringBuffer.append(str);
    if (paramStringBuffer.charAt(i) == '0')
      paramStringBuffer.setCharAt(i, ' ');
  }

  protected void appendLocalName(StringBuffer paramStringBuffer, String paramString)
  {
    if (paramString != null)
      paramStringBuffer.append(paramString);
    else
      paramStringBuffer.append(this.localName);
    paramStringBuffer.append(' ');
  }

  public String createSyslogHeader(int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    appendPriority(localStringBuffer, paramInt1, paramInt2);
    if (paramBoolean1)
      appendLocalTimestamp(localStringBuffer);
    if (paramBoolean2)
      appendLocalName(localStringBuffer, paramString);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.processor.AbstractSyslogMessageProcessor
 * JD-Core Version:    0.6.0
 */