package org.productivity.java.syslog4j.impl.backlog.printstream;

import org.productivity.java.syslog4j.SyslogBackLogHandlerIF;

public class SystemOutSyslogBackLogHandler extends PrintStreamSyslogBackLogHandler
{
  public static final SyslogBackLogHandlerIF create()
  {
    return new SystemOutSyslogBackLogHandler();
  }

  public SystemOutSyslogBackLogHandler()
  {
    super(System.out, true);
  }

  public SystemOutSyslogBackLogHandler(boolean paramBoolean)
  {
    super(System.out, true, paramBoolean);
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.backlog.printstream.SystemOutSyslogBackLogHandler
 * JD-Core Version:    0.6.0
 */