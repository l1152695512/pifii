package org.productivity.java.syslog4j.impl.message.modifier.mac;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.Mac;
import org.productivity.java.syslog4j.SyslogIF;
import org.productivity.java.syslog4j.SyslogRuntimeException;
import org.productivity.java.syslog4j.impl.message.modifier.AbstractSyslogMessageModifier;
import org.productivity.java.syslog4j.util.Base64;
import org.productivity.java.syslog4j.util.SyslogUtility;

public class MacSyslogMessageModifier extends AbstractSyslogMessageModifier
{
  private static final long serialVersionUID = 5054979194802197540L;
  protected MacSyslogMessageModifierConfig config = null;
  protected Mac mac = null;

  public MacSyslogMessageModifier(MacSyslogMessageModifierConfig paramMacSyslogMessageModifierConfig)
    throws SyslogRuntimeException
  {
    super(paramMacSyslogMessageModifierConfig);
    this.config = paramMacSyslogMessageModifierConfig;
    try
    {
      this.mac = Mac.getInstance(paramMacSyslogMessageModifierConfig.getMacAlgorithm());
      this.mac.init(paramMacSyslogMessageModifierConfig.getKey());
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new SyslogRuntimeException(localNoSuchAlgorithmException);
    }
    catch (InvalidKeyException localInvalidKeyException)
    {
      throw new SyslogRuntimeException(localInvalidKeyException);
    }
  }

  public static MacSyslogMessageModifier createHmacSHA1(Key paramKey)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA1(paramKey));
  }

  public static MacSyslogMessageModifier createHmacSHA1(String paramString)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA1(paramString));
  }

  public static MacSyslogMessageModifier createHmacSHA256(Key paramKey)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA256(paramKey));
  }

  public static MacSyslogMessageModifier createHmacSHA256(String paramString)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA256(paramString));
  }

  public static MacSyslogMessageModifier createHmacSHA512(Key paramKey)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA512(paramKey));
  }

  public static MacSyslogMessageModifier createHmacSHA512(String paramString)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacSHA512(paramString));
  }

  public static MacSyslogMessageModifier createHmacMD5(Key paramKey)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacMD5(paramKey));
  }

  public static MacSyslogMessageModifier createHmacMD5(String paramString)
  {
    return new MacSyslogMessageModifier(MacSyslogMessageModifierConfig.createHmacMD5(paramString));
  }

  public MacSyslogMessageModifierConfig getConfig()
  {
    return this.config;
  }

  public String modify(SyslogIF paramSyslogIF, int paramInt1, int paramInt2, String paramString)
  {
    synchronized (this.mac)
    {
      byte[] arrayOfByte1 = SyslogUtility.getBytes(paramSyslogIF.getConfig(), paramString);
      StringBuffer localStringBuffer = new StringBuffer(paramString);
      byte[] arrayOfByte2 = this.mac.doFinal(arrayOfByte1);
      String str = Base64.encodeBytes(arrayOfByte2, 8);
      localStringBuffer.append(this.config.getPrefix());
      localStringBuffer.append(str);
      localStringBuffer.append(this.config.getSuffix());
      return localStringBuffer.toString();
    }
  }

  public boolean verify(String paramString1, String paramString2)
  {
    byte[] arrayOfByte = Base64.decode(paramString2);
    return verify(paramString1, arrayOfByte);
  }

  public boolean verify(String paramString, byte[] paramArrayOfByte)
  {
    synchronized (this.mac)
    {
      byte[] arrayOfByte1 = SyslogUtility.getBytes(this.config, paramString);
      byte[] arrayOfByte2 = this.mac.doFinal(arrayOfByte1);
      return Arrays.equals(arrayOfByte2, paramArrayOfByte);
    }
  }
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.impl.message.modifier.mac.MacSyslogMessageModifier
 * JD-Core Version:    0.6.0
 */