package org.productivity.java.syslog4j;

public abstract interface SyslogIF extends SyslogConstants
{
  public abstract void initialize(String paramString, SyslogConfigIF paramSyslogConfigIF)
    throws SyslogRuntimeException;

  public abstract String getProtocol();

  public abstract SyslogConfigIF getConfig();

  public abstract void backLog(int paramInt, String paramString, Throwable paramThrowable);

  public abstract void backLog(int paramInt, String paramString1, String paramString2);

  public abstract void log(int paramInt, String paramString);

  public abstract void debug(String paramString);

  public abstract void info(String paramString);

  public abstract void notice(String paramString);

  public abstract void warn(String paramString);

  public abstract void error(String paramString);

  public abstract void critical(String paramString);

  public abstract void alert(String paramString);

  public abstract void emergency(String paramString);

  public abstract void log(int paramInt, SyslogMessageIF paramSyslogMessageIF);

  public abstract void debug(SyslogMessageIF paramSyslogMessageIF);

  public abstract void info(SyslogMessageIF paramSyslogMessageIF);

  public abstract void notice(SyslogMessageIF paramSyslogMessageIF);

  public abstract void warn(SyslogMessageIF paramSyslogMessageIF);

  public abstract void error(SyslogMessageIF paramSyslogMessageIF);

  public abstract void critical(SyslogMessageIF paramSyslogMessageIF);

  public abstract void alert(SyslogMessageIF paramSyslogMessageIF);

  public abstract void emergency(SyslogMessageIF paramSyslogMessageIF);

  public abstract void flush()
    throws SyslogRuntimeException;

  public abstract void shutdown()
    throws SyslogRuntimeException;

  public abstract void setMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF);

  public abstract SyslogMessageProcessorIF getMessageProcessor();

  public abstract void setStructuredMessageProcessor(SyslogMessageProcessorIF paramSyslogMessageProcessorIF);

  public abstract SyslogMessageProcessorIF getStructuredMessageProcessor();
}

/* Location:           D:\cache\windows\Desktop\logServer.src\libsrc\syslog4j\
 * Qualified Name:     org.productivity.java.syslog4j.SyslogIF
 * JD-Core Version:    0.6.0
 */